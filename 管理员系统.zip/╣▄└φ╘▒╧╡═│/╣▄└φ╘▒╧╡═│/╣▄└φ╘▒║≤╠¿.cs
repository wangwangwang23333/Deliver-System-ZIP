﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Runtime.InteropServices;

namespace 管理员系统
{
    public partial class 管理员后台 : Form
    {
        public string userID;
        const string mystr = "Data Source=DESKTOP-4U1M65K;Initial Catalog=take_out;Integrated Security=True;MultipleActiveResultSets=true";
        SqlConnection myconn = new SqlConnection(mystr);

        private string deliverGuyName;
        private string restaurantName;
        private string customerName;
        public 管理员后台(string userId)
        {
            this.userID = userId;
            InitializeComponent();
        }

        #region 无边框拖动效果
        [DllImport("user32.dll")]//拖动无窗体的控件
        public static extern bool ReleaseCapture();
        [DllImport("user32.dll")]
        public static extern bool SendMessage(IntPtr hwnd, int wMsg, int wParam, int lParam);
        public const int WM_SYSCOMMAND = 0x0112;
        public const int SC_MOVE = 0xF010;
        public const int HTCAPTION = 0x0002;

        private void Start_MouseDown(object sender, MouseEventArgs e)
        {
            //拖动窗体
            ReleaseCapture();
            SendMessage(this.Handle, WM_SYSCOMMAND, SC_MOVE + HTCAPTION, 0);
        }
        #endregion
        private void 管理员后台_Load(object sender, EventArgs e)
        {
            tabControl1.DrawItem += new DrawItemEventHandler(tabControl1_DrawItem);

            label1.Text += userID;

            //加载待审核骑手信息
            SqlCommand mycmd = new SqlCommand("select * from deliverGuy where deliverGuy_status='a'", myconn);
            SqlDataReader myreader;
            //读取数据
            myconn.Open();
            myreader = mycmd.ExecuteReader();
            //循环读取数据
            int index = 0;
            while (myreader.Read())
            {
                //利用new操作生成一个窗体
                Panel panel = new Panel();
                panel.Size = new Size(550, 100);
                panel.Location = new Point(5, 5 * (index + 1) + 100 * index);
                panel.BackColor = Color.LightGray;

                //向panel中添加信息
                //头像
                PictureBox picture = new PictureBox();
                picture.Size = new Size(60, 60);
                picture.Location = new Point(5, 5);
                picture.SizeMode = PictureBoxSizeMode.Zoom;
                try
                {
                    myreader.GetValue(6);
                    picture.Image = Image.FromFile(myreader.GetString(6));
                }
                catch (Exception)
                {
                    picture.Image = Image.FromFile("yonghutouxiang.png");
                }
                panel.Controls.Add(picture);

                Label orderLabel = new Label();
                orderLabel.Text = "编号:" + myreader.GetString(0);
                orderLabel.Location = new Point(70, 5);
                orderLabel.AutoSize = true;
                panel.Controls.Add(orderLabel);
                //姓名
                Label placeLabel = new Label();
                placeLabel.Text = myreader.GetString(1);
                placeLabel.AutoSize = true;
                placeLabel.Location = new Point(70, 30);
                panel.Controls.Add(placeLabel);
                //身份证号
                Label requireTimeLabel = new Label();
                requireTimeLabel.Text = "身份证号:" + myreader.GetString(5);
                requireTimeLabel.AutoSize = true;
                requireTimeLabel.Location = new Point(70, 55);
                panel.Controls.Add(requireTimeLabel);

                //按钮控件
                Button deliverGuyAcceptButton = new Button();
                deliverGuyAcceptButton.Name = myreader.GetString(0);
                deliverGuyAcceptButton.Size = new Size(30, 90);
                deliverGuyAcceptButton.Text = "审核通过";
                deliverGuyAcceptButton.Location = new Point(460, 2);
                deliverGuyAcceptButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.deliverGuyAcceptEvent);
                panel.Controls.Add(deliverGuyAcceptButton);

                //审核不通过
                Button deliverGuyUnAcceptButton = new Button();
                deliverGuyUnAcceptButton.Name = myreader.GetString(0);
                deliverGuyUnAcceptButton.Size = new Size(30, 90);
                deliverGuyUnAcceptButton.Text = "不通过";
                deliverGuyUnAcceptButton.Location = new Point(500, 2);
                deliverGuyUnAcceptButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.deliverGuyUnAcceptEvent);
                panel.Controls.Add(deliverGuyUnAcceptButton);

                //电话号码
                Label restaurantLabel = new Label();
                restaurantLabel.AutoSize = true;
                restaurantLabel.Location = new Point(70, 90);
                restaurantLabel.Text = "电话号码:" + myreader.GetString(2);
                panel.Controls.Add(requireTimeLabel);

                index++;
                tabPage2.Controls.Add(panel);
            }
            myreader.Close();
            myconn.Close();

            //加载待审核商家信息
            mycmd.CommandText = "select * from restaurant where restaurant_status='a'";
            //读取数据
            myconn.Open();
            myreader = mycmd.ExecuteReader();
            //循环读取数据
            int restaurantIndex = 0;
            while (myreader.Read())
            {
                //利用new操作生成一个窗体
                Panel panel = new Panel();
                panel.Size = new Size(550, 100);
                panel.Location = new Point(5, 5 * (restaurantIndex + 1) + 100 * restaurantIndex);
                panel.BackColor = Color.LightGray;

                //向panel中添加信息
                //头像
                PictureBox picture = new PictureBox();
                picture.Size = new Size(60, 60);
                picture.Location = new Point(5, 5);
                picture.SizeMode = PictureBoxSizeMode.Zoom;
                try
                {
                    myreader.GetValue(6);
                    picture.Image = Image.FromFile(myreader.GetString(9));
                }
                catch (Exception)
                {
                    picture.Image = Image.FromFile("yonghutouxiang.png");
                }
                panel.Controls.Add(picture);

                Label orderLabel = new Label();
                orderLabel.Text = "编号:" + myreader.GetString(0);
                orderLabel.Location = new Point(70, 5);
                orderLabel.AutoSize = true;
                panel.Controls.Add(orderLabel);
                //店名
                Label placeLabel = new Label();
                placeLabel.Text = myreader.GetString(1);
                placeLabel.AutoSize = true;
                placeLabel.Location = new Point(70, 30);
                panel.Controls.Add(placeLabel);
                //营业时间
                Label requireTimeLabel = new Label();
                requireTimeLabel.Text = "营业时间:" + myreader.GetString(5) + "～" + myreader.GetString(6);
                requireTimeLabel.AutoSize = true;
                requireTimeLabel.Location = new Point(70, 55);
                panel.Controls.Add(requireTimeLabel);

                //按钮控件
                Button deliverGuyAcceptButton = new Button();
                deliverGuyAcceptButton.Name = myreader.GetString(0);
                deliverGuyAcceptButton.Size = new Size(30, 90);
                deliverGuyAcceptButton.Text = "审核通过";
                deliverGuyAcceptButton.Location = new Point(460, 2);
                deliverGuyAcceptButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.restaurantAcceptEvent);
                panel.Controls.Add(deliverGuyAcceptButton);

                //审核不通过
                Button restaurantUnAcceptButton = new Button();
                restaurantUnAcceptButton.Name = myreader.GetString(0);
                restaurantUnAcceptButton.Size = new Size(30, 90);
                restaurantUnAcceptButton.Text = "不通过";
                restaurantUnAcceptButton.Location = new Point(500, 2);
                restaurantUnAcceptButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.restaurantUnAcceptEvent);
                panel.Controls.Add(restaurantUnAcceptButton);

                //电话号码
                Label restaurantLabel = new Label();
                restaurantLabel.AutoSize = true;
                restaurantLabel.Location = new Point(70, 90);
                restaurantLabel.Text = "电话号码:" + myreader.GetString(3);
                panel.Controls.Add(requireTimeLabel);

                //说明控件(此时还无法添加菜系
                string restaurantInformation = "商家地址:\n" + myreader.GetString(7);
                restaurantInformation += "\n商家说明:\n" + myreader.GetString(3);
                restaurantInformation += "\n配送费:" + myreader.GetValue(8).ToString();
                ToolTip toolTip = new ToolTip();
                toolTip.SetToolTip(panel, restaurantInformation);

                restaurantIndex++;
                tabPage1.Controls.Add(panel);
            }
            myreader.Close();
            myconn.Close();

            //投诉信息管理
            mycmd.CommandText = "select * from orders where orders_score<3";
            myconn.Open();
            myreader = mycmd.ExecuteReader();
            int commentIndex = 0;
            while (myreader.Read())
            {
                //利用new操作生成一个窗体
                Panel panel = new Panel();
                panel.Size = new Size(560, 165);
                panel.Location = new Point(5, 5 * (commentIndex + 1) + 165 * commentIndex);
                panel.BackColor = Color.LightGray;

                //向panel中添加信息
                Label orderLabel = new Label();
                orderLabel.Text = "订单编号:" + myreader.GetString(0);
                orderLabel.Location = new Point(5, 5);
                orderLabel.AutoSize = true;
                panel.Controls.Add(orderLabel);
                //地址信息
                Label placeLabel = new Label();
                placeLabel.Text = myreader.GetString(3) + "  至  " + myreader.GetString(4);
                placeLabel.AutoSize = true;
                placeLabel.Location = new Point(5, 55);
                panel.Controls.Add(placeLabel);
                //送达时间
                Label requireTimeLabel = new Label();
                requireTimeLabel.Text = "预期送达时间:" + myreader.GetValue(7).ToString();
                requireTimeLabel.AutoSize = true;
                requireTimeLabel.Location = new Point(5, 80);
                panel.Controls.Add(requireTimeLabel);
                //实际送达时间
                Label trueTimeLabel = new Label();
                trueTimeLabel.Text = "实际送达时间:" + myreader.GetValue(8).ToString();
                trueTimeLabel.AutoSize = true;
                trueTimeLabel.Location = new Point(5, 105);
                panel.Controls.Add(trueTimeLabel);

                //订单信息
                string orderInformation = /*"订单内容:\n";*/myreader.GetString(9);
                //将orderContent按照逗号分隔
                //string[] orderContent = myreader.GetString(9).Split(',');
                //for (int i = 0; i < orderContent.Length; i++)
                //{
                //    if (i != 0)
                //        orderInformation += ",";
                //    SqlCommand orderCommand = new SqlCommand("select dish_name from dish where dish_id='" + orderContent[i] + "'", myconn);
                //    //获取对应菜品名
                //    orderInformation += orderCommand.ExecuteScalar().ToString();
                //}
                //备注信息
                orderInformation += "\n订单备注:\n" + myreader.GetString(10);
                //用户评价
                try
                {
                    orderInformation += "\n用户评价:\n" + myreader.GetString(14);
                }
                catch (Exception)
                {
                    orderInformation += "\n用户评价:\n用户未给出评价";
                }
                ToolTip toolTip = new ToolTip();
                toolTip.SetToolTip(panel, orderInformation);

                //按钮控件


                //获取餐厅名
                Label restaurantLabel = new Label();
                restaurantLabel.AutoSize = true;
                restaurantLabel.Location = new Point(200, 5);
                SqlCommand mycmds = new SqlCommand("select restaurant_name from restaurant where restaurant_id='" + myreader.GetString(1) + "'", myconn);
                restaurantLabel.Text = mycmds.ExecuteNonQuery().ToString();
                panel.Controls.Add(requireTimeLabel);

                //获取用户信息
                mycmds.CommandText = "select customer_name,customer_phone from customer where customer_id='" + myreader.GetString(2) + "'";
                SqlDataReader informationReader = mycmds.ExecuteReader();
                informationReader.Read();
                Label informationLabel = new Label();
                informationLabel.AutoSize = true;
                informationLabel.Location = new Point(5, 30);
                informationLabel.Text = informationReader.GetString(0) + "    ";
                //保护用户隐私
                informationLabel.Text += "尾号:" + informationReader.GetString(1).Substring(informationReader.GetString(1).Length - 4);
                informationReader.Close();
                panel.Controls.Add(informationLabel);

                //获取订单评分
                Label scoreLabel = new Label();
                scoreLabel.Text = myreader.GetValue(11).ToString();
                scoreLabel.AutoSize = true;
                scoreLabel.Location = new Point(450, 50);
                scoreLabel.Font = new Font("宋体", 36);
                panel.Controls.Add(scoreLabel);

                //商家管理与骑手管理与用户管理
                Button deliverGuyButton = new Button();
                deliverGuyButton.Name = myreader.GetString(12);
                deliverGuyButton.Size = new Size(90, 25);
                deliverGuyButton.Text = "骑手管理";
                deliverGuyButton.Location = new Point(5, 130);
                deliverGuyButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.deliverGuyManageEvent);
                panel.Controls.Add(deliverGuyButton);

                Button restaurantButton = new Button();
                restaurantButton.Name = myreader.GetString(1);
                restaurantButton.Size = new Size(90, 25);
                restaurantButton.Text = "商家管理";
                restaurantButton.Location = new Point(100, 130);
                restaurantButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.restaurantManageEvent);
                panel.Controls.Add(restaurantButton);

                Button customerButton = new Button();
                customerButton.Name = myreader.GetString(2);
                customerButton.Size = new Size(90, 25);
                customerButton.Text = "用户管理";
                customerButton.Location = new Point(195, 130);
                customerButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.customerManageEvent);
                panel.Controls.Add(customerButton);

                commentIndex++;
                tabPage6.Controls.Add(panel);
            }
            myreader.Close();
            myconn.Close();
        }

        //骑手审核通过
        protected void deliverGuyAcceptEvent(object sender, MouseEventArgs e)
        {
            //获取该骑手用户名
            string name = ((Button)sender).Name;

            //如果左键被按下
            if (e.Button == MouseButtons.Left)
            {
                //弹窗询问是否确定
                if (MessageBox.Show("确定通过该骑手的注册申请吗？", "提示", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    //更改该骑手状态为b
                    SqlCommand mycmd = new SqlCommand("update deliverGuy set deliverGuy_status = 'b' where deliverGuy_id = '" + name + "'", myconn);
                    myconn.Open();
                    mycmd.ExecuteNonQuery();
                    myconn.Close();
                    //自动刷新窗体
                    this.refreshForm();
                }
            }
        }

        //骑手审核不通过
        protected void deliverGuyUnAcceptEvent(object sender, MouseEventArgs e)
        {
            //获取该骑手用户名
            string name = ((Button)sender).Name;

            //如果左键被按下
            if (e.Button == MouseButtons.Left)
            {
                //弹窗询问是否确定
                if (MessageBox.Show("确定不通过该骑手的注册申请吗？", "提示", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    //更改该骑手状态为d
                    SqlCommand mycmd = new SqlCommand("update deliverGuy set deliverGuy_status = 'd' where deliverGuy_id = '" + name + "'", myconn);
                    myconn.Open();
                    mycmd.ExecuteNonQuery();
                    myconn.Close();
                    //自动刷新窗体
                    this.refreshForm();
                }
            }
        }

        //商家审核通过
        protected void restaurantAcceptEvent(object sender, MouseEventArgs e)
        {
            //获取该商家用户名
            string name = ((Button)sender).Name;

            //如果左键被按下
            if (e.Button == MouseButtons.Left)
            {
                //弹窗询问是否确定
                if (MessageBox.Show("确定通过该商家的注册申请吗？", "提示", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    //更改该商家状态为b
                    SqlCommand mycmd = new SqlCommand("update restaurant set restaurant_status = 'b' where restaurant_id = '" + name + "'", myconn);
                    myconn.Open();
                    mycmd.ExecuteNonQuery();
                    myconn.Close();
                    //自动刷新窗体
                    this.refreshForm();
                }
            }
        }

        //商家审核不通过
        protected void restaurantUnAcceptEvent(object sender, MouseEventArgs e)
        {
            //获取该商家用户名
            string name = ((Button)sender).Name;

            //如果左键被按下
            if (e.Button == MouseButtons.Left)
            {
                //弹窗询问是否确定
                if (MessageBox.Show("确定不通过该商家的注册申请吗？", "提示", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    //更改该商家状态为d
                    SqlCommand mycmd = new SqlCommand("update restaurant set restaurant_status = 'd' where restaurant_id = '" + name + "'", myconn);
                    myconn.Open();
                    mycmd.ExecuteNonQuery();
                    myconn.Close();
                    //自动刷新窗体
                    this.refreshForm();
                }
            }
        }

        //刷新窗体
        private void refreshForm()
        {
            this.Close();
            管理员后台 fp = new 管理员后台(this.userID);
            fp.Show();
        }

        //骑手管理
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("尚未输入要检索的骑手信息！");
                return;
            }
            SqlCommand mycmd = new SqlCommand("select * from deliverGuy where deliverGuy_id='" + textBox1.Text + "'", myconn);
            //按手机号检索
            if (comboBox1.SelectedIndex == 1)
            {
                mycmd.CommandText = "select * from deliverGuy where deliverGuy_phone='" + textBox1.Text + "'";
            }
            myconn.Open();
            //检索结果为空
            if (mycmd.ExecuteScalar() == null)
            {
                myconn.Close();
                if (comboBox1.SelectedIndex == 1)
                {
                    MessageBox.Show("不存在手机号为" + textBox1.Text + "的骑手!");
                }
                else
                {
                    MessageBox.Show("不存在用户ID为" + textBox1.Text + "的骑手!");
                }
                return;
            }
            SqlDataReader myreader = mycmd.ExecuteReader();
            //获取信息
            myreader.Read();
            if (tabPage4.Controls.Count != 5)
            {
                tabPage4.Controls.RemoveByKey("userInformation");
                tabPage4.Controls.RemoveByKey(deliverGuyName);
            }

            //利用new操作生成一个窗体
            Panel panel = new Panel();
            panel.Size = new Size(550, 80);
            panel.Location = new Point(5, 70);
            panel.BackColor = Color.LightGray;

            //向panel中添加信息
            //头像
            PictureBox picture = new PictureBox();
            picture.Size = new Size(60, 60);
            picture.Location = new Point(5, 5);
            picture.SizeMode = PictureBoxSizeMode.Zoom;
            try
            {
                myreader.GetValue(6);
                picture.Image = Image.FromFile(myreader.GetString(6));
            }
            catch (Exception)
            {
                picture.Image = Image.FromFile("yonghutouxiang.png");
            }
            panel.Controls.Add(picture);

            Label orderLabel = new Label();
            orderLabel.Text = "编号:" + myreader.GetString(0);
            orderLabel.Location = new Point(70, 5);
            orderLabel.AutoSize = true;
            panel.Controls.Add(orderLabel);
            //姓名
            Label placeLabel = new Label();
            placeLabel.Text = myreader.GetString(1);
            placeLabel.AutoSize = true;
            placeLabel.Location = new Point(70, 30);
            panel.Controls.Add(placeLabel);
            //身份证号
            Label requireTimeLabel = new Label();
            requireTimeLabel.Text = "身份证号:" + myreader.GetString(5);
            requireTimeLabel.AutoSize = true;
            requireTimeLabel.Location = new Point(70, 55);
            panel.Controls.Add(requireTimeLabel);

            //电话号码
            Label restaurantLabel = new Label();
            restaurantLabel.AutoSize = true;
            restaurantLabel.Location = new Point(70, 90);
            restaurantLabel.Text = "电话号码:" + myreader.GetString(2);
            panel.Controls.Add(restaurantLabel);

            //根据用户状态确定按钮功能
            Button specificButton = new Button();
            specificButton.Name = myreader.GetString(0);
            deliverGuyName = specificButton.Name;
            specificButton.Size = new Size(100, 30);
            specificButton.Location = new Point(50, 230);

            //用户状态
            if (myreader.GetString(7) == "a")
            {
                label2.Text = "该骑手当前正在等待审核";
                //通过审核
                specificButton.Text = "审核通过";
                specificButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.deliverGuyAcceptEvent);
            }
            else if (myreader.GetString(7) == "b")
            {
                label2.Text = "该骑手当前状态正常";
                specificButton.Text = "封禁用户";
                specificButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.deliverGuyLockedEvent);

            }
            else if (myreader.GetString(7) == "c")
            {
                label2.Text = "该骑手当前已被封禁";
                specificButton.Text = "取消封禁";
                specificButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.deliverGuyUnlockedEvent);
            }
            else
            {
                label2.Text = "该骑手信息审核未通过";
                specificButton.Text = "再次通过";
                specificButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.deliverGuyAcceptEvent);
            }
            tabPage4.Controls.Add(specificButton);

            //用户完成的总订单数
            SqlCommand mycmds = new SqlCommand("select count(*) from orders where deliverGuy_id='" + myreader.GetString(0) + "' and orders_status='d'", myconn);
            label3.Text = "骑手完成的总订单数:" + mycmds.ExecuteScalar().ToString();

            //添加控件
            panel.Name = "userInformation";
            tabPage4.Controls.Add(panel);

            myreader.Close();
            myconn.Close();
        }

        //封禁骑手
        protected void deliverGuyLockedEvent(object sender, MouseEventArgs e)
        {
            //获取该骑手用户名
            string name = ((Button)sender).Name;

            //如果左键被按下
            if (e.Button == MouseButtons.Left)
            {
                //弹窗询问是否确定
                if (MessageBox.Show("确定要封禁该骑手吗？", "提示", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    //更改该骑手状态为b
                    SqlCommand mycmd = new SqlCommand("update deliverGuy set deliverGuy_status = 'c' where deliverGuy_id = '" + name + "'", myconn);
                    myconn.Open();
                    mycmd.ExecuteNonQuery();
                    myconn.Close();
                    //自动刷新窗体
                    this.refreshForm();
                }
            }
        }

        //解封骑手
        protected void deliverGuyUnlockedEvent(object sender, MouseEventArgs e)
        {
            //获取该骑手用户名
            string name = ((Button)sender).Name;

            //如果左键被按下
            if (e.Button == MouseButtons.Left)
            {
                //弹窗询问是否确定
                if (MessageBox.Show("确定要解除封禁该骑手吗？", "提示", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    //更改该骑手状态为b
                    SqlCommand mycmd = new SqlCommand("update deliverGuy set deliverGuy_status = 'b' where deliverGuy_id = '" + name + "'", myconn);
                    myconn.Open();
                    mycmd.ExecuteNonQuery();
                    myconn.Close();
                    //自动刷新窗体
                    this.refreshForm();
                }
            }
        }

        //封禁商家
        protected void restaurantLockedEvent(object sender, MouseEventArgs e)
        {
            //获取该商家用户名
            string name = ((Button)sender).Name;

            //如果左键被按下
            if (e.Button == MouseButtons.Left)
            {
                //弹窗询问是否确定
                if (MessageBox.Show("确定要封禁该商家吗？", "提示", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    //更改该骑手状态为b
                    SqlCommand mycmd = new SqlCommand("update restaurant set restaurant_status = 'c' where restaurant" +
                        "_id = '" + name + "'", myconn);
                    myconn.Open();
                    mycmd.ExecuteNonQuery();
                    myconn.Close();
                    //自动刷新窗体
                    this.refreshForm();
                }
            }
        }

        //解封商家
        protected void restaurantUnLockedEvent(object sender, MouseEventArgs e)
        {
            //获取该商家用户名
            string name = ((Button)sender).Name;

            //如果左键被按下
            if (e.Button == MouseButtons.Left)
            {
                //弹窗询问是否确定
                if (MessageBox.Show("确定要解除封禁该商家吗？", "提示", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    //更改该骑手状态为b
                    SqlCommand mycmd = new SqlCommand("update restaurant set restaurant_status = 'b' where restaurant_id = '" + name + "'", myconn);
                    myconn.Open();
                    mycmd.ExecuteNonQuery();
                    myconn.Close();
                    //自动刷新窗体
                    this.refreshForm();
                }
            }
        }

        //快速管理骑手
        protected void deliverGuyManageEvent(object sender, MouseEventArgs e)
        {
            //获取该按钮对应骑手号
            string name = ((Button)sender).Name;

            //如果左键被按下
            if (e.Button == MouseButtons.Left)
            {
                //跳转到指定页面
                this.tabControl1.SelectedIndex = 3;
                comboBox1.SelectedIndex = 0;
                textBox1.Text = name;
                //执行按钮事件
                button1_Click(sender, e);
            }
        }

        //快速管理商家
        protected void restaurantManageEvent(object sender, MouseEventArgs e)
        {
            //获取该按钮对应商家
            string name = ((Button)sender).Name;

            //如果左键被按下
            if (e.Button == MouseButtons.Left)
            {
                //跳转到指定页面
                this.tabControl1.SelectedIndex = 2;
                textBox2.Text = name;
                //执行按钮事件
                button2_Click(sender, e);
            }
        }

        //快速管理用户
        protected void customerManageEvent(object sender, MouseEventArgs e)
        {
            //获取该按钮对应用户
            string name = ((Button)sender).Name;

            //如果左键被按下
            if (e.Button == MouseButtons.Left)
            {
                //跳转到指定页面
                this.tabControl1.SelectedIndex = 4;
                comboBox2.SelectedIndex = 0;
                textBox3.Text = name;
                //执行按钮事件
                button3_Click(sender, e);
            }
        }

        //商家管理
        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox2.Text == "")
            {
                MessageBox.Show("尚未输入要检索的商家信息！");
                return;
            }

            SqlCommand mycmd = new SqlCommand("select * from restaurant where restaurant_id='" + textBox2.Text + "'", myconn);

            myconn.Open();
            //检索结果为空
            if (mycmd.ExecuteScalar() == null)
            {
                myconn.Close();
                MessageBox.Show("不存在ID为" + textBox2.Text + "的商家!");
                return;
            }
            SqlDataReader myreader = mycmd.ExecuteReader();
            //获取信息
            myreader.Read();
            if (tabPage3.Controls.Count != 4)
            {
                tabPage3.Controls.RemoveAt(4);
                tabPage3.Controls.RemoveByKey(restaurantName);
            }

            //利用new操作生成一个窗体
            Panel panel = new Panel();
            panel.Size = new Size(550, 90);
            panel.Location = new Point(5, 70);
            panel.BackColor = Color.LightGray;

            //向panel中添加信息
            //头像
            PictureBox picture = new PictureBox();
            picture.Size = new Size(60, 60);
            picture.Location = new Point(5, 5);
            picture.SizeMode = PictureBoxSizeMode.Zoom;
            try
            {
                myreader.GetValue(9);
                picture.Image = Image.FromFile(myreader.GetString(9));
            }
            catch (Exception)
            {
                picture.Image = Image.FromFile("yonghutouxiang.png");
            }
            panel.Controls.Add(picture);

            Label orderLabel = new Label();
            orderLabel.Text = "编号:" + myreader.GetString(0);
            orderLabel.Location = new Point(70, 5);
            orderLabel.AutoSize = true;
            panel.Controls.Add(orderLabel);
            //店名
            Label placeLabel = new Label();
            placeLabel.Text = myreader.GetString(1);
            placeLabel.AutoSize = true;
            placeLabel.Location = new Point(70, 30);
            panel.Controls.Add(placeLabel);
            //营业时间
            Label requireTimeLabel = new Label();
            requireTimeLabel.Text = "营业时间:" + myreader.GetString(6) + "～" + myreader.GetString(7);
            requireTimeLabel.AutoSize = true;
            requireTimeLabel.Location = new Point(70, 55);
            panel.Controls.Add(requireTimeLabel);

            //电话号码
            Label restaurantLabel = new Label();
            restaurantLabel.AutoSize = true;
            restaurantLabel.Location = new Point(70, 90);
            restaurantLabel.Text = "电话号码:" + myreader.GetString(4);
            panel.Controls.Add(restaurantLabel);

            //说明控件
            string restaurantInformation = "商家地址:\n" + myreader.GetString(7);
            restaurantInformation += "\n商家说明:\n" + myreader.GetString(3);
            restaurantInformation += "\n配送费:" + myreader.GetValue(8).ToString();
            restaurantInformation += "\n售菜:\n";
            //获取全部菜系
            SqlCommand mycmds = new SqlCommand("select dish_name from dish where restaurant_id='" + myreader.GetString(0) + "'", myconn);
            SqlDataReader myreaders = mycmds.ExecuteReader();
            bool firstDish = true;
            while (myreaders.Read())
            {
                if (firstDish)
                    firstDish = false;
                else
                    restaurantInformation += ",";
                restaurantInformation += myreaders.GetString(0);
            }
            myreaders.Close();
            ToolTip toolTip = new ToolTip();
            toolTip.SetToolTip(panel, restaurantInformation);

            tabPage3.Controls.Add(panel);

            //根据用户状态确定按钮功能
            Button specificButton = new Button();
            specificButton.Name = myreader.GetString(0);
            restaurantName = specificButton.Name;
            specificButton.Size = new Size(100, 30);
            specificButton.Location = new Point(50, 230);

            //用户状态
            if (myreader.GetString(11) == "a")
            {
                label6.Text = "该商家当前正在等待审核";
                //通过审核
                specificButton.Text = "审核通过";
                specificButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.restaurantAcceptEvent);
            }
            else if (myreader.GetString(11) == "b")
            {
                label6.Text = "该商家当前状态正常";
                specificButton.Text = "封禁商家";
                specificButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.restaurantLockedEvent);

            }
            else if (myreader.GetString(11) == "c")
            {
                label6.Text = "该商家当前已被封禁";
                specificButton.Text = "取消封禁";
                specificButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.restaurantUnLockedEvent);
            }
            else
            {
                label6.Text = "该商家信息审核未通过";
                specificButton.Text = "再次通过";
                specificButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.restaurantAcceptEvent);
            }
            tabPage3.Controls.Add(specificButton);

            myreader.Close();
            myconn.Close();
        }

        //用户管理
        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox3.Text == "")
            {
                MessageBox.Show("尚未输入要检索的用户信息！");
                return;
            }

            SqlCommand mycmd = new SqlCommand("select * from customer where customer_id='" + textBox3.Text + "'", myconn);
            //按手机号检索
            if (comboBox2.SelectedIndex == 1)
            {
                mycmd.CommandText = "select * from customer where customer_phone='" + textBox3.Text + "'";
            }
            myconn.Open();
            //检索结果为空
            if (mycmd.ExecuteScalar() == null)
            {
                myconn.Close();
                if (comboBox2.SelectedIndex == 1)
                {
                    MessageBox.Show("不存在手机号为" + textBox3.Text + "的用户!");
                }
                else
                {
                    MessageBox.Show("不存在用户ID为" + textBox3.Text + "的用户!");
                }
                return;
            }
            SqlDataReader myreader = mycmd.ExecuteReader();
            //获取信息
            myreader.Read();
            if (tabPage5.Controls.Count != 4)
            {
                tabPage5.Controls.RemoveAt(4);
                tabPage5.Controls.RemoveByKey(customerName);
            }

            //利用new操作生成一个窗体
            Panel panel = new Panel();
            panel.Size = new Size(550, 80);
            panel.Location = new Point(5, 70);
            panel.BackColor = Color.LightGray;

            //向panel中添加信息
            //头像
            PictureBox picture = new PictureBox();
            picture.Size = new Size(60, 60);
            picture.Location = new Point(5, 5);
            picture.SizeMode = PictureBoxSizeMode.Zoom;
            try
            {
                myreader.GetValue(6);
                picture.Image = Image.FromFile(myreader.GetString(6));
            }
            catch (Exception)
            {
                picture.Image = Image.FromFile("yonghutouxiang.png");
            }
            panel.Controls.Add(picture);

            Label orderLabel = new Label();
            orderLabel.Text = "编号:" + myreader.GetString(0);
            orderLabel.AutoSize = true;
            orderLabel.Location = new Point(70, 5);
            panel.Controls.Add(orderLabel);
            //姓名
            Label placeLabel = new Label();
            placeLabel.Text = myreader.GetString(1);
            placeLabel.AutoSize = true;
            placeLabel.Location = new Point(70, 30);
            panel.Controls.Add(placeLabel);

            //电话号码
            Label restaurantLabel = new Label();
            restaurantLabel.AutoSize = true;
            restaurantLabel.Location = new Point(70, 90);
            restaurantLabel.Text = "电话号码:" + myreader.GetString(2);
            panel.Controls.Add(restaurantLabel);

            //根据用户状态确定按钮功能
            Button specificButton = new Button();
            specificButton.Name = myreader.GetString(0);
            customerName = specificButton.Name;
            specificButton.Size = new Size(100, 30);
            specificButton.Location = new Point(50, 230);

            //用户状态
            if (myreader.GetString(7) == "a")
            {
                label5.Text = "该用户当前已被封禁";
                specificButton.Text = "取消封禁";
                specificButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.customerUnLockedEvent);
            }
            else
            {
                label5.Text = "该用户当前状态正常";
                specificButton.Text = "封禁用户";
                specificButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.customerLockedEvent);
            }

            tabPage5.Controls.Add(specificButton);

            //添加控件
            tabPage5.Controls.Add(panel);

            myreader.Close();
            myconn.Close();
        }

        //封禁用户
        protected void customerLockedEvent(object sender, MouseEventArgs e)
        {
            //获取该用户名
            string name = ((Button)sender).Name;

            //如果左键被按下
            if (e.Button == MouseButtons.Left)
            {
                //弹窗询问是否确定
                if (MessageBox.Show("确定要封禁该用户吗？", "提示", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    //更改该骑手状态为b
                    SqlCommand mycmd = new SqlCommand("update customer set customer_status = 'a' where customer" +
                        "_id = '" + name + "'", myconn);
                    myconn.Open();
                    mycmd.ExecuteNonQuery();
                    myconn.Close();
                    //自动刷新窗体
                    this.refreshForm();
                }
            }
        }

        //解封用户
        protected void customerUnLockedEvent(object sender, MouseEventArgs e)
        {
            //获取该用户用户名
            string name = ((Button)sender).Name;

            //如果左键被按下
            if (e.Button == MouseButtons.Left)
            {
                //弹窗询问是否确定
                if (MessageBox.Show("确定要解除封禁该用户吗？", "提示", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    //更改该骑手状态为b
                    SqlCommand mycmd = new SqlCommand("update customer set customer_status = 'b' where customer_id = '" + name + "'", myconn);
                    myconn.Open();
                    mycmd.ExecuteNonQuery();
                    myconn.Close();
                    //自动刷新窗体
                    this.refreshForm();
                }
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            timer.Start();
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            if (this.Opacity >= 0.025)
                this.Opacity -= 0.025;
            else
            {
                timer.Stop();
                Application.Exit();
            }
        }

        //绘图
        private void tabControl1_DrawItem(object sender, DrawItemEventArgs e)
        {
            StringFormat sf = new StringFormat();

            #region 头背景
            sf.LineAlignment = StringAlignment.Center;
            sf.Alignment = StringAlignment.Center;
            Rectangle rec = tabControl1.ClientRectangle;
            //获取背景图片，我的背景图片在项目资源文件中。
            Image backImage = Properties.Resources.UnselectedIndex;
            e.Graphics.DrawImage(backImage, 0, 2, tabControl1.Width, tabControl1.ItemSize.Height + 2);
            #endregion
            #region  设置选择的标签的背景
            if (e.Index == tabControl1.SelectedIndex)
                e.Graphics.DrawImage(Properties.Resources.selectedIndex, e.Bounds.X, e.Bounds.Y, e.Bounds.Width, e.Bounds.Height);
            else
                e.Graphics.DrawImage(Properties.Resources.UnselectedIndex, e.Bounds.X, e.Bounds.Y, e.Bounds.Width, e.Bounds.Height);
            e.Graphics.DrawString(((TabControl)sender).TabPages[e.Index].Text,
            System.Windows.Forms.SystemInformation.MenuFont, new SolidBrush(Color.Black), e.Bounds, sf);
            #endregion
            #region 重写标签名
            ColorConverter colorConverter = new ColorConverter();
            Color cwhite = (Color)colorConverter.ConvertFromString("#2178ba");
            SolidBrush white = new SolidBrush(cwhite);

            Rectangle rect0 = tabControl1.GetTabRect(0);
            Rectangle rect1 = tabControl1.GetTabRect(1);
            Rectangle rect2 = tabControl1.GetTabRect(2);
            Rectangle rect3 = tabControl1.GetTabRect(3);
            Rectangle rect4 = tabControl1.GetTabRect(4);
            Rectangle rect5 = tabControl1.GetTabRect(5);

            StringFormat stringFormat = new StringFormat();
            stringFormat.Alignment = StringAlignment.Center;
            stringFormat.LineAlignment = StringAlignment.Center;

            e.Graphics.DrawString("商家审核", new Font("微软雅黑", 12), white, rect0, stringFormat);
            e.Graphics.DrawString("骑手审核", new Font("微软雅黑", 12), white, rect1, stringFormat);
            e.Graphics.DrawString("商家管理", new Font("微软雅黑", 12), white, rect2, stringFormat);
            e.Graphics.DrawString("骑手管理", new Font("微软雅黑", 12), white, rect3, stringFormat);
            e.Graphics.DrawString("用户管理", new Font("微软雅黑", 12), white, rect4, stringFormat);
            e.Graphics.DrawString("投诉管理", new Font("微软雅黑", 12), white, rect5, stringFormat);



            #endregion



        }
    }
}