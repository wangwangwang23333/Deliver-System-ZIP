﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Runtime.InteropServices;

namespace 管理员系统
{
    public partial class Form1 : Form
    {
        const string mystr = "Data Source=DESKTOP-4U1M65K;Initial Catalog=take_out;Integrated Security=True;MultipleActiveResultSets=true";
        SqlConnection myconn = new SqlConnection(mystr);
        public Form1()
        {
            InitializeComponent();
        }

        #region 无边框拖动效果
        [DllImport("user32.dll")]//拖动无窗体的控件
        public static extern bool ReleaseCapture();
        [DllImport("user32.dll")]
        public static extern bool SendMessage(IntPtr hwnd, int wMsg, int wParam, int lParam);
        public const int WM_SYSCOMMAND = 0x0112;
        public const int SC_MOVE = 0xF010;
        public const int HTCAPTION = 0x0002;

        private void Start_MouseDown(object sender, MouseEventArgs e)
        {
            //拖动窗体
            ReleaseCapture();
            SendMessage(this.Handle, WM_SYSCOMMAND, SC_MOVE + HTCAPTION, 0);
        }
        #endregion
        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            pictureBox1.Parent = pictureBox2;
            label3.Parent = pictureBox2;

            //读取文件信息
            StreamReader sr = new StreamReader("masterinformation.txt");
            string userName = sr.ReadLine();
            if(userName!="null")
            {
                checkBox2.Checked = true;
                textBox1.Text = userName;
                textBox2.Text = sr.ReadLine();
            }
            else
            {
                checkBox2.Checked = false;
            }
            sr.Close();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            timer.Start();
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            if (this.Opacity >= 0.025)
                this.Opacity -= 0.025;
            else
            {
                timer.Stop();
                this.Close();
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            string userID = textBox1.Text;
            string userPassword = textBox2.Text;
            if (userID.Length == 0)
            {
                MessageBox.Show("用户名不能为空");
                return;
            }
            if (userPassword.Length == 0)
            {
                MessageBox.Show("密码不能为空");
                return;
            }
            //查询用户名是否存在
            SqlCommand mycmd = new SqlCommand("select masters_password from masters where masters_id='" + userID + "'", myconn);
            myconn.Open();
            if (mycmd.ExecuteScalar() == null)
            {
                myconn.Close();
                MessageBox.Show("不存在该用户！");
                return;
            }
            if (mycmd.ExecuteScalar().ToString() != userPassword)
            {
                myconn.Close();
                MessageBox.Show("密码错误！");
                return;
            }
            //成功登录
            myconn.Close();

            //如果勾选了记住密码，则存储到本地文件
            if(checkBox2.Checked==true)
            {
                StreamWriter sr = new StreamWriter("masterinformation.txt", false);
                sr.WriteLine(textBox1.Text);
                sr.WriteLine(textBox2.Text);
                sr.Close();
            }
            else
            {
                StreamWriter sr = new StreamWriter("masterinformation.txt", false);
                sr.WriteLine("null");
                sr.Close();
            }


            管理员后台 fp = new 管理员后台(userID);
            fp.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox2.PasswordChar == '●')
            {
                textBox2.PasswordChar = '\0';
                button3.Image = Image.FromFile("yanjingzheng.png");
            }
            else
            {
                textBox2.PasswordChar = '●';
                button3.Image = Image.FromFile("yanjingbi.png");
            }
        }
    }
}
