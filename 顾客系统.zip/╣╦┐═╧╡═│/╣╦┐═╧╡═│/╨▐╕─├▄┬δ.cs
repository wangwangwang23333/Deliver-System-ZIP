﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Runtime.InteropServices;

namespace 顾客系统
{
    public partial class 修改密码 : Form
    {
        public 修改密码()
        {
            InitializeComponent();
        }
        public string userID;
        static string mystr = "Initial Catalog = take_out;Data Source = (local);Integrated Security = True;";
        SqlConnection myconn = new SqlConnection(mystr);
        bool passwordFinished = false;
        public 修改密码(string userId)
        {
            userID = userId;
            InitializeComponent();
        }

        private void 修改个人密码_Load(object sender, EventArgs e)
        {

        }

        #region 无边框拖动效果
        [DllImport("user32.dll")]//拖动无窗体的控件
        public static extern bool ReleaseCapture();
        [DllImport("user32.dll")]
        public static extern bool SendMessage(IntPtr hwnd, int wMsg, int wParam, int lParam);
        public const int WM_SYSCOMMAND = 0x0112;
        public const int SC_MOVE = 0xF010;
        public const int HTCAPTION = 0x0002;

        private void Start_MouseDown(object sender, MouseEventArgs e)
        {
            //拖动窗体
            ReleaseCapture();
            SendMessage(this.Handle, WM_SYSCOMMAND, SC_MOVE + HTCAPTION, 0);
        }
        #endregion

        private void button1_Click(object sender, EventArgs e)
        {
            //确认新密码正常
            if (!passwordFinished)
            {
                MessageBox.Show("请输入符合要求的新密码！");
                return;
            }
            //确认原密码无误
            string oldPassword = textBox2.Text;
            //获取当前userID对应的密码
            SqlCommand mycmd = new SqlCommand("select customer_password from customer where customer_id='" + userID + "'", myconn);
            myconn.Open();
            //密码错误
            if (mycmd.ExecuteScalar().ToString() != oldPassword)
            {
                myconn.Close();
                MessageBox.Show("输入的旧密码错误！");
                return;
            }
            //修改密码
            mycmd.CommandText = "update customer set customer_password = '" + textBox4.Text + "' where customer_id = '" + userID + "'";
            mycmd.ExecuteNonQuery();
            myconn.Close();
            MessageBox.Show("已修改密码！");
            this.Close();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            //同步更新
            string userPassword = textBox4.Text;
            //检验密码异常
            if (userPassword.Length < 8)
                label6.Text = "密码需要至少八位";
            else
            {
                //检验是否同时含有字母和数字
                bool numberAppear = false;
                bool wordAppear = false;
                for (int i = 0; i < userPassword.Length; i++)
                {
                    if (userPassword[i] >= '0' && userPassword[i] <= '9')
                        numberAppear = true;
                    else if ((userPassword[i] >= 'a' && userPassword[i] <= 'z') ||
                        userPassword[i] >= 'A' && userPassword[i] <= 'Z')
                        wordAppear = true;
                }
                //输出提示符
                if (!numberAppear || !wordAppear)
                    label6.Text = "密码需要同时包含数字和字母";
                else
                {
                    label6.Text = "合法的密码";
                    passwordFinished = true;
                    return;
                }
            }
            passwordFinished = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox4.PasswordChar == '*')
                textBox4.PasswordChar = '\0';
            else
                textBox4.PasswordChar = '*';
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
