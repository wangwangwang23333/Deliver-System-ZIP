﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Runtime.InteropServices;

namespace 顾客系统
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        #region 无边框拖动效果
        [DllImport("user32.dll")]//拖动无窗体的控件
        public static extern bool ReleaseCapture();
        [DllImport("user32.dll")]
        public static extern bool SendMessage(IntPtr hwnd, int wMsg, int wParam, int lParam);
        public const int WM_SYSCOMMAND = 0x0112;
        public const int SC_MOVE = 0xF010;
        public const int HTCAPTION = 0x0002;

        private void Start_MouseDown(object sender, MouseEventArgs e)
        {
            //拖动窗体
            ReleaseCapture();
            SendMessage(this.Handle, WM_SYSCOMMAND, SC_MOVE + HTCAPTION, 0);
        }
        #endregion


        private void Form1_Load(object sender, EventArgs e)
        {
            label4.Parent = pictureBox2;
            pictureBox1.Parent = pictureBox2;

            //读取登陆过的账号信息
            StreamReader sr = new StreamReader("uername.txt");
            while (sr.Peek() != -1)
            {
                comboBox1.Items.Add(sr.ReadLine());
            }
            sr.Close();

            //comboBox默认取最后一次登录信息
            StreamReader sr2 = new StreamReader("defaultLog.txt");
            while (sr2.Peek() != -1)
            {
                comboBox1.Text = sr2.ReadLine();
                //查看defaulLog是否有默认密码
                try
                {
                    StreamReader sr3 = new StreamReader("user" + comboBox1.Text + ".txt");
                    string userPassword = sr3.ReadLine();
                    if (userPassword != "null")
                    //非null，表示有密码
                    {
                        textBox2.Text = userPassword;
                        //如果到这里都正常，说明默认选择勾选了记住密码
                        checkBox2.Checked = true;
                    }
                    sr3.Close();
                }
                catch (Exception) { };
            }
            sr2.Close();
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            //淡出系统
            if (this.Opacity >= 0.025)
                this.Opacity -= 0.025;
            else
            {
                timer.Stop();
                this.Close();
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            timer.Start();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            string id = comboBox1.Text;
            string passWord = textBox2.Text;
            string selectStr = "";
            string cID = "";
            if (id[0] == 'c')
            {
                //账号登陆;
                selectStr = "select customer_passWord,customer_status,customer_id from customer where customer_id='" + id + "'";
            }
            else if (id.Length == 11)
            {
                //末尾手机号;
                selectStr = "select customer_passWord,customer_status,customer_id from customer where right(customer_phone,11)='" + id + "'";
            }
            else
            {
                selectStr = "select customer_passWord,customer_status,customer_id from customer where customer_phone='" + id + "'";
            }

            const string mystr = "Initial Catalog = take_out;Data Source = (local);Integrated Security = True;";
            SqlConnection myconn = new SqlConnection(mystr);

            SqlCommand myCmd = new SqlCommand(selectStr, myconn);

            string newPassWord;
            string status;
            //打开数据库连接
            myconn.Open();
            SqlDataReader myreader = myCmd.ExecuteReader();
            try
            {
                //读取数据
                myreader.Read();
                newPassWord = myreader.GetString(0);
                status = myreader.GetString(1);
                cID = myreader.GetString(2);
            }
            catch (Exception)
            {
                MessageBox.Show("不存在此用户,请检查账号重新输入,谢谢!");
                textBox2.Clear();
                return;
            }
            myreader.Close();

            string userName = comboBox1.Text;

            //先读一读看看是不是这个账号以前存过
            StreamReader srs = new StreamReader("uername.txt");
            bool exists = false;
            while (srs.Peek() != -1)
            {
                if (srs.ReadLine() == userName)
                {
                    exists = true;
                    break;
                }
            }
            srs.Close();
            if (exists == false)
            {
                StreamWriter sw = new StreamWriter("uername.txt", true);
                sw.WriteLine(userName);
                sw.Close();
            }

            StreamWriter sw2 = new StreamWriter("defaultLog.txt", false);
            sw2.WriteLine(userName);
            sw2.Close();

            if (checkBox2.Checked == true)
            {
                //选择了记住密码,写入
                StreamWriter sw3 = new StreamWriter("user" + userName + ".txt", false);
                sw3.WriteLine(textBox2.Text);
                sw3.Close();
            }
            else
            {
                StreamWriter sw3 = new StreamWriter("user" + userName + ".txt", false);
                sw3.WriteLine("null");
                sw3.Close();
            }

            if (passWord != newPassWord)
            {
                MessageBox.Show("密码不正确,请重新输入!");
                textBox2.Clear();
                return;
            }

            if (status == "a")
            {
                MessageBox.Show("用户你好,您目前正处于账号封禁状态,请及时与管理员联系清楚原因,谢谢您的配合!");
                textBox2.Clear();
                return;
            }



            订餐界面 fp1 = new 订餐界面(cID);
            this.Hide();
            fp1.ShowDialog();
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            顾客注册 fp2 = new 顾客注册();
            this.Hide();
            fp2.Owner = this;
            fp2.ShowDialog();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            忘记密码 fp = new 忘记密码();
            fp.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox2.PasswordChar == '●')
            {
                textBox2.PasswordChar = '\0';
                button3.Image = Image.FromFile("yanjingzheng.png");
            }
            else
            {
                textBox2.PasswordChar = '●';
                button3.Image = Image.FromFile("yanjingbi.png");
            }
        }
    }
}
