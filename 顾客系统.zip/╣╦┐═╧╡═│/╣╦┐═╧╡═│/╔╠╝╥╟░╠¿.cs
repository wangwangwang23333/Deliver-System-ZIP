﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Runtime.InteropServices;

namespace 顾客系统
{
    public partial class 商家前台 : Form
    {
        static string resID="";
        public 商家前台(string id)
        {
            resID=id;
            InitializeComponent();
        }
        static string mystr = "Initial Catalog = take_out;Data Source = (local);Integrated Security = True;";
        static SqlConnection myconn=new SqlConnection(mystr);

        #region 无边框拖动效果
        [DllImport("user32.dll")]//拖动无窗体的控件
        public static extern bool ReleaseCapture();
        [DllImport("user32.dll")]
        public static extern bool SendMessage(IntPtr hwnd, int wMsg, int wParam, int lParam);
        public const int WM_SYSCOMMAND = 0x0112;
        public const int SC_MOVE = 0xF010;
        public const int HTCAPTION = 0x0002;

        private void Start_MouseDown(object sender, MouseEventArgs e)
        {
            //拖动窗体
            ReleaseCapture();
            SendMessage(this.Handle, WM_SYSCOMMAND, SC_MOVE + HTCAPTION, 0);
        }
        #endregion

        private void 商家前台_Load(object sender, EventArgs e)
        {
            全部菜品.AutoScroll=true;
            当前已点.AutoScroll=true;
            商家评价.AutoScroll=true;
            string str1="select restaurant_name from restaurant where restaurant_id='"+resID+"'";
            string str2="select * from dish where restaurant_id='"+resID+"'";
            SqlCommand myCmd=new SqlCommand(str1,myconn);

            myconn.Open();

            SqlDataReader myreader=myCmd.ExecuteReader();
            myreader.Read();
            label1.Text=myreader.GetString(0)+",欢迎你的到来!";
            myreader.Close();

            myCmd.CommandText=str2;
            myreader=myCmd.ExecuteReader();
            try
            {
                int index = 0;
                while (myreader.Read())
                {
                    //利用new操作生成一个窗体
                    Panel panel = new Panel();
                    panel.Size = new Size(430, 100);
                    panel.Location = new Point(5, 5 * (index + 1) + 100 * index);
                    panel.BackColor = Color.LightGray;

                    //添加菜的id
                    //向panel中添加信息
                    Label dishID = new Label();
                    dishID.Text = "菜品编号:" + myreader.GetString(1);
                    dishID.Location = new Point(5, 5);
                    dishID.AutoSize = true;
                    panel.Name=myreader.GetString(1);
                    panel.Controls.Add(dishID);


                    //菜品名字;
                    Label dishName = new Label();
                    dishName.Text = "菜品名称:" + myreader.GetString(2);
                    dishName.Location = new Point(5, 30);
                    dishName.AutoSize = true;
                    panel.Controls.Add(dishName);

                    //菜品价格;
                    Label dishPrice = new Label();
                    dishPrice.Text = "菜品价格:" + myreader.GetValue(3).ToString()+" 元";
                    dishPrice.AutoSize = true;
                    dishPrice.Location = new Point(5, 55);
                    panel.Controls.Add(dishPrice);

                    //菜品图片;
                    string ImageFile = myreader.GetValue(4).ToString();
                    if (ImageFile == "")
                        ImageFile = "1.jpg";
                    Image dishFile = Image.FromFile(ImageFile);
                    PictureBox dishImage = new PictureBox();
                    dishImage.Image = dishFile;
                    dishImage.Location = new Point(200, 5);
                    dishImage.Size = new Size(100, 80);
                    dishImage.SizeMode = PictureBoxSizeMode.Zoom;
                    panel.Controls.Add(dishImage);

                    //菜品简介;
                    string dishIntro = "菜品简介:\n" + myreader.GetString(5);
                    ToolTip t1=new ToolTip();
                    t1.SetToolTip(panel,dishIntro);


                    //增加TextBox 表示点餐的数量;
                    TextBox numBox = new TextBox();
                    numBox.Text = "0";
                    numBox.ReadOnly = true;
                    numBox.Location = new Point(352, 47);
                    numBox.Size = new Size(40, 25);
                    numBox.TextAlign = HorizontalAlignment.Center;
                    numBox.Name=panel.Name+"textBox";
                    panel.Controls.Add(numBox);

                    //添加减少按钮 
                    Button subtractButton=new Button();
                    subtractButton.Size=new Size(25,25);
                    subtractButton.Location=new Point(320,45);
                    subtractButton.Image=Image.FromFile("jian.jpg");
                    subtractButton.Name=panel.Name+"Button";

                    subtractButton.Click += new System.EventHandler(subtractClick);
                    panel.Controls.Add(subtractButton);

                    //增加按钮;
                    Button addButton = new Button();
                    addButton.Size = new Size(25, 25);
                    addButton.Location = new Point(400, 45);
                    addButton.Image = Image.FromFile("jia.jpg");
                    addButton.Name=panel.Name+"Button";
                    addButton.Click += new System.EventHandler(addClick);
                    panel.Controls.Add(addButton);

                    index++;
                    全部菜品.Controls.Add(panel);
                }
            }
            catch (Exception) { };

            myreader.Close();
            myconn.Close();

           
            //评价功能;

            string evaluationStr="select orders_comment,orders_score from orders where restaurant_id='"+resID+"'";
            myCmd.CommandText=evaluationStr;
            myconn.Open();
            myreader=myCmd.ExecuteReader();
            try
            {
                int index=0;
                while (myreader.Read())
                {
                    string evaluation;
                    try
                    {
                        evaluation = myreader.GetString(0);
                    }
                    catch (Exception) { continue; }
                    //利用new操作生成一个窗体
                    Panel panel = new Panel();
                    panel.Size = new Size(440, 100);
                    panel.Location = new Point(5, 5 * (index + 1) + 100 * index);
                    panel.BackColor = Color.LightGray;

                    //信息
                    Label score = new Label();
                    score.Text = "评分:" + myreader.GetValue(1).ToString();
                    score.AutoSize = true;
                    score.Location = new Point(5, 5);
                    panel.Controls.Add(score);

                    //评价;
                    TextBox resEvaluation = new TextBox();
                    resEvaluation.ReadOnly=true;
                    resEvaluation.Multiline = true;
                    resEvaluation.Text = "评价信息:" + evaluation;
                    resEvaluation.Location = new Point(5, 30);
                    resEvaluation.Size=new Size(340,60);
                    resEvaluation.ScrollBars=ScrollBars.Vertical;
                    panel.Controls.Add(resEvaluation);

                    商家评价.Controls.Add(panel);
                    index++;
                }
            }
            catch (Exception) { };
            myreader.Close();
            myconn.Close();
        }
        static int panelNum=0;
        public static string allPrice="";
        private void addClick(object sender,EventArgs e)
        {
            Button button=(Button)sender;
            string textBox=(button.Name).Substring(0,6)+"textBox";
            string text=((TextBox)(this.Controls.Find(textBox,true)[0])).Text;
            string text1;
            text1 = (int.Parse(text) + 1).ToString();
            ((TextBox)(this.Controls.Find(textBox, true)[0])).Text=text1;

            string select1="select * from dish where dish_id='"+(button.Name).Substring(0,6)+"'";
            SqlCommand mycmd=new SqlCommand(select1,myconn);           
            myconn.Open();
            SqlDataReader myreader=mycmd.ExecuteReader();
            try
            {
                myreader.Read();
                if (int.Parse(text) != 0)
                {
                    string panelStr=myreader.GetString(1)+"My";
                    Panel myPanel=(Panel)(this.Controls.Find(panelStr,true)[0]);
                    
                    //寻找 金额 和 数量 修改;
                    string priceStr=(float.Parse(myreader.GetValue(3).ToString()) * int.Parse(text1)).ToString();
                    ((Label)(myPanel.Controls.Find("numLabel",true)[0])).Text = " 数量: "+text1;
                    ((Label)(myPanel.Controls.Find("priceLabel", true)[0])).Text = "金额: "+priceStr;

                    if (allPrice == "")
                    {
                        allPrice=priceStr;
                    }
                    else
                    {
                        allPrice = (float.Parse(allPrice)+float.Parse(myreader.GetValue(3).ToString())).ToString();
                    }
                }
                else
                {
                    //利用new操作生成一个窗体
                    Panel panel = new Panel();
                    panel.Size = new Size(600, 100);
                    panel.Location = new Point(5, 5 * (panelNum + 1) + 100 * panelNum);
                    panel.BackColor = Color.LightGray;

                    //向panel中添加信息
                    Label dishID = new Label();
                    dishID.Text = "菜品编号:" + myreader.GetString(1);
                    dishID.Location = new Point(5, 5);
                    panel.Name = myreader.GetString(1) + "My";
                    dishID.Name="dishID";
                    panel.Controls.Add(dishID);

                    
                    Label dishName = new Label();
                    dishName.Text = "菜品名称:" + myreader.GetString(2);
                    dishName.Location = new Point(5, 30);
                    dishName.AutoSize = true;
                    dishName.Name="dishName";
                    panel.Controls.Add(dishName);

                    //菜品价格;
                    Label dishPrice = new Label();
                    dishPrice.Text = "菜品价格:" + myreader.GetValue(3).ToString() + " 元";
                    dishPrice.Location = new Point(5, 55);
                    panel.Controls.Add(dishPrice);

                    //菜品图片;
                    string ImageFile = myreader.GetString(4);
                    if (ImageFile == "")
                        ImageFile = "1.jpg";
                    Image dishFile = Image.FromFile(ImageFile);
                    PictureBox dishImage = new PictureBox();
                    dishImage.Image = dishFile;
                    dishImage.Location = new Point(200, 5);
                    dishImage.Size = new Size(100, 80);
                    dishImage.SizeMode = PictureBoxSizeMode.Zoom;
                    panel.Controls.Add(dishImage);

                    //菜品简介;
                    string dishIntro = "菜品简介:\r\n" + myreader.GetString(5);
                    ToolTip t1 = new ToolTip();
                    t1.SetToolTip(panel, dishIntro);

                    //数量
                    string num = "数量: " + text1;
                    Label numLabel = new Label();
                    numLabel.Text = num;
                    numLabel.Location = new Point(320, 40);
                    numLabel.AutoSize = true;
                    numLabel.Name="numLabel";
                    panel.Controls.Add(numLabel);

                    //金额;
                    float Allprice = float.Parse(myreader.GetValue(3).ToString()) * int.Parse(text1);
                    string priceAll = "金额： " + Allprice.ToString();
                    Label priceLabel = new Label();
                    priceLabel.Text = priceAll;
                    priceLabel.Location = new Point(320, 65);
                    priceLabel.AutoSize = true;
                    priceLabel.Name="priceLabel";
                    panel.Controls.Add(priceLabel);

                    当前已点.Controls.Add(panel);
                    panelNum++;

                    if (allPrice == "")
                    {
                        allPrice = myreader.GetValue(3).ToString();
                    }
                    else
                    {
                        allPrice = (float.Parse(allPrice) + float.Parse(myreader.GetValue(3).ToString())).ToString();
                    }
                }               

            }
            catch (Exception) { };
            myconn.Close();

            label2.Text = "当前商品总金额为: " + allPrice + " 元";

        }
        private void subtractClick(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            string textBox = (button.Name).Substring(0, 6) + "textBox";
            string text = ((TextBox)(this.Controls.Find(textBox, true)[0])).Text;
            string text1;
            if (text=="0")
            {
                return;
            }
            text1 = (int.Parse(text) - 1).ToString();
            ((TextBox)(this.Controls.Find(textBox, true)[0])).Text = text1;

            string select1 = "select * from dish where dish_id='" + (button.Name).Substring(0, 6) + "'";
            SqlCommand mycmd = new SqlCommand(select1, myconn);
            myconn.Open();
            SqlDataReader myreader = mycmd.ExecuteReader();
            try
            {
                myreader.Read();
                string panelStr = myreader.GetString(1) + "My";
                Panel myPanel = (Panel)(this.Controls.Find(panelStr, true)[0]);

                //寻找 金额 和 数量 修改;
                string priceStr = (float.Parse(myreader.GetValue(3).ToString()) * int.Parse(text1)).ToString();
                ((Label)(myPanel.Controls.Find("numLabel", true)[0])).Text = " 数量: " + text1;
                ((Label)(myPanel.Controls.Find("priceLabel", true)[0])).Text = "金额: " + priceStr;
                if (text1 == "0")
                {
                    panelNum--;
                    当前已点.Controls.Remove(myPanel);
                    for(int i = 0; i < 当前已点.Controls.Count; i++){
                        当前已点.Controls[i].Location= new Point(5, 5 * (i + 1) + 100 * i);
                    }
                }

                allPrice = (float.Parse(allPrice) - float.Parse(myreader.GetValue(3).ToString())).ToString();
            }
            catch (Exception) { };
            myconn.Close();

            label2.Text = "当前商品总金额为: " + allPrice + " 元";
        }

        public static string information="";
        private void 商家前台_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (has_preserve == true)
            {
                return;

            }
            DialogResult result = MessageBox.Show("确认退出该店吗,已点商品以加入~！", "提示信息", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
            if (result == DialogResult.OK)
            {
                e.Cancel = false; 
                panelNum=0;
                information="商家ID:"+resID+"\r\n,已点内容:\r\n";
                for(int i=0; i < 当前已点.Controls.Count; i++)
                {
                    Panel curpanel=(Panel)当前已点.Controls[i];
                    string curID = ((Label)(curpanel.Controls.Find("dishID", true)[0])).Text;
                    string curName = ((Label)(curpanel.Controls.Find("dishName", true)[0])).Text;
                    string curNum= ((Label)(curpanel.Controls.Find("numLabel", true)[0])).Text;
                    string curPrice= ((Label)(curpanel.Controls.Find("priceLabel", true)[0])).Text;
                    information+=curID+" -"+curName+" -"+curNum+"份 -"+curPrice+"元每份\r\n";
                }
                information+=","+label2.Text+"\r\n";
            }
            else
            {
                e.Cancel = true;
            }
            
        }
        static bool has_preserve=false;
        private void button1_Click(object sender, EventArgs e)
        {
            panelNum = 0;
            information = "商家ID:" + resID + "\r\n,已点内容:\r\n";
            for (int i = 0; i < 当前已点.Controls.Count; i++)
            {
                Panel curpanel = (Panel)当前已点.Controls[i];
                string curID = ((Label)(curpanel.Controls.Find("dishID", true)[0])).Text;
                string curName = ((Label)(curpanel.Controls.Find("dishName", true)[0])).Text;
                string curNum = ((Label)(curpanel.Controls.Find("numLabel", true)[0])).Text;
                string curPrice = ((Label)(curpanel.Controls.Find("priceLabel", true)[0])).Text;
                information += curID + " -" + curName + " -" + curNum + "份 -" + curPrice + "元每份\r\n";
            }
            information += "," + label2.Text + "\r\n";
            MessageBox.Show("保存成功!");
            has_preserve=true;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
