﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Runtime.InteropServices;

namespace 顾客系统
{
    public partial class 订餐界面 : Form
    {
        public string myID;       
        public 订餐界面(string ID)
        {
            myID=ID;
            InitializeComponent();
        }
        static string mystr = "Initial Catalog = take_out;Data Source = (local);Integrated Security = True;";

        #region 无边框拖动效果
        [DllImport("user32.dll")]//拖动无窗体的控件
        public static extern bool ReleaseCapture();
        [DllImport("user32.dll")]
        public static extern bool SendMessage(IntPtr hwnd, int wMsg, int wParam, int lParam);
        public const int WM_SYSCOMMAND = 0x0112;
        public const int SC_MOVE = 0xF010;
        public const int HTCAPTION = 0x0002;

        private void Start_MouseDown(object sender, MouseEventArgs e)
        {
            //拖动窗体
            ReleaseCapture();
            SendMessage(this.Handle, WM_SYSCOMMAND, SC_MOVE + HTCAPTION, 0);
        }
        #endregion

        private void 订餐界面_Load(object sender, EventArgs e)
        {
            SqlConnection myconn=new SqlConnection(mystr);

            string selectStr="exec RestaurantNow";
            SqlCommand myCmd=new SqlCommand(selectStr,myconn);
            myconn.Open();
            SqlDataReader myreader = myCmd.ExecuteReader();
            try
            {
                int index = 0;
                while (myreader.Read())
                {
                    //利用new操作生成一个窗体
                    Panel panel = new Panel();
                    panel.Size = new Size(500, 100);
                    panel.Location = new Point(5, 5 * (index + 1) + 100 * index );
                    panel.BackColor = Color.LightGray;
                    panel.Click+=new System.EventHandler(panelClick);
                        
                    //向panel中添加信息
                    Label restaurantID = new Label();
                    restaurantID.Text = "商家编号:" + myreader.GetString(0);
                    restaurantID.Location = new Point(5, 5);
                    panel.Name=myreader.GetString(0);
                    panel.Controls.Add(restaurantID);

                    //商家名字;
                    Label restaurantName = new Label();
                    restaurantName.Text = "商家名称:" + myreader.GetString(1);
                    restaurantName.Location = new Point(5, 30);
                    panel.Controls.Add(restaurantName);

                    ToolTip t=new ToolTip();
                    t.SetToolTip(panel, "商家简介:\n" + myreader.GetString(3));

                    //电话;
                    Label restaurantPhone = new Label();
                    restaurantPhone.Text = "商家电话:" + myreader.GetString(4);
                    restaurantPhone.AutoSize=true;
                    restaurantPhone.Location = new Point(120, 5);
                    panel.Controls.Add(restaurantPhone);

                    //营业时间;
                    Label restaurantTime = new Label();
                    restaurantTime.Text = "商家营业时间:" + myreader.GetString(5) + '-' + myreader.GetString(6);
                    restaurantTime.AutoSize=true;
                    restaurantTime.Location = new Point(120, 30);
                    panel.Controls.Add(restaurantTime);

                    //商家地址;
                    Label restaurantAddress = new Label();
                    restaurantAddress.Text = "商家地址:" + myreader.GetString(7);
                    restaurantAddress.AutoSize=true;
                    restaurantAddress.Location = new Point(120, 55);
                    panel.Controls.Add(restaurantAddress);

                    //配送费;
                    Label restaurantFee = new Label();
                    restaurantFee.Text = "商家配送费:" + myreader.GetValue(8).ToString()+"元";
                    restaurantFee.Location = new Point(300, 30);
                    panel.Controls.Add(restaurantFee);

                    //图片;

                    string imageFile = myreader.GetString(9);
                    if (imageFile == "")
                        imageFile = "1.jpg";
                    //string imageFile="1.jpg";
                    Image restaurantImageFile = Image.FromFile(imageFile);
                    PictureBox restaurantImage = new PictureBox();
                    restaurantImage.Image = restaurantImageFile;
                    restaurantImage.Location = new Point(390, 5);
                    restaurantImage.Size = new Size(100, 80);
                    restaurantImage.SizeMode=PictureBoxSizeMode.Zoom;
                    panel.Controls.Add(restaurantImage);
                    
                    //评分;
                    Label restaurantScore = new Label();
                    restaurantScore.Text = "商家评分:" + myreader.GetValue(10).ToString();
                    restaurantScore.Location = new Point(300, 5);
                    panel.Controls.Add(restaurantScore);


                    index++;
                    挑选美食.Controls.Add(panel);
                }
                挑选美食.AutoScroll=true;
            }
            catch (Exception) { };

            myreader.Close();
            myconn.Close();

//--个人信息--------------------------------------------------------------------------------------------------//


            
            string selectStr2="select * from customer where customer_id='"+myID+"'";
            myCmd.CommandText=selectStr2;
            myconn.Open();
            myreader=myCmd.ExecuteReader();
            try
            {
                while (myreader.Read())
                {
                    textBox1.Text=myreader.GetString(0);
                    textBox2.Text=myreader.GetString(1);
                    textBox3.Text=myreader.GetString(2);
                    textBox4.Text=myreader.GetString(4);
                    textBox5.Text=myreader.GetValue(5).ToString();
                    
                    if (myreader.GetValue(6).ToString() != "")
                    {
                        pictureBox1.Image=Image.FromFile(myreader.GetValue(6).ToString());
                    }
                    else
                    {
                        pictureBox1.Image=Image.FromFile("1.jpg");
                    }
                    

                }
            }
            catch (Exception) {  };
            myreader.Close();
            myconn.Close();


//--派送中订单--------------------------------------------------------------------------------------------------//
            myCmd = new SqlCommand("procOrdersA",myconn);
            myCmd.CommandType = CommandType.StoredProcedure;
            SqlParameter ID = new SqlParameter("@_customer_id", SqlDbType.Char, 6);
            SqlParameter status=new SqlParameter("@_status",SqlDbType.Char,1);
            myCmd.Parameters.Add(ID);
            myCmd.Parameters.Add(status);
            ID.Value=myID;
            status.Value='c';

            myconn.Open();
            myreader=myCmd.ExecuteReader();
            try
            {
                
                int index=0;
                while (myreader.Read())
                {
                    //利用new操作生成一个窗体
                    Panel panel = new Panel();
                    panel.Size = new Size(500, 100);
                    panel.Location = new Point(5, 5 * (index + 1) + 100 * index);
                    panel.BackColor = Color.LightGray;

                    //向panel中添加信息
                    Label orderID = new Label();
                    orderID.Text = "订单编号:" + myreader.GetString(0);
                    orderID.Location = new Point(5, 5);
                    orderID.AutoSize = true;
                    panel.Controls.Add(orderID);

                    //饭店名字;
                    Label restaurantName = new Label();
                    restaurantName.Text = "商家名称:" + myreader.GetString(1);
                    restaurantName.Location = new Point(5, 30);
                    restaurantName.AutoSize = true;
                    panel.Name = myreader.GetString(0) + "," + myreader.GetString(1);
                    panel.Controls.Add(restaurantName);

                    //派送员姓名
                    Label deliverGuyName = new Label();
                    deliverGuyName.AutoSize = true;
                    deliverGuyName.Text = "派送员姓名:" + myreader.GetString(2);
                    if (myreader.GetString(2) == "g09999")
                    {
                        deliverGuyName.Text= "派送员姓名: ***";
                    }
                    deliverGuyName.Location = new Point(5, 55);
                    panel.Controls.Add(deliverGuyName);

                    //起始地址
                    Label orderStartAddress = new Label();
                    orderStartAddress.Text = "起始地址:" + myreader.GetString(3);
                    orderStartAddress.Location = new Point(5, 80);
                    orderStartAddress.AutoSize=true;
                    panel.Controls.Add(orderStartAddress);

                    //终止地址
                    Label orderEndAddress = new Label();
                    orderEndAddress.Text = "目的地:" + myreader.GetString(4);
                    orderEndAddress.Location = new Point(230, 80);
                    orderEndAddress.AutoSize=true;
                    panel.Controls.Add(orderEndAddress);

                    //订单金额
                    Label orderMoney = new Label();
                    orderMoney.Text = "订单金额:" + myreader.GetValue(5).ToString()+"元";
                    orderMoney.Location = new Point(230, 5);
                    panel.Controls.Add(orderMoney);

                    //下单时间;
                    Label orderStartTime = new Label();
                    orderStartTime.Text = "下单时间:" + myreader.GetValue(6).ToString();
                    orderStartTime.AutoSize=true;
                    orderStartTime.Location = new Point(230, 30);
                    panel.Controls.Add(orderStartTime);

                    //预期时间;
                    Label orderReEndTime = new Label();
                    orderReEndTime.Text = "预期时间:" + myreader.GetValue(7).ToString();
                    orderReEndTime.AutoSize=true;
                    orderReEndTime.Location = new Point(230, 55);
                    panel.Controls.Add(orderReEndTime);

                    string info = myreader.GetString(8) + "\n订单备注:\n" + myreader.GetString(9);
                    ToolTip tp=new ToolTip();
                    tp.SetToolTip(panel,info);

                    

                    index++;
                    派送中.Controls.Add(panel);
                }
                派送中.AutoScroll=true;
            }
            
            catch (Exception) { };
            myreader.Close();
            myconn.Close();


 //--待支付订单--------------------------------------------------------------------------------------------------//
            myCmd = new SqlCommand("procOrdersA", myconn);
            myCmd.CommandType = CommandType.StoredProcedure;
            SqlParameter ID2 = new SqlParameter("@_customer_id", SqlDbType.Char, 6);
            SqlParameter status2 = new SqlParameter("@_status", SqlDbType.Char, 1);
            myCmd.Parameters.Add(ID2);
            myCmd.Parameters.Add(status2);
            ID2.Value = myID;
            status2.Value = 'e';

            myconn.Open();
            myreader = myCmd.ExecuteReader();
            try
            {
                int index = 0;
                while (myreader.Read())
                {
                    //利用new操作生成一个窗体
                    Panel panel = new Panel();
                    panel.Size = new Size(500, 100);
                    panel.Location = new Point(5, 5 * (index + 1) + 100 * index);
                    panel.BackColor = Color.LightGray;

                    //向panel中添加信息
                    Label orderID = new Label();
                    orderID.Text = "订单编号:" + myreader.GetString(0);
                    orderID.Location = new Point(5, 5);
                    orderID.AutoSize = true;
                    panel.Controls.Add(orderID);

                    //饭店名字;
                    Label restaurantName = new Label();
                    restaurantName.Text = "商家名称:" + myreader.GetString(1);
                    restaurantName.Location = new Point(5, 30);
                    restaurantName.AutoSize = true;
                    panel.Controls.Add(restaurantName);

                    //派送员姓名
                    Label deliverGuyName = new Label();
                    deliverGuyName.AutoSize = true;
                    deliverGuyName.Text = "派送员姓名:" + myreader.GetString(2);
                    if (myreader.GetString(2) == "虚拟")
                    {
                        deliverGuyName.Text = "派送员姓名: ***";
                    }
                    deliverGuyName.Location = new Point(5, 55);
                    panel.Controls.Add(deliverGuyName);

                    //起始地址
                    Label orderStartAddress = new Label();
                    orderStartAddress.Text = "起始地址:" + myreader.GetString(3);
                    orderStartAddress.Location = new Point(5, 80);
                    orderStartAddress.AutoSize = true;
                    panel.Controls.Add(orderStartAddress);

                    //终止地址
                    Label orderEndAddress = new Label();
                    orderEndAddress.Text = "目的地:" + myreader.GetString(4);
                    orderEndAddress.Location = new Point(230, 80);
                    orderEndAddress.AutoSize = true;

                    panel.Controls.Add(orderEndAddress);

                    //订单金额
                    Label orderMoney = new Label();
                    orderMoney.Text = "订单金额:" + myreader.GetValue(5).ToString() + "元";
                    orderMoney.Location = new Point(230, 5);
                    panel.Name = myreader.GetString(0) +","+ myreader.GetValue(5).ToString();
                    panel.Controls.Add(orderMoney);

                    //下单时间;
                    Label orderStartTime = new Label();
                    orderStartTime.Text = "下单时间:" + myreader.GetValue(6).ToString();
                    orderStartTime.AutoSize = true;
                    orderStartTime.Location = new Point(230, 30);
                    panel.Controls.Add(orderStartTime);

                    //预期时间;
                    Label orderReEndTime = new Label();
                    orderReEndTime.Text = "应到时间:" + myreader.GetValue(7).ToString();
                    orderReEndTime.AutoSize = true;
                    orderReEndTime.Location = new Point(230, 55);
                    panel.Controls.Add(orderReEndTime);

                    string info = myreader.GetString(8) + "\n订单备注:\n" + myreader.GetString(9);
                    ToolTip tp = new ToolTip();
                    tp.SetToolTip(panel, info);


                    panel.Click += new System.EventHandler(panelClick2);

                    index++;
                    待支付订单.Controls.Add(panel);
                }
                待支付订单.AutoScroll=true;
            }

            catch (Exception) { };
            myreader.Close();
            myconn.Close();


//--历史订单--------------------------------------------------------------------------------------------------//
            myCmd = new SqlCommand("procOrdersA", myconn);
            myCmd.CommandType = CommandType.StoredProcedure;
            SqlParameter ID3 = new SqlParameter("@_customer_id", SqlDbType.Char, 6);
            SqlParameter status3 = new SqlParameter("@_status", SqlDbType.Char, 1);
            myCmd.Parameters.Add(ID3);
            myCmd.Parameters.Add(status3);
            ID3.Value = myID;
            status3.Value = 'd';

            myconn.Open();
            myreader = myCmd.ExecuteReader();
            try
            {
                int index = 0;
                while (myreader.Read())
                {
                    //利用new操作生成一个窗体
                    Panel panel = new Panel();
                    panel.Size = new Size(500, 100);
                    panel.Location = new Point(5, 5 * (index + 1) + 100 * index);
                    panel.BackColor = Color.LightGray;
                    panel.Name = myreader.GetString(0) + "," + myreader.GetValue(5).ToString();

                    //向panel中添加信息
                    Label orderID = new Label();
                    orderID.Text = "订单编号:" + myreader.GetString(0);
                    orderID.Location = new Point(5, 5);
                    orderID.AutoSize = true;
                    panel.Controls.Add(orderID);

                    //饭店名字;
                    Label restaurantName = new Label();
                    restaurantName.Text = "商家名称:" + myreader.GetString(1);
                    restaurantName.Location = new Point(5, 30);
                    restaurantName.AutoSize = true;
                    panel.Controls.Add(restaurantName);

                    //派送员姓名
                    Label deliverGuyName = new Label();
                    deliverGuyName.AutoSize = true;
                    deliverGuyName.Text = "派送员姓名:" + myreader.GetString(2);
                    if (myreader.GetString(2) == "g09999")
                    {
                        deliverGuyName.Text = "派送员姓名: ***";
                    }
                    deliverGuyName.Location = new Point(5, 55);
                    panel.Controls.Add(deliverGuyName);

                    //起始地址
                    Label orderStartAddress = new Label();
                    orderStartAddress.Text = "起始地址:" + myreader.GetString(3);
                    orderStartAddress.Location = new Point(5, 80);
                    orderStartAddress.AutoSize = true;
                    panel.Controls.Add(orderStartAddress);

                    //终止地址
                    Label orderEndAddress = new Label();
                    orderEndAddress.Text = "目的地:" + myreader.GetString(4);
                    orderEndAddress.Location = new Point(230, 80);
                    orderEndAddress.AutoSize = true;
                    panel.Controls.Add(orderEndAddress);

                    //订单金额
                    Label orderMoney = new Label();
                    orderMoney.Text = "订单金额:" + myreader.GetValue(5).ToString() + "元";
                    orderMoney.Location = new Point(230, 5);
                    panel.Controls.Add(orderMoney);

                    //下单时间;
                    Label orderStartTime = new Label();
                    orderStartTime.Text = "下单时间:" + myreader.GetValue(6).ToString();
                    orderStartTime.AutoSize = true;
                    orderStartTime.Location = new Point(230, 30);
                    panel.Controls.Add(orderStartTime);

                    //预期时间;
                    Label orderReEndTime = new Label();
                    orderReEndTime.Text = "应到时间:" + myreader.GetValue(7).ToString();
                    orderReEndTime.AutoSize = true;
                    orderReEndTime.Location = new Point(230, 55);
                    panel.Controls.Add(orderReEndTime);



                    string info = myreader.GetString(8) +"\n订单备注:\n"+ myreader.GetString(9);
                    ToolTip tp = new ToolTip();
                    tp.SetToolTip(panel, info);

                    panel.Click += new System.EventHandler(panelClick3);
                    index++;
                    历史订单.Controls.Add(panel);
                }
                历史订单.AutoScroll=true;
            }

            catch (Exception) { };
            myreader.Close();
            myconn.Close();


//--未接取订单--------------------------------------------------------------------------------------------------//
            myCmd = new SqlCommand("procOrdersA", myconn);
            myCmd.CommandType = CommandType.StoredProcedure;
            SqlParameter ID4 = new SqlParameter("@_customer_id", SqlDbType.Char, 6);
            SqlParameter status4 = new SqlParameter("@_status", SqlDbType.Char, 1);
            myCmd.Parameters.Add(ID4);
            myCmd.Parameters.Add(status4);
            ID4.Value = myID;
            status4.Value = 'a';

            myconn.Open();
            myreader = myCmd.ExecuteReader();
            try
            {
                int index = 0;
                while (myreader.Read())
                {
                    //利用new操作生成一个窗体
                    Panel panel = new Panel();
                    panel.Size = new Size(500, 100);
                    panel.Location = new Point(5, 5 * (index + 1) + 100 * index);
                    panel.BackColor = Color.LightGray;

                    //向panel中添加信息
                    Label orderID = new Label();
                    orderID.Text = "订单编号:" + myreader.GetString(0);
                    orderID.Location = new Point(5, 5);
                    orderID.AutoSize = true;
                    panel.Controls.Add(orderID);

                    //饭店名字;
                    Label restaurantName = new Label();
                    restaurantName.Text = "商家名称:" + myreader.GetString(1);
                    restaurantName.Location = new Point(5, 30);
                    restaurantName.AutoSize = true;
                    panel.Controls.Add(restaurantName);

                    //派送员姓名
                    Label deliverGuyName = new Label();
                    deliverGuyName.AutoSize = true;
                    deliverGuyName.Text = "派送员姓名:" + myreader.GetString(2);
                    if (myreader.GetString(2) == "虚拟")
                    {
                        deliverGuyName.Text = "派送员姓名: ***";
                    }
                    deliverGuyName.Location = new Point(5, 55);
                    panel.Controls.Add(deliverGuyName);

                    //起始地址
                    Label orderStartAddress = new Label();
                    orderStartAddress.Text = "起始地址:" + myreader.GetString(3);
                    orderStartAddress.Location = new Point(5, 80);
                    orderStartAddress.AutoSize = true;
                    panel.Controls.Add(orderStartAddress);

                    //终止地址
                    Label orderEndAddress = new Label();
                    orderEndAddress.Text = "目的地:" + myreader.GetString(4);
                    orderEndAddress.Location = new Point(230, 80);
                    orderEndAddress.AutoSize = true;
                    panel.Controls.Add(orderEndAddress);

                    //订单金额
                    Label orderMoney = new Label();
                    orderMoney.Text = "订单金额:" + myreader.GetValue(5).ToString() + "元";
                    orderMoney.Location = new Point(230, 5);
                    panel.Controls.Add(orderMoney);

                    //下单时间;
                    Label orderStartTime = new Label();
                    orderStartTime.Text = "下单时间:" + myreader.GetValue(6).ToString();
                    orderStartTime.AutoSize = true;
                    orderStartTime.Location = new Point(230, 30);
                    panel.Controls.Add(orderStartTime);

                    //预期时间;
                    Label orderReEndTime = new Label();
                    orderReEndTime.Text = "应到时间:" + myreader.GetValue(7).ToString();
                    orderReEndTime.AutoSize = true;
                    orderReEndTime.Location = new Point(230, 55);
                    panel.Controls.Add(orderReEndTime);



                    string info = myreader.GetString(8) + "\n订单备注:\n" + myreader.GetString(9);
                    ToolTip tp = new ToolTip();
                    tp.SetToolTip(panel, info);


                    index++;
                    未接取订单.Controls.Add(panel);
                }
                未接取订单.AutoScroll = true;
            }

            catch (Exception) { };
            myreader.Close();
            myconn.Close();

//--未派送订单--------------------------------------------------------------------------------------------------//
            myCmd = new SqlCommand("procOrdersA", myconn);
            myCmd.CommandType = CommandType.StoredProcedure;
            SqlParameter ID5 = new SqlParameter("@_customer_id", SqlDbType.Char, 6);
            SqlParameter status5 = new SqlParameter("@_status", SqlDbType.Char, 1);
            myCmd.Parameters.Add(ID5);
            myCmd.Parameters.Add(status5);
            ID5.Value = myID;
            status5.Value = 'b';

            myconn.Open();
            myreader = myCmd.ExecuteReader();
            try
            {
                int index = 0;
                while (myreader.Read())
                {
                    //利用new操作生成一个窗体
                    Panel panel = new Panel();
                    panel.Size = new Size(500, 100);
                    panel.Location = new Point(5, 5 * (index + 1) + 100 * index);
                    panel.BackColor = Color.LightGray;

                    //向panel中添加信息
                    Label orderID = new Label();
                    orderID.Text = "订单编号:" + myreader.GetString(0);
                    orderID.Location = new Point(5, 5);
                    orderID.AutoSize = true;
                    panel.Controls.Add(orderID);

                    //饭店名字;
                    Label restaurantName = new Label();
                    restaurantName.Text = "商家名称:" + myreader.GetString(1);
                    restaurantName.Location = new Point(5, 30);
                    restaurantName.AutoSize=true;
                    panel.Controls.Add(restaurantName);

                    //派送员姓名
                    Label deliverGuyName = new Label();
                    deliverGuyName.Text = "派送员姓名:" + myreader.GetString(2);
                    if (myreader.GetString(2) == "虚拟")
                    {
                        deliverGuyName.Text = "派送员姓名: ***";
                    }
                    deliverGuyName.Location = new Point(5, 55);
                    panel.Controls.Add(deliverGuyName);

                    //起始地址
                    Label orderStartAddress = new Label();
                    orderStartAddress.Text = "起始地址:" + myreader.GetString(3);
                    orderStartAddress.Location = new Point(5, 80);
                    orderStartAddress.AutoSize = true;
                    panel.Controls.Add(orderStartAddress);

                    //终止地址
                    Label orderEndAddress = new Label();
                    orderEndAddress.Text = "目的地:" + myreader.GetString(4);
                    orderEndAddress.Location = new Point(230, 80);
                    orderEndAddress.AutoSize = true;
                    panel.Controls.Add(orderEndAddress);

                    //订单金额
                    Label orderMoney = new Label();
                    orderMoney.Text = "订单金额:" + myreader.GetValue(5).ToString() + "元";
                    orderMoney.Location = new Point(230, 5);
                    panel.Controls.Add(orderMoney);

                    //下单时间;
                    Label orderStartTime = new Label();
                    orderStartTime.Text = "下单时间:" + myreader.GetValue(6).ToString();
                    orderStartTime.AutoSize = true;
                    orderStartTime.Location = new Point(230, 30);
                    panel.Controls.Add(orderStartTime);

                    //预期时间;
                    Label orderReEndTime = new Label();
                    orderReEndTime.Text = "应到时间:" + myreader.GetValue(7).ToString();
                    orderReEndTime.AutoSize = true;
                    orderReEndTime.Location = new Point(230, 55);
                    panel.Controls.Add(orderReEndTime);



                    string info = myreader.GetString(8) + "\n订单备注:\n" + myreader.GetString(9);
                    ToolTip tp = new ToolTip();
                    tp.SetToolTip(panel, info);


                    index++;
                    未配送订单.Controls.Add(panel);
                }
                未配送订单.AutoScroll = true;
            }

            catch (Exception) { };
            myreader.Close();
            myconn.Close();
        }


//--修改个人信息--------------------------------------------------------------------------------------------------//
        public static bool flag_image_change=false;
        private void button1_Click(object sender, EventArgs e)
        {
            button2.Visible=true;
            button1.Visible=false;
            textBox2.ReadOnly = false;
            textBox3.ReadOnly = false;
            textBox4.ReadOnly = false;
            flag_image_change=true;        
        }

        private void button2_Click(object sender, EventArgs e)
        {
            button2.Visible = false;
            button1.Visible = true;
            textBox2.ReadOnly = true;
            textBox3.ReadOnly = true;
            textBox4.ReadOnly = true;
            flag_image_change = false;

            string id=textBox1.Text;
            string name=textBox2.Text;
            string phone=textBox3.Text;
            string address=textBox4.Text;
            

            //
            if (name == "")
            {
                MessageBox.Show("昵称不能为空!");
            }
            if (phone == "")
            {
                MessageBox.Show("电话不能为空！");
            }
            if (address == "")
            {
                MessageBox.Show("地址不能为空!");
            }
            //
            SqlConnection myconn = new SqlConnection(mystr);
            string check = "select customer_id from customer where customer_phone='" + phone + "'" + "and customer_id !='"
                + myID + "'";
            SqlCommand myCmd = new SqlCommand(check, myconn);
            myconn.Open();
            SqlDataReader myreader = myCmd.ExecuteReader();
            try
            {
                myreader.Read();
                myreader.GetString(0);
                myreader.Close();
                MessageBox.Show("当前电话号码已注册使用过");
                return;
            }
            catch (Exception) { };
            myconn.Close();
            //发送验证码;
            string update = "update customer set customer_name='" + name + "'," + "customer_phone='" + phone + "'," + "customer_address='"
                + address + "',"+"customer_image='"+ imageFile +"'"+" where customer_id='"+myID+"'";

            myCmd.CommandText = update;

            myconn.Open();
            try
            {
                myCmd.ExecuteNonQuery();
                MessageBox.Show("更新信息成功！");
            }
            catch (Exception) { };
            myconn.Close();
        }

//--点单界面~--------------------------------------------------------------------------------------------------//
        static int index_info=0;
        static string money="";
        private void panelClick(object sender,EventArgs e)
        {
           已选购美食.AutoScroll=true;
            string id=((Panel)sender).Name;
            商家前台 fp=new 商家前台(id);
            fp.ShowDialog();
            if (商家前台.information != "商家ID:"+id+"\r\n,已点内容:\r\n,当前商品总金额:  元\r\n")
            {
                //利用new操作生成一个窗体
                Panel panel = new Panel();
                panel.Size = new Size(600, 100);
                panel.Location = new Point(5, 5 * (index_info + 1) + 100 * index_info);
                panel.BackColor = Color.LightGray;

                TextBox orderInfo =new TextBox();
                orderInfo.Text=商家前台.information;
                orderInfo.ReadOnly=true;
                orderInfo.Location=new Point(5,5);
                orderInfo.Size=new Size(300,80);
                orderInfo.Multiline=true;
                orderInfo.ScrollBars=ScrollBars.Vertical;
                panel.Name=id+"panel"+index_info.ToString();
                
                panel.Controls.Add(orderInfo);

                panel.Click+=new System.EventHandler(panelClick4);

                已选购美食.Controls.Add(panel);
                index_info++;
                商家前台.information="";
                if (money == "")
                {
                    money=商家前台.allPrice;
                }
                else
                {
                    money=(float.Parse(money)+float.Parse(商家前台.allPrice)).ToString();
                }
                label7.Text="待支付金额为: "+money+" 元";
                商家前台.allPrice="";
            }
            
        }

        //--转化为订单功能!--------------------------------------------------------------------------------------------------//
        public static string orders_remarks ="";
        private void button3_Click(object sender, EventArgs e)
        {
            
            SqlConnection myconn=new SqlConnection(mystr);
            
            string select="select customer_address from customer where customer_id='"+
                myID+"'";
            string resAddress="",cusAddress="";
            SqlCommand myCmd=new SqlCommand(select,myconn);
            myconn.Open();
            SqlDataReader myreader=myCmd.ExecuteReader();
            myreader.Read();
            cusAddress=myreader.GetString(0);
            myreader.Close();
            myconn.Close();
    
            int i=0;
            
            for( ; i < 已选购美食.Controls.Count; i++)
            {
                Panel curpanel=(Panel)已选购美食.Controls[i];
                string restaurantID=curpanel.Name.Substring(0,6);
                string customerID=myID;
                //时间数据
                string orders_start_time=DateTime.Now.ToString();
                string orders_require_end_time=DateTime.Now.AddHours(1).ToString();
                
                //information 的截取;
                string[] info=curpanel.Controls[0].Text.Split(',');
                string moneyStr=info[2];
                string[] moneyArr=moneyStr.Split(' ');
                float money=float.Parse(moneyArr[1]);

                string orders_content=info[1];
                

                string select1 = "select restaurant_address,restaurant_delivery_fee from restaurant where restaurant_id='" +
                       restaurantID + "'";
                myCmd.CommandText=select1;
                myconn.Open();
                myreader=myCmd.ExecuteReader();
                myreader.Read();
                resAddress=myreader.GetString(0);
                money+=float.Parse(myreader.GetValue(1).ToString());
                myreader.Close();

                string maxId;
                string select2="select MAX(orders_id) from orders";
                myCmd.CommandText=select2;
                myreader=myCmd.ExecuteReader();
                try
                {
                    myreader.Read();
                    maxId = myreader.GetString(0);
                }
                catch (Exception) { maxId="o09999";}
                myreader.Close();
                maxId = "o" + (int.Parse(maxId.Substring(1)) + 1).ToString();

               string insert="insert into orders(orders_id,restaurant_id,customer_id,orders_start_address,"+
                    "orders_end_address,orders_money,orders_start_time,orders_require_end_time,orders_content,orders_remarks,"
                    +"deliverGuy_id,orders_status) values("+
                    "'"+maxId+"','"+restaurantID+"','"+customerID+"','"+resAddress+"','"+cusAddress+"',"+money+",'"+orders_start_time
                    +"','"+orders_require_end_time+"','"+orders_content+"','"+orders_remarks+"','"+"g09999"+"','"+"e"+"')";
                myCmd.CommandText=insert;
                try
                {
                    myCmd.ExecuteNonQuery();

                }
                catch (Exception) { };
                MessageBox.Show("订单全部添加完成,前往待支付界面查看并支付~");            
                已选购美食.Controls.Clear();
                orders_remarks="";
            }
            if (i == 0)
            {
                MessageBox.Show("没有需要处理成订单的操作!");
                return ;
            }
            money="";
            index_info = 0;
            i =0;
            this.reflushForm();
        }

        private void tabControl1_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            if (tabControl1.SelectedTab.Name == "已选购美食")
            {
                button3.Visible = true;
                label7.Visible = true;
            }
            else
            {
                button3.Visible = false;
                label7.Visible = false;
            }
        }
//--支付功能--------------------------------------------------------------------------------------------------//
        private void panelClick2(object sender, EventArgs e)
        {
            string text=((Panel)sender).Name;
            string []text2=text.Split(',');
            string orders_id=text2[0];
            float allmoney=float.Parse(text2[1]);

            string myMoney="";
            string select="select customer_money from customer where customer_id='"+myID+"'";
            SqlConnection myconn=new SqlConnection(mystr);
            SqlCommand myCmd=new SqlCommand(select,myconn);
            myconn.Open();
            SqlDataReader myreader=myCmd.ExecuteReader();
            myreader.Read();
            myMoney=myreader.GetValue(0).ToString();
            myreader.Close();
            myconn.Close();

            DialogResult result = MessageBox.Show("本次订单编号为:"+orders_id+
                ", 总金额为:"+allmoney.ToString()+",是否要付款?", "提示信息", 
                MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
            if (result == DialogResult.OK)
            {
                if (float.Parse(myMoney) < allmoney)
                {
                    MessageBox.Show("账户余额不足,请充值后再进行操作!");
                    return;
                }
                else
                {
                    float balance=float.Parse(myMoney)-allmoney;
                    string update1="update customer set customer_money="+balance+" where customer_id='"+myID+"'";
                    string update2="update orders set orders_status='a' where orders_id='"+orders_id+"'";
                    myCmd.CommandText=update1;
                    myconn.Open();
                    myCmd.ExecuteNonQuery();

                    myCmd.CommandText=update2;
                    myCmd.ExecuteNonQuery();
                    myconn.Close();

                    MessageBox.Show("支付成功!");                    
                }
            }
        }
//--评分完成订单--------------------------------------------------------------------------------------------------//
        private void panelClick3(object sender, EventArgs e)
        {
            string text=((Panel)sender).Name;
            string []text2=text.Split(',');
            string orders_id=text2[0];
            string restaurant_name=text2[1];

            SqlConnection myconn=new SqlConnection(mystr);
            string select1="select restaurant_id,deliverGuy_id from orders where orders_id='"+orders_id+"'";
            SqlCommand myCmd=new SqlCommand(select1,myconn);

            string rID="";
            string dID="";
            myconn.Open();
            SqlDataReader myreader=myCmd.ExecuteReader();
            try
            {
                myreader.Read();
                rID=myreader.GetString(0);
                dID=myreader.GetString(1);
            }
            catch (Exception) {  };

            评分界面 fp=new 评分界面(rID,dID,orders_id);
            fp.ShowDialog();


        }

        void reflushForm()
        {
            订餐界面 fp=new 订餐界面(myID);
            fp.Show();
            this.Close();
        }


        private void button4_Click(object sender, EventArgs e)
        {
            this.reflushForm();
            money = "";
            index_info = 0;
        }



        private string imageFile="";
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            if (flag_image_change == false)
            {
                return;
            }
            //默认路径
            openFileDialog1.InitialDirectory = "C:\\";
            //限制文件格式
            openFileDialog1.Filter = "*.png|*.jpg|*.jpeg|*.bmp";
            //选择文件
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                //设置图片
                imageFile = openFileDialog1.FileName;
                pictureBox1.Image = Image.FromFile(imageFile);
                //图片上传操作完成
             
            }
        }



        private void button5_Click(object sender, EventArgs e)
        {
            修改密码 fp=new 修改密码(myID);
            fp.ShowDialog();
        }

        static string remarks="";
        private void panelClick4(object sender, EventArgs e)
        {
            备注 fp=new 备注();
            fp.ShowDialog();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            timer.Start();
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            if (this.Opacity >= 0.025)
                this.Opacity -= 0.025;
            else
            {
                timer.Stop();
                Application.Exit();
            }
        }
    }
}
