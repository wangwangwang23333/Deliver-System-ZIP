﻿namespace 顾客系统
{
    partial class 订餐界面
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(订餐界面));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.挑选美食 = new System.Windows.Forms.TabPage();
            this.订单中心 = new System.Windows.Forms.TabPage();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.待支付订单 = new System.Windows.Forms.TabPage();
            this.派送中 = new System.Windows.Forms.TabPage();
            this.历史订单 = new System.Windows.Forms.TabPage();
            this.未接取订单 = new System.Windows.Forms.TabPage();
            this.未配送订单 = new System.Windows.Forms.TabPage();
            this.个人信息 = new System.Windows.Forms.TabPage();
            this.button5 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.已选购美食 = new System.Windows.Forms.TabPage();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.tabControl1.SuspendLayout();
            this.订单中心.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.个人信息.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.挑选美食);
            this.tabControl1.Controls.Add(this.订单中心);
            this.tabControl1.Controls.Add(this.个人信息);
            this.tabControl1.Controls.Add(this.已选购美食);
            this.tabControl1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tabControl1.Location = new System.Drawing.Point(15, 81);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(693, 413);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged_1);
            // 
            // 挑选美食
            // 
            this.挑选美食.BackgroundImage = global::顾客系统.Properties.Resources.BlueSky;
            this.挑选美食.Location = new System.Drawing.Point(4, 29);
            this.挑选美食.Name = "挑选美食";
            this.挑选美食.Padding = new System.Windows.Forms.Padding(3);
            this.挑选美食.Size = new System.Drawing.Size(685, 380);
            this.挑选美食.TabIndex = 0;
            this.挑选美食.Text = "挑选美食";
            this.挑选美食.UseVisualStyleBackColor = true;
            // 
            // 订单中心
            // 
            this.订单中心.Controls.Add(this.label9);
            this.订单中心.Controls.Add(this.label8);
            this.订单中心.Controls.Add(this.tabControl2);
            this.订单中心.Location = new System.Drawing.Point(4, 29);
            this.订单中心.Name = "订单中心";
            this.订单中心.Padding = new System.Windows.Forms.Padding(3);
            this.订单中心.Size = new System.Drawing.Size(685, 380);
            this.订单中心.TabIndex = 1;
            this.订单中心.Text = "订单中心";
            this.订单中心.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(7, 12);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(354, 20);
            this.label9.TabIndex = 2;
            this.label9.Text = "若果你已经收到外卖,点击派送中的订单可以完成哦~";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(441, 12);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(179, 20);
            this.label8.TabIndex = 1;
            this.label8.Text = "点击未支付订单即可支付!";
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.待支付订单);
            this.tabControl2.Controls.Add(this.派送中);
            this.tabControl2.Controls.Add(this.历史订单);
            this.tabControl2.Controls.Add(this.未接取订单);
            this.tabControl2.Controls.Add(this.未配送订单);
            this.tabControl2.Location = new System.Drawing.Point(6, 30);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(619, 348);
            this.tabControl2.TabIndex = 0;
            // 
            // 待支付订单
            // 
            this.待支付订单.BackgroundImage = global::顾客系统.Properties.Resources.BlueSky;
            this.待支付订单.Location = new System.Drawing.Point(4, 29);
            this.待支付订单.Name = "待支付订单";
            this.待支付订单.Padding = new System.Windows.Forms.Padding(3);
            this.待支付订单.Size = new System.Drawing.Size(611, 315);
            this.待支付订单.TabIndex = 0;
            this.待支付订单.Text = "待支付订单";
            this.待支付订单.UseVisualStyleBackColor = true;
            // 
            // 派送中
            // 
            this.派送中.BackgroundImage = global::顾客系统.Properties.Resources.BlueSky;
            this.派送中.Location = new System.Drawing.Point(4, 29);
            this.派送中.Name = "派送中";
            this.派送中.Padding = new System.Windows.Forms.Padding(3);
            this.派送中.Size = new System.Drawing.Size(611, 315);
            this.派送中.TabIndex = 1;
            this.派送中.Text = "派送中";
            this.派送中.UseVisualStyleBackColor = true;
            // 
            // 历史订单
            // 
            this.历史订单.BackgroundImage = global::顾客系统.Properties.Resources.BlueSky;
            this.历史订单.Location = new System.Drawing.Point(4, 29);
            this.历史订单.Name = "历史订单";
            this.历史订单.Padding = new System.Windows.Forms.Padding(3);
            this.历史订单.Size = new System.Drawing.Size(611, 315);
            this.历史订单.TabIndex = 2;
            this.历史订单.Text = "历史订单";
            this.历史订单.UseVisualStyleBackColor = true;
            // 
            // 未接取订单
            // 
            this.未接取订单.BackgroundImage = global::顾客系统.Properties.Resources.BlueSky;
            this.未接取订单.Location = new System.Drawing.Point(4, 29);
            this.未接取订单.Name = "未接取订单";
            this.未接取订单.Padding = new System.Windows.Forms.Padding(3);
            this.未接取订单.Size = new System.Drawing.Size(611, 315);
            this.未接取订单.TabIndex = 3;
            this.未接取订单.Text = "未接取订单";
            this.未接取订单.UseVisualStyleBackColor = true;
            // 
            // 未配送订单
            // 
            this.未配送订单.BackgroundImage = global::顾客系统.Properties.Resources.BlueSky;
            this.未配送订单.Location = new System.Drawing.Point(4, 29);
            this.未配送订单.Name = "未配送订单";
            this.未配送订单.Size = new System.Drawing.Size(611, 315);
            this.未配送订单.TabIndex = 4;
            this.未配送订单.Text = "未配送订单";
            this.未配送订单.UseVisualStyleBackColor = true;
            // 
            // 个人信息
            // 
            this.个人信息.BackgroundImage = global::顾客系统.Properties.Resources.BlueSky;
            this.个人信息.Controls.Add(this.button5);
            this.个人信息.Controls.Add(this.button2);
            this.个人信息.Controls.Add(this.button1);
            this.个人信息.Controls.Add(this.pictureBox1);
            this.个人信息.Controls.Add(this.textBox5);
            this.个人信息.Controls.Add(this.textBox4);
            this.个人信息.Controls.Add(this.textBox3);
            this.个人信息.Controls.Add(this.textBox2);
            this.个人信息.Controls.Add(this.textBox1);
            this.个人信息.Controls.Add(this.label5);
            this.个人信息.Controls.Add(this.label4);
            this.个人信息.Controls.Add(this.label3);
            this.个人信息.Controls.Add(this.label2);
            this.个人信息.Controls.Add(this.label1);
            this.个人信息.Location = new System.Drawing.Point(4, 29);
            this.个人信息.Name = "个人信息";
            this.个人信息.Padding = new System.Windows.Forms.Padding(3);
            this.个人信息.Size = new System.Drawing.Size(685, 380);
            this.个人信息.TabIndex = 2;
            this.个人信息.Text = "个人信息";
            this.个人信息.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(223, 319);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(122, 35);
            this.button5.TabIndex = 13;
            this.button5.Text = "修改密码";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(491, 300);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(91, 29);
            this.button2.TabIndex = 12;
            this.button2.Text = "保存";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Visible = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(491, 247);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(94, 30);
            this.button1.TabIndex = 11;
            this.button1.Text = "修改";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Location = new System.Drawing.Point(466, 28);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(140, 190);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(210, 272);
            this.textBox5.Name = "textBox5";
            this.textBox5.ReadOnly = true;
            this.textBox5.Size = new System.Drawing.Size(159, 27);
            this.textBox5.TabIndex = 9;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(210, 177);
            this.textBox4.Multiline = true;
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(159, 52);
            this.textBox4.TabIndex = 8;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(210, 124);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(159, 27);
            this.textBox3.TabIndex = 7;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(210, 78);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(159, 27);
            this.textBox2.TabIndex = 6;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(210, 28);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(159, 27);
            this.textBox1.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(111, 282);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(39, 20);
            this.label5.TabIndex = 4;
            this.label5.Text = "钱包";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(111, 203);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(39, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "地址";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(98, 134);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "送餐电话";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(111, 88);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "昵称";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(111, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "账号";
            // 
            // 已选购美食
            // 
            this.已选购美食.AutoScroll = true;
            this.已选购美食.BackgroundImage = global::顾客系统.Properties.Resources.BlueSky;
            this.已选购美食.Location = new System.Drawing.Point(4, 29);
            this.已选购美食.Name = "已选购美食";
            this.已选购美食.Size = new System.Drawing.Size(685, 380);
            this.已选购美食.TabIndex = 3;
            this.已选购美食.Text = "已选购美食";
            this.已选购美食.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label7.Location = new System.Drawing.Point(494, 510);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(122, 20);
            this.label7.TabIndex = 0;
            this.label7.Text = "待支付金额：  元";
            this.label7.Visible = false;
            this.label7.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Start_MouseDown);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.Location = new System.Drawing.Point(380, 40);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(170, 20);
            this.label6.TabIndex = 1;
            this.label6.Text = "再忙，也要记得吃饭哟~";
            this.label6.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Start_MouseDown);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button3.Image = global::顾客系统.Properties.Resources.UnselectedIndex;
            this.button3.Location = new System.Drawing.Point(355, 500);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(94, 39);
            this.button3.TabIndex = 1;
            this.button3.Text = "生成订单";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Visible = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Transparent;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button4.Image = global::顾客系统.Properties.Resources.shuaxin;
            this.button4.Location = new System.Drawing.Point(19, 500);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(58, 46);
            this.button4.TabIndex = 2;
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label10.Location = new System.Drawing.Point(16, 58);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(140, 20);
            this.label10.TabIndex = 0;
            this.label10.Text = "点击商家进去选餐~";
            this.label10.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Start_MouseDown);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label11.Location = new System.Drawing.Point(526, 63);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(136, 20);
            this.label11.TabIndex = 3;
            this.label11.Text = "点击添加备注哦~~";
            this.label11.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Start_MouseDown);
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnClose.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(193)))), ((int)(((byte)(255)))));
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.Image = global::顾客系统.Properties.Resources.close_small;
            this.btnClose.Location = new System.Drawing.Point(699, 12);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(32, 33);
            this.btnClose.TabIndex = 44;
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // timer
            // 
            this.timer.Interval = 30;
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // 订餐界面
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::顾客系统.Properties.Resources.餐厅背景图;
            this.ClientSize = new System.Drawing.Size(743, 551);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "订餐界面";
            this.Text = "订餐界面";
            this.Load += new System.EventHandler(this.订餐界面_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Start_MouseDown);
            this.tabControl1.ResumeLayout(false);
            this.订单中心.ResumeLayout(false);
            this.订单中心.PerformLayout();
            this.tabControl2.ResumeLayout(false);
            this.个人信息.ResumeLayout(false);
            this.个人信息.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage 挑选美食;
        private System.Windows.Forms.TabPage 订单中心;
        private System.Windows.Forms.TabPage 个人信息;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage 待支付订单;
        private System.Windows.Forms.TabPage 派送中;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TabPage 历史订单;
        private System.Windows.Forms.TabPage 已选购美食;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TabPage 未接取订单;
        private System.Windows.Forms.TabPage 未配送订单;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Timer timer;
    }
}