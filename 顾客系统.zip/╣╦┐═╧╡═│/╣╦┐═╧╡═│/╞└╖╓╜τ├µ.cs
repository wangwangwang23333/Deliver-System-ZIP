﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Runtime.InteropServices;

namespace 顾客系统
{
    public partial class 评分界面 : Form
    {
        public static string restaurantID="";
        public static string deliverGuyID="";
        public static string orderID="";
        public 评分界面(string resID,string delID,string ordID)
        {
            restaurantID=resID;
            deliverGuyID=delID;
            orderID=ordID;
            InitializeComponent();
        }

        private void 评分界面_Load(object sender, EventArgs e)
        {
            SqlCommand mycmd=new SqlCommand("select orders_comment from orders where orders_id='"+orderID+"'",myconn);
            string comment="";
            myconn.Open();
            SqlDataReader myreader=mycmd.ExecuteReader();
            myreader.Read();
            try
            {
                comment = myreader.GetString(0);
                myconn.Close();
                myreader.Close();
                MessageBox.Show("该订单已经完成评价哦!");
                this.Close();
            }
            catch(Exception)
            {
                myconn.Close();
                myreader.Close();
            }
            
        }

        static string mystr= "Initial Catalog = take_out;Data Source = (local);Integrated Security = True;";
        static SqlConnection myconn = new SqlConnection(mystr);
        #region 无边框拖动效果
        [DllImport("user32.dll")]//拖动无窗体的控件
        public static extern bool ReleaseCapture();
        [DllImport("user32.dll")]
        public static extern bool SendMessage(IntPtr hwnd, int wMsg, int wParam, int lParam);
        public const int WM_SYSCOMMAND = 0x0112;
        public const int SC_MOVE = 0xF010;
        public const int HTCAPTION = 0x0002;

        private void Start_MouseDown(object sender, MouseEventArgs e)
        {
            //拖动窗体
            ReleaseCapture();
            SendMessage(this.Handle, WM_SYSCOMMAND, SC_MOVE + HTCAPTION, 0);
        }
        #endregion
        private void button1_Click(object sender, EventArgs e)
        {
            float scoreRes=0;
            float scoreOrd=0;
            float scoreDel=0;
            if (radioButton1.Checked == true)
            {
                scoreOrd = 1;
            }
            else if (radioButton2.Checked == true)
            {
                scoreOrd = 2;
            }
            else if (radioButton3.Checked == true)
            {
                scoreOrd = 3;
            }
            else if (radioButton4.Checked == true)
            {
                scoreOrd = 4;
            }
            else if(radioButton5.Checked == true)
            {
                scoreOrd = 5;
            }

            if (radioButton6.Checked == true)
            {
                scoreRes = 5;
            }
            else if (radioButton7.Checked == true)
            {
                scoreRes = 4;
            }
            else if (radioButton8.Checked == true)
            {
                scoreRes = 3;
            }
            else if (radioButton9.Checked == true)
            {
                scoreRes = 2;
            }
            else if (radioButton10.Checked == true)
            {
                scoreRes = 1;
            }

            if (radioButton11.Checked == true)
            {
                scoreDel = 5;
            }
            else if (radioButton12.Checked == true)
            {
                scoreDel = 4;
            }
            else if (radioButton13.Checked == true)
            {
                scoreDel = 3;
            }
            else if (radioButton14.Checked == true)
            {
                scoreDel = 2;
            }
            else if (radioButton15.Checked == true )
            {
                scoreDel = 1;
            }
            string evaluation=textBox1.Text;
            if (evaluation == "")
            {
                evaluation="该用户没有评价,默认为好评!";
            }

            string select1="select Count(orders_id) from orders where restaurant_id='"+restaurantID+"'";
            string select2="select Count(orders_id) from orders where deliverGuy_id='"+deliverGuyID+"'";
            string select3="select restaurant_score from restaurant where restaurant_id='"+restaurantID+"'";
            string select4="select deliverGuy_score from deliverGuy where deliverGuy_id='"+deliverGuyID+"'";


            int num_resOrder=0;
            int num_delOrder=0;
            float resScore=0;
            float delScore=0;
            SqlCommand myCmd=new SqlCommand(select1,myconn);
            
            myconn.Open();
            SqlDataReader myreader=myCmd.ExecuteReader();
            myreader.Read();
            num_resOrder=int.Parse(myreader.GetValue(0).ToString());
            myreader.Close();
            myCmd.CommandText=select2;
            myreader=myCmd.ExecuteReader();
            myreader.Read();
            num_delOrder=int.Parse(myreader.GetValue(0).ToString());
            myreader.Close();
            myCmd.CommandText = select3;
            myreader = myCmd.ExecuteReader();
            myreader.Read();
            resScore = float.Parse(myreader.GetValue(0).ToString());
            myreader.Close();
            myCmd.CommandText = select4;
            myreader = myCmd.ExecuteReader();
            myreader.Read();
            delScore = float.Parse(myreader.GetValue(0).ToString());
            myreader.Close();
            myconn.Close();

            float newResScore = (scoreRes + num_resOrder * resScore) / num_resOrder;
            float newDelScore = (scoreDel + num_delOrder * delScore) / num_delOrder;

            string update1="update orders set orders_score="+scoreOrd+",orders_comment='"+
                evaluation+"'"+"where orders_id='"+orderID+"'";
            string update2="update restaurant set restaurant_score="+newResScore+
                "where restaurant_id='"+restaurantID+"'";
            string update3="update deliverGuy set deliverGuy_score="+newDelScore+
                "where deliverGuy_id='"+deliverGuyID+"'";

            myCmd.CommandText=update1;
            myconn.Open();
            try
            {
                myCmd.ExecuteNonQuery();
            }
            catch (Exception) {MessageBox.Show("订单信息更新失败!"); }
            myCmd.CommandText=update2;
            try
            {
                myCmd.ExecuteNonQuery();
            }
            catch (Exception) { MessageBox.Show("餐厅信息更新失败!"); }
            myCmd.CommandText=update3;
            try
            {
                myCmd.ExecuteNonQuery();
            }
            catch (Exception) { MessageBox.Show("骑手信息更新失败!"); }
            myconn.Close();
            MessageBox.Show("成功评价此订单,订单已经完成~,关闭界面后刷新可以得到最新情况!~");
            button1.Visible=false;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
