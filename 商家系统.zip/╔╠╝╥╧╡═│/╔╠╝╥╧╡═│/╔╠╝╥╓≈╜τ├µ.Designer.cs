﻿namespace 商家系统
{
    partial class 商家主界面
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(商家主界面));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.商家菜谱 = new System.Windows.Forms.TabPage();
            this.添加新菜 = new System.Windows.Forms.TabPage();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.订单中心 = new System.Windows.Forms.TabPage();
            this.label19 = new System.Windows.Forms.Label();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.可接订单 = new System.Windows.Forms.TabPage();
            this.派送中 = new System.Windows.Forms.TabPage();
            this.历史订单 = new System.Windows.Forms.TabPage();
            this.未配送订单 = new System.Windows.Forms.TabPage();
            this.商家信息 = new System.Windows.Forms.TabPage();
            this.button9 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.修改菜品 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.button3 = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.商家评价 = new System.Windows.Forms.TabPage();
            this.tabControl1.SuspendLayout();
            this.添加新菜.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.订单中心.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.商家信息.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.修改菜品.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.商家菜谱);
            this.tabControl1.Controls.Add(this.添加新菜);
            this.tabControl1.Controls.Add(this.订单中心);
            this.tabControl1.Controls.Add(this.商家信息);
            this.tabControl1.Controls.Add(this.修改菜品);
            this.tabControl1.Controls.Add(this.商家评价);
            this.tabControl1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tabControl1.Location = new System.Drawing.Point(12, 52);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(694, 387);
            this.tabControl1.TabIndex = 0;
            // 
            // 商家菜谱
            // 
            this.商家菜谱.AutoScroll = true;
            this.商家菜谱.BackgroundImage = global::商家系统.Properties.Resources.BlueSky;
            this.商家菜谱.Location = new System.Drawing.Point(4, 29);
            this.商家菜谱.Name = "商家菜谱";
            this.商家菜谱.Padding = new System.Windows.Forms.Padding(3);
            this.商家菜谱.Size = new System.Drawing.Size(686, 354);
            this.商家菜谱.TabIndex = 0;
            this.商家菜谱.Text = "商家菜谱";
            this.商家菜谱.UseVisualStyleBackColor = true;
            // 
            // 添加新菜
            // 
            this.添加新菜.BackgroundImage = global::商家系统.Properties.Resources.BlueSky;
            this.添加新菜.Controls.Add(this.label14);
            this.添加新菜.Controls.Add(this.label13);
            this.添加新菜.Controls.Add(this.textBox12);
            this.添加新菜.Controls.Add(this.textBox11);
            this.添加新菜.Controls.Add(this.textBox10);
            this.添加新菜.Controls.Add(this.button2);
            this.添加新菜.Controls.Add(this.button1);
            this.添加新菜.Controls.Add(this.pictureBox2);
            this.添加新菜.Controls.Add(this.label12);
            this.添加新菜.Controls.Add(this.label11);
            this.添加新菜.Controls.Add(this.label10);
            this.添加新菜.Location = new System.Drawing.Point(4, 29);
            this.添加新菜.Name = "添加新菜";
            this.添加新菜.Padding = new System.Windows.Forms.Padding(3);
            this.添加新菜.Size = new System.Drawing.Size(686, 354);
            this.添加新菜.TabIndex = 1;
            this.添加新菜.Text = "添加新菜";
            this.添加新菜.UseVisualStyleBackColor = true;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(516, 103);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(129, 20);
            this.label14.TabIndex = 10;
            this.label14.Text = "点击添加菜品图片";
            this.label14.Visible = false;
            this.label14.Click += new System.EventHandler(this.label14_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(342, 205);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(225, 20);
            this.label13.TabIndex = 9;
            this.label13.Text = "(只有点击添加菜品才能操作哦~)";
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(97, 153);
            this.textBox12.Multiline = true;
            this.textBox12.Name = "textBox12";
            this.textBox12.ReadOnly = true;
            this.textBox12.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox12.Size = new System.Drawing.Size(239, 138);
            this.textBox12.TabIndex = 8;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(97, 84);
            this.textBox11.Name = "textBox11";
            this.textBox11.ReadOnly = true;
            this.textBox11.Size = new System.Drawing.Size(239, 27);
            this.textBox11.TabIndex = 7;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(97, 16);
            this.textBox10.Name = "textBox10";
            this.textBox10.ReadOnly = true;
            this.textBox10.Size = new System.Drawing.Size(239, 27);
            this.textBox10.TabIndex = 6;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(532, 307);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(101, 31);
            this.button2.TabIndex = 5;
            this.button2.Text = "保  存";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Visible = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(532, 258);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(102, 33);
            this.button1.TabIndex = 4;
            this.button1.Text = "添加菜品";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox2.Location = new System.Drawing.Point(506, 20);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(146, 182);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 3;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(16, 156);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(69, 20);
            this.label12.TabIndex = 2;
            this.label12.Text = "菜品介绍";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(16, 84);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(69, 20);
            this.label11.TabIndex = 1;
            this.label11.Text = "菜品价格";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(16, 20);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(69, 20);
            this.label10.TabIndex = 0;
            this.label10.Text = "菜品名称";
            // 
            // 订单中心
            // 
            this.订单中心.Controls.Add(this.label19);
            this.订单中心.Controls.Add(this.tabControl2);
            this.订单中心.Location = new System.Drawing.Point(4, 29);
            this.订单中心.Name = "订单中心";
            this.订单中心.Size = new System.Drawing.Size(686, 354);
            this.订单中心.TabIndex = 2;
            this.订单中心.Text = "订单中心";
            this.订单中心.UseVisualStyleBackColor = true;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(516, 10);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(155, 20);
            this.label19.TabIndex = 1;
            this.label19.Text = "点击订单可以接单哦~";
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.可接订单);
            this.tabControl2.Controls.Add(this.派送中);
            this.tabControl2.Controls.Add(this.历史订单);
            this.tabControl2.Controls.Add(this.未配送订单);
            this.tabControl2.Location = new System.Drawing.Point(7, 28);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(676, 316);
            this.tabControl2.TabIndex = 0;
            // 
            // 可接订单
            // 
            this.可接订单.AutoScroll = true;
            this.可接订单.BackgroundImage = global::商家系统.Properties.Resources.餐厅背景图;
            this.可接订单.Location = new System.Drawing.Point(4, 29);
            this.可接订单.Name = "可接订单";
            this.可接订单.Padding = new System.Windows.Forms.Padding(3);
            this.可接订单.Size = new System.Drawing.Size(668, 283);
            this.可接订单.TabIndex = 0;
            this.可接订单.Text = "可接订单";
            this.可接订单.UseVisualStyleBackColor = true;
            // 
            // 派送中
            // 
            this.派送中.AutoScroll = true;
            this.派送中.BackgroundImage = global::商家系统.Properties.Resources.餐厅背景图;
            this.派送中.Location = new System.Drawing.Point(4, 29);
            this.派送中.Name = "派送中";
            this.派送中.Padding = new System.Windows.Forms.Padding(3);
            this.派送中.Size = new System.Drawing.Size(668, 283);
            this.派送中.TabIndex = 1;
            this.派送中.Text = "派送中";
            this.派送中.UseVisualStyleBackColor = true;
            // 
            // 历史订单
            // 
            this.历史订单.AutoScroll = true;
            this.历史订单.BackgroundImage = global::商家系统.Properties.Resources.餐厅背景图;
            this.历史订单.Location = new System.Drawing.Point(4, 29);
            this.历史订单.Name = "历史订单";
            this.历史订单.Size = new System.Drawing.Size(668, 283);
            this.历史订单.TabIndex = 2;
            this.历史订单.Text = "历史订单";
            this.历史订单.UseVisualStyleBackColor = true;
            // 
            // 未配送订单
            // 
            this.未配送订单.AutoScroll = true;
            this.未配送订单.BackgroundImage = global::商家系统.Properties.Resources.餐厅背景图;
            this.未配送订单.Location = new System.Drawing.Point(4, 29);
            this.未配送订单.Name = "未配送订单";
            this.未配送订单.Padding = new System.Windows.Forms.Padding(3);
            this.未配送订单.Size = new System.Drawing.Size(668, 283);
            this.未配送订单.TabIndex = 3;
            this.未配送订单.Text = "未配送订单";
            this.未配送订单.UseVisualStyleBackColor = true;
            // 
            // 商家信息
            // 
            this.商家信息.BackgroundImage = global::商家系统.Properties.Resources.BlueSky;
            this.商家信息.Controls.Add(this.button9);
            this.商家信息.Controls.Add(this.button5);
            this.商家信息.Controls.Add(this.button4);
            this.商家信息.Controls.Add(this.label9);
            this.商家信息.Controls.Add(this.textBox9);
            this.商家信息.Controls.Add(this.textBox8);
            this.商家信息.Controls.Add(this.textBox7);
            this.商家信息.Controls.Add(this.textBox6);
            this.商家信息.Controls.Add(this.textBox5);
            this.商家信息.Controls.Add(this.textBox4);
            this.商家信息.Controls.Add(this.textBox3);
            this.商家信息.Controls.Add(this.textBox2);
            this.商家信息.Controls.Add(this.textBox1);
            this.商家信息.Controls.Add(this.pictureBox1);
            this.商家信息.Controls.Add(this.label8);
            this.商家信息.Controls.Add(this.label7);
            this.商家信息.Controls.Add(this.label6);
            this.商家信息.Controls.Add(this.label5);
            this.商家信息.Controls.Add(this.label4);
            this.商家信息.Controls.Add(this.label3);
            this.商家信息.Controls.Add(this.label2);
            this.商家信息.Controls.Add(this.label1);
            this.商家信息.Location = new System.Drawing.Point(4, 29);
            this.商家信息.Name = "商家信息";
            this.商家信息.Size = new System.Drawing.Size(686, 354);
            this.商家信息.TabIndex = 3;
            this.商家信息.Text = "商家信息";
            this.商家信息.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(196, 312);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(121, 30);
            this.button9.TabIndex = 21;
            this.button9.Text = "修改密码";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(540, 261);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(108, 36);
            this.button5.TabIndex = 20;
            this.button5.Text = "保存";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(540, 213);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(108, 29);
            this.button4.TabIndex = 19;
            this.button4.Text = "修改";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(383, 114);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(15, 20);
            this.label9.TabIndex = 18;
            this.label9.Text = "-";
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(294, 174);
            this.textBox9.Multiline = true;
            this.textBox9.Name = "textBox9";
            this.textBox9.ReadOnly = true;
            this.textBox9.Size = new System.Drawing.Size(180, 123);
            this.textBox9.TabIndex = 17;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(294, 143);
            this.textBox8.Name = "textBox8";
            this.textBox8.ReadOnly = true;
            this.textBox8.Size = new System.Drawing.Size(210, 27);
            this.textBox8.TabIndex = 16;
            this.textBox8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(404, 111);
            this.textBox7.Name = "textBox7";
            this.textBox7.ReadOnly = true;
            this.textBox7.Size = new System.Drawing.Size(100, 27);
            this.textBox7.TabIndex = 15;
            this.textBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(279, 111);
            this.textBox6.Name = "textBox6";
            this.textBox6.ReadOnly = true;
            this.textBox6.Size = new System.Drawing.Size(98, 27);
            this.textBox6.TabIndex = 14;
            this.textBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(349, 76);
            this.textBox5.Name = "textBox5";
            this.textBox5.ReadOnly = true;
            this.textBox5.Size = new System.Drawing.Size(155, 27);
            this.textBox5.TabIndex = 13;
            this.textBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(349, 16);
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(155, 27);
            this.textBox4.TabIndex = 12;
            this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(15, 141);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(194, 156);
            this.textBox3.TabIndex = 11;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(85, 69);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(180, 27);
            this.textBox2.TabIndex = 10;
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(85, 16);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(180, 27);
            this.textBox1.TabIndex = 9;
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Location = new System.Drawing.Point(521, 19);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(141, 179);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(215, 153);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(69, 20);
            this.label8.TabIndex = 7;
            this.label8.Text = "商家评分";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(291, 79);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(54, 20);
            this.label7.TabIndex = 6;
            this.label7.Text = "配送费";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(215, 183);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(69, 20);
            this.label6.TabIndex = 5;
            this.label6.Text = "商家地址";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(276, 19);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(69, 20);
            this.label5.TabIndex = 4;
            this.label5.Text = "商家电话";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(168, 114);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(99, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "商家营业时间";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 114);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "商家简介";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "商家名称";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "商家ID";
            // 
            // 修改菜品
            // 
            this.修改菜品.BackgroundImage = global::商家系统.Properties.Resources.BlueSky;
            this.修改菜品.Controls.Add(this.groupBox1);
            this.修改菜品.Controls.Add(this.button6);
            this.修改菜品.Controls.Add(this.textBox13);
            this.修改菜品.Controls.Add(this.label15);
            this.修改菜品.Location = new System.Drawing.Point(4, 29);
            this.修改菜品.Name = "修改菜品";
            this.修改菜品.Size = new System.Drawing.Size(686, 354);
            this.修改菜品.TabIndex = 4;
            this.修改菜品.Text = "修改菜品";
            this.修改菜品.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button8);
            this.groupBox1.Controls.Add(this.button7);
            this.groupBox1.Controls.Add(this.pictureBox3);
            this.groupBox1.Controls.Add(this.textBox16);
            this.groupBox1.Controls.Add(this.textBox15);
            this.groupBox1.Controls.Add(this.textBox14);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Location = new System.Drawing.Point(3, 81);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(680, 228);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            this.groupBox1.Visible = false;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(580, 105);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(70, 30);
            this.button8.TabIndex = 11;
            this.button8.Text = "保存";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Visible = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(580, 50);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(70, 30);
            this.button7.TabIndex = 10;
            this.button7.Text = "修改";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox3.Location = new System.Drawing.Point(401, 24);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(152, 177);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 9;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(83, 105);
            this.textBox16.Multiline = true;
            this.textBox16.Name = "textBox16";
            this.textBox16.ReadOnly = true;
            this.textBox16.Size = new System.Drawing.Size(295, 117);
            this.textBox16.TabIndex = 8;
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(122, 62);
            this.textBox15.Name = "textBox15";
            this.textBox15.ReadOnly = true;
            this.textBox15.Size = new System.Drawing.Size(186, 27);
            this.textBox15.TabIndex = 7;
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(122, 15);
            this.textBox14.Name = "textBox14";
            this.textBox14.ReadOnly = true;
            this.textBox14.Size = new System.Drawing.Size(186, 27);
            this.textBox14.TabIndex = 6;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(6, 163);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(69, 20);
            this.label18.TabIndex = 5;
            this.label18.Text = "菜品简介";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(6, 65);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(69, 20);
            this.label17.TabIndex = 4;
            this.label17.Text = "菜品价格";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(6, 18);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(69, 20);
            this.label16.TabIndex = 3;
            this.label16.Text = "菜品名称";
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(404, 19);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(120, 28);
            this.button6.TabIndex = 2;
            this.button6.Text = "查询";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(86, 23);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(186, 27);
            this.textBox13.TabIndex = 1;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(14, 26);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(54, 20);
            this.label15.TabIndex = 0;
            this.label15.Text = "菜品ID";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button3.Location = new System.Drawing.Point(623, 46);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(76, 29);
            this.button3.TabIndex = 1;
            this.button3.Text = "刷新";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.Transparent;
            this.btnClose.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(193)))), ((int)(((byte)(255)))));
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.Image = global::商家系统.Properties.Resources.close_small;
            this.btnClose.Location = new System.Drawing.Point(679, 7);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(32, 33);
            this.btnClose.TabIndex = 48;
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // timer
            // 
            this.timer.Interval = 30;
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // 商家评价
            // 
            this.商家评价.Location = new System.Drawing.Point(4, 29);
            this.商家评价.Name = "商家评价";
            this.商家评价.Size = new System.Drawing.Size(686, 354);
            this.商家评价.TabIndex = 5;
            this.商家评价.Text = "商家评价";
            this.商家评价.UseVisualStyleBackColor = true;
            // 
            // 商家主界面
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::商家系统.Properties.Resources.餐厅背景图;
            this.ClientSize = new System.Drawing.Size(723, 451);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "商家主界面";
            this.Text = "商家主界面";
            this.Load += new System.EventHandler(this.商家主界面_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Start_MouseDown);
            this.tabControl1.ResumeLayout(false);
            this.添加新菜.ResumeLayout(false);
            this.添加新菜.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.订单中心.ResumeLayout(false);
            this.订单中心.PerformLayout();
            this.tabControl2.ResumeLayout(false);
            this.商家信息.ResumeLayout(false);
            this.商家信息.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.修改菜品.ResumeLayout(false);
            this.修改菜品.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage 商家菜谱;
        private System.Windows.Forms.TabPage 添加新菜;
        private System.Windows.Forms.TabPage 订单中心;
        private System.Windows.Forms.TabPage 商家信息;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage 可接订单;
        private System.Windows.Forms.TabPage 派送中;
        private System.Windows.Forms.TabPage 历史订单;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TabPage 修改菜品;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.TabPage 未配送订单;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.TabPage 商家评价;
    }
}