﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Runtime.InteropServices;

namespace 商家系统
{
    public partial class 商家主界面 : Form
    {
        public  string resID;
        public 商家主界面(string ID)
        {
            resID=ID;
            InitializeComponent();
        }
        static string mystr = "Initial Catalog = take_out;Data Source = (local);Integrated Security = True ; MultipleActiveResultSets=true";

        #region 无边框拖动效果
        [DllImport("user32.dll")]//拖动无窗体的控件
        public static extern bool ReleaseCapture();
        [DllImport("user32.dll")]
        public static extern bool SendMessage(IntPtr hwnd, int wMsg, int wParam, int lParam);
        public const int WM_SYSCOMMAND = 0x0112;
        public const int SC_MOVE = 0xF010;
        public const int HTCAPTION = 0x0002;

        private void Start_MouseDown(object sender, MouseEventArgs e)
        {
            //拖动窗体
            ReleaseCapture();
            SendMessage(this.Handle, WM_SYSCOMMAND, SC_MOVE + HTCAPTION, 0);
        }
        #endregion

        private void 商家主界面_Load(object sender, EventArgs e)
        {
            SqlConnection myconn = new SqlConnection(mystr);

//-------加载菜谱-------------------------------------------------------------------------------------------//
            string selectStr="select * from dish where restaurant_id='"+resID+"'";
            SqlCommand myCmd=new SqlCommand(selectStr,myconn);
            
            myconn.Open();
            SqlDataReader myreader = myCmd.ExecuteReader();
            
            try
            {
                int index=0;
                while (myreader.Read())
                {
                    //利用new操作生成一个窗体
                    Panel panel = new Panel();
                    panel.Size = new Size(480, 100);
                    panel.Location = new Point(5, 5 * (index + 1) + 100 * index);
                    panel.BackColor = Color.LightGray;

                    //添加菜的id
                    //向panel中添加信息
                    Label dishID = new Label();
                    dishID.Text = "菜品编号:" + myreader.GetString(1);
                    dishID.Location = new Point(5, 5);
                    dishID.AutoSize = true;
                    panel.Controls.Add(dishID);

                    //菜品名字;
                    Label dishName = new Label();
                    dishName.Text = "菜品名称:" + myreader.GetString(2);
                    dishName.Location = new Point(5, 30);
                    dishName.AutoSize=true;
                    panel.Controls.Add(dishName);

                    //菜品价格;
                    Label dishPrice = new Label();
                    dishPrice.Text = "菜品价格:" + myreader.GetValue(3).ToString();
                    dishPrice.Location = new Point(5, 55);
                    panel.Controls.Add(dishPrice);

                    //菜品图片;
                    string ImageFile;
                    if(myreader.GetValue(4).ToString()!="")
                    {
                        ImageFile = myreader.GetValue(4).ToString();
                    }
                    else
                    {
                        ImageFile = "1.jpg";
                    }
                    Image dishFile = Image.FromFile(ImageFile);
                    PictureBox dishImage = new PictureBox();
                    dishImage.Image = dishFile;
                    dishImage.Location = new Point(300, 5);
                    dishImage.Size = new Size(100, 80);
                    dishImage.SizeMode = PictureBoxSizeMode.Zoom;
                    panel.Controls.Add(dishImage);

                    //菜品简介;
                    string intro= "菜品简介:\n" + myreader.GetString(5);
                    ToolTip t=new ToolTip();
                    t.SetToolTip(panel,intro);

                    Button deleteButton = new Button();
                    deleteButton.Name = myreader.GetString(1);
                    deleteButton.Size = new Size(30, 30);
                    deleteButton.Image= Image.FromFile("deleteButton.jpg");
                    deleteButton.BackgroundImageLayout=ImageLayout.Stretch;
                    
                    deleteButton.Location = new Point(425, 5);
                    deleteButton.Click += new System.EventHandler(this.deleteButton_Click);
                    

                    panel.Controls.Add(deleteButton);
                    index++;
                    商家菜谱.Controls.Add(panel);

                }

            }
            catch (Exception) { };

            myreader.Close();
            myconn.Close();

//-------加载商家可以接受的订单-------------------------------------------------------------------------------------------//
            //获得商家待接收订单;
            myCmd.CommandText = "select * from orders where orders_status='a' and restaurant_id='"+resID+"'";
            //读取数据
            myconn.Open();
            myreader = myCmd.ExecuteReader();
            try
            {
                int index2 = 0;
                while (myreader.Read())
                {
                    //利用new操作生成一个窗体
                    Panel panel = new Panel();
                    panel.Size = new Size(475, 110);
                    panel.Location = new Point(5, 5 * (index2 + 1) + 110 * index2);
                    panel.BackColor = Color.LightGray;
                    panel.AutoScroll=true;

                    //向panel中添加信息
                    Label orderID = new Label();
                    orderID.Text = "订单编号:" + myreader.GetString(0);
                    orderID.Location = new Point(5, 5);
                    orderID.AutoSize = true;
                    panel.Name=myreader.GetString(0)+"accpet";
                    panel.Controls.Add(orderID);

                    //目的地;
                    Label endAddress = new Label();
                    endAddress.Text = "目的地:" + myreader.GetString(4);
                    endAddress.Location = new Point(5, 55);
                    endAddress.AutoSize=true;
                    panel.Controls.Add(endAddress);

                    //订单金额;
                    Label orderMoney = new Label();
                    orderMoney.Text = "订单金额:" + myreader.GetValue(5).ToString();
                    orderMoney.Location = new Point(5, 80);
                    panel.Controls.Add(orderMoney);

                    //订单下单时间;
                    Label startTime = new Label();
                    startTime.Text = "下单时间:" + myreader.GetValue(6).ToString();
                    startTime.Location = new Point(220, 5);
                    startTime.AutoSize=true;
                    panel.Controls.Add(startTime);

                    //订单应到时间;
                    Label endTime = new Label();
                    endTime.Text = "到达时间:" + myreader.GetValue(7).ToString();
                    endTime.Location = new Point(220,30);
                    endTime.AutoSize = true;
                    panel.Controls.Add(endTime);

                    //送货员信息;
                    Label deliverGuyID = new Label();
                    string _deliverGuyID=myreader.GetString(12);
                    if (_deliverGuyID == "g09999")
                    {
                        _deliverGuyID="***";
                    }
                    deliverGuyID.Text = "送餐员编号:" + _deliverGuyID;          
                    deliverGuyID.Location = new Point(150, 55);
                    deliverGuyID.AutoSize = true;
                    panel.Controls.Add(deliverGuyID);

                    //获取用户信息
                    string selectStr2= "select customer_name,customer_phone from customer where customer_id='" + myreader.GetString(2)+"' ";
                    SqlCommand mycmd2=new SqlCommand(selectStr2,myconn);
                    SqlDataReader informationReader = mycmd2.ExecuteReader();   
                    informationReader.Read();
                    Label informationLabel = new Label();
                    informationLabel.AutoSize = true;
                    informationLabel.Location = new Point(5, 30);
                    informationLabel.Text = informationReader.GetString(0) + "    ";
                    //保护用户隐私
                    informationLabel.Text += "尾号:" + informationReader.GetString(1).Substring(informationReader.GetString(1).Length - 4);
                    informationReader.Close();
                    panel.Controls.Add(informationLabel);

                    //获取订单内容;
                    string orderInformation = "订单内容:\n"+myreader.GetString(9);                 
                    orderInformation += "\n订单备注:\n" + myreader.GetString(10);
                    ToolTip toolTip = new ToolTip();
                    toolTip.SetToolTip(panel, orderInformation);

                    index2++;
                    panel.Click+=new System.EventHandler(panelClick);
                    可接订单.Controls.Add(panel);
                    可接订单.AutoScroll=true;
                }
            }
            catch (Exception) { };
            myreader.Close();
            myconn.Close();

//-------派送中订单-------------------------------------------------------------------------------------------//
            myCmd.CommandText = "select * from orders where orders_status='c' and restaurant_id='"+resID+"'";
            //读取数据
            myconn.Open();
            myreader = myCmd.ExecuteReader();
            try
            {
                int index2 = 0;
                while (myreader.Read())
                {
                    //利用new操作生成一个窗体
                    Panel panel = new Panel();
                    panel.Size = new Size(475, 110);
                    panel.Location = new Point(5, 5 * (index2 + 1) + 110 * index2);
                    panel.BackColor = Color.LightGray;
                    panel.AutoScroll = true;

                    //向panel中添加信息
                    Label orderID = new Label();
                    orderID.Text = "订单编号:" + myreader.GetString(0);
                    orderID.Location = new Point(5, 5);
                    orderID.AutoSize = true;
                    panel.Controls.Add(orderID);

                    //目的地;
                    Label endAddress = new Label();
                    endAddress.Text = "目的地:" + myreader.GetString(4);
                    endAddress.Location = new Point(5, 55);
                    endAddress.AutoSize = true;
                    panel.Controls.Add(endAddress);

                    //订单金额;
                    Label orderMoney = new Label();
                    orderMoney.Text = "订单金额:" + myreader.GetValue(5).ToString();
                    orderMoney.Location = new Point(5, 80);
                    panel.Controls.Add(orderMoney);

                    //订单下单时间;
                    Label startTime = new Label();
                    startTime.Text = "下单时间:" + myreader.GetValue(6).ToString();
                    startTime.Location = new Point(220, 5);
                    startTime.AutoSize = true;
                    panel.Controls.Add(startTime);

                    //订单应到时间;
                    Label endTime = new Label();
                    endTime.Text = "到达时间:" + myreader.GetValue(7).ToString();
                    endTime.Location = new Point(220, 30);
                    endTime.AutoSize = true;
                    panel.Controls.Add(endTime);

                    //送货员信息;
                    Label deliverGuyID = new Label();
                    string _deliverGuyID = myreader.GetString(12);
                    if (_deliverGuyID == "g09999")
                    {
                        _deliverGuyID = "***";
                    }
                    deliverGuyID.Text = "送餐员编号:" + _deliverGuyID;
                    deliverGuyID.Location = new Point(150, 55);
                    deliverGuyID.AutoSize = true;
                    panel.Controls.Add(deliverGuyID);

                    //获取用户信息
                    string selectStr2 = "select customer_name,customer_phone from customer where customer_id='" + myreader.GetString(2) + "' ";
                    SqlCommand mycmd2 = new SqlCommand(selectStr2, myconn);
                    SqlDataReader informationReader = mycmd2.ExecuteReader();
                    informationReader.Read();
                    Label informationLabel = new Label();
                    informationLabel.AutoSize = true;
                    informationLabel.Location = new Point(5, 30);
                    informationLabel.Text = informationReader.GetString(0) + "    ";
                    //保护用户隐私
                    informationLabel.Text += "尾号:" + informationReader.GetString(1).Substring(informationReader.GetString(1).Length - 4);
                    informationReader.Close();
                    panel.Controls.Add(informationLabel);

                    //获取订单内容;
                    string orderInformation = "订单内容:\n"+myreader.GetString(9);
                    //备注信息  
                    orderInformation += "\n订单备注:\n" + myreader.GetString(10);
                    ToolTip toolTip = new ToolTip();
                    toolTip.SetToolTip(panel, orderInformation);

                    index2++;
                    派送中.Controls.Add(panel);
                    派送中.AutoScroll = true;
                }
            }
            catch (Exception) { };
            myreader.Close();
            myconn.Close();

//-------历史订单-------------------------------------------------------------------------------------------//
            myCmd.CommandText = "select * from orders where orders_status='d' and restaurant_id='"+resID+"'";
            //读取数据
            myconn.Open();
            myreader = myCmd.ExecuteReader();
            try
            {
                int index2 = 0;
                while (myreader.Read())
                {
                    //利用new操作生成一个窗体
                    Panel panel = new Panel();
                    panel.Size = new Size(475, 100);
                    panel.Location = new Point(5, 5 * (index2 + 1) + 110 * index2);
                    panel.BackColor = Color.LightGray;
                    panel.AutoScroll = true;

                    //向panel中添加信息
                    Label orderID = new Label();
                    orderID.Text = "订单编号:" + myreader.GetString(0);
                    orderID.Location = new Point(5, 5);
                    orderID.AutoSize = true;
                    panel.Controls.Add(orderID);

                    //目的地;
                    Label endAddress = new Label();
                    endAddress.Text = "目的地:" + myreader.GetString(4);
                    endAddress.Location = new Point(5, 55);
                    endAddress.AutoSize = true;
                    panel.Controls.Add(endAddress);

                    //订单金额;
                    Label orderMoney = new Label();
                    orderMoney.Text = "订单金额:" + myreader.GetValue(5).ToString();
                    orderMoney.Location = new Point(5, 80);
                    orderMoney.AutoSize = true;
                    panel.Controls.Add(orderMoney);

                    //订单下单时间;
                    Label startTime = new Label();
                    startTime.Text = "下单时间:" + myreader.GetValue(6).ToString();
                    startTime.Location = new Point(220, 5);
                    startTime.AutoSize = true;
                    panel.Controls.Add(startTime);

                    //订单应到时间;
                    Label endTime = new Label();
                    endTime.Text = "到达时间:" + myreader.GetValue(7).ToString();
                    endTime.Location = new Point(220, 30);
                    endTime.AutoSize = true;
                    panel.Controls.Add(endTime);

                    //送货员信息;
                    Label deliverGuyID = new Label();
                    string _deliverGuyID = myreader.GetString(12);
                    if (_deliverGuyID == "g09999")
                    {
                        _deliverGuyID = "***";
                    }
                    deliverGuyID.Text = "送餐员编号:" + _deliverGuyID;
                    deliverGuyID.Location = new Point(150, 55);
                    deliverGuyID.AutoSize = true;
                    panel.Controls.Add(deliverGuyID);

                    //获取用户信息
                    string selectStr2 = "select customer_name,customer_phone from customer where customer_id='" + myreader.GetString(2) + "' ";
                    SqlCommand mycmd2 = new SqlCommand(selectStr2, myconn);
                    SqlDataReader informationReader = mycmd2.ExecuteReader();
                    informationReader.Read();
                    Label informationLabel = new Label();
                    informationLabel.AutoSize = true;
                    informationLabel.Location = new Point(5, 30);
                    informationLabel.Text = informationReader.GetString(0) + "    ";
                    //保护用户隐私
                    informationLabel.Text += "尾号:" + informationReader.GetString(1).Substring(informationReader.GetString(1).Length - 4);
                    informationReader.Close();
                    panel.Controls.Add(informationLabel);

                    //获取订单内容;
                    string orderInformation = "订单内容:\n" + myreader.GetString(9);
                    //备注信息  
                    orderInformation += "\n订单备注:\n" + myreader.GetString(10);
                    //查看是否有评价信息
                    try
                    {
                        orderInformation += "\n订单评价:\n" + myreader.GetString(14);
                    }
                    catch (Exception)
                    {
                        orderInformation += "\n订单尚无评价";
                    }
                    ToolTip toolTip = new ToolTip();
                    toolTip.SetToolTip(panel, orderInformation);

                    index2++;

                    历史订单.Controls.Add(panel);
                    历史订单.AutoScroll = true;
                }
            }
            catch (Exception) { };
            myreader.Close();
            myconn.Close();


//-------未配送订单-------------------------------------------------------------------------------------------//
            myCmd.CommandText = "select * from orders where orders_status='b' and restaurant_id='" + resID + "'";
            //读取数据
            myconn.Open();
            myreader = myCmd.ExecuteReader();
            try
            {
                int index2 = 0;
                while (myreader.Read())
                {
                    //利用new操作生成一个窗体
                    Panel panel = new Panel();
                    panel.Size = new Size(475, 110);
                    panel.Location = new Point(5, 5 * (index2 + 1) + 110 * index2);
                    panel.BackColor = Color.LightGray;
                    panel.AutoScroll = true;

                    //向panel中添加信息
                    Label orderID = new Label();
                    orderID.Text = "订单编号:" + myreader.GetString(0);
                    orderID.Location = new Point(5, 5);
                    orderID.AutoSize = true;
                    panel.Name = myreader.GetString(0) + "accpet";
                    panel.Controls.Add(orderID);

                    //目的地;
                    Label endAddress = new Label();
                    endAddress.Text = "目的地:" + myreader.GetString(4);
                    endAddress.Location = new Point(5, 55);
                    endAddress.AutoSize = true;
                    panel.Controls.Add(endAddress);

                    //订单金额;
                    Label orderMoney = new Label();
                    orderMoney.Text = "订单金额:" + myreader.GetValue(5).ToString();
                    orderMoney.Location = new Point(5, 80);
                    panel.Controls.Add(orderMoney);

                    //订单下单时间;
                    Label startTime = new Label();
                    startTime.Text = "下单时间:" + myreader.GetValue(6).ToString();
                    startTime.Location = new Point(220, 5);
                    startTime.AutoSize = true;
                    panel.Controls.Add(startTime);

                    //订单应到时间;
                    Label endTime = new Label();
                    endTime.Text = "到达时间:" + myreader.GetValue(7).ToString();
                    endTime.Location = new Point(220, 30);
                    endTime.AutoSize = true;
                    panel.Controls.Add(endTime);

                    //送货员信息;
                    Label deliverGuyID = new Label();
                    string _deliverGuyID = myreader.GetString(12);
                    if (_deliverGuyID == "g09999")
                    {
                        _deliverGuyID = "***";
                    }
                    deliverGuyID.Text = "送餐员编号:" + _deliverGuyID;
                    deliverGuyID.Location = new Point(150, 55);
                    panel.Controls.Add(deliverGuyID);

                    //获取用户信息
                    string selectStr2 = "select customer_name,customer_phone from customer where customer_id='" + myreader.GetString(2) + "' ";
                    SqlCommand mycmd2 = new SqlCommand(selectStr2, myconn);
                    SqlDataReader informationReader = mycmd2.ExecuteReader();
                    informationReader.Read();
                    Label informationLabel = new Label();
                    informationLabel.AutoSize = true;
                    informationLabel.Location = new Point(5, 30);
                    informationLabel.Text = informationReader.GetString(0) + "    ";
                    //保护用户隐私
                    informationLabel.Text += "尾号:" + informationReader.GetString(1).Substring(informationReader.GetString(1).Length - 4);
                    informationReader.Close();
                    panel.Controls.Add(informationLabel);

                    //获取订单内容;
                    string orderInformation = "订单内容:\n" + myreader.GetString(9);
                    orderInformation += "\n订单备注:\n" + myreader.GetString(10);
                    ToolTip toolTip = new ToolTip();
                    toolTip.SetToolTip(panel, orderInformation);

                    index2++;
                    //panel.Click += new System.EventHandler(panelClick);
                    未配送订单.Controls.Add(panel);
                    未配送订单.AutoScroll = true;
                }
            }
            catch (Exception) { };
            myreader.Close();
            myconn.Close();

            //-------商家个人信息订单-------------------------------------------------------------------------------------------//
            string selectStr3 ="select * from restaurant where restaurant_id='"+resID+"'";
            myCmd.CommandText=selectStr3;
            myconn.Open();
            try
            {
                myreader = myCmd.ExecuteReader();
                while (myreader.Read())
                {
                    textBox1.Text=myreader.GetValue(0).ToString();
                    textBox2.Text = myreader.GetValue(1).ToString();
                    textBox3.Text = myreader.GetValue(3).ToString();
                    textBox4.Text = myreader.GetValue(4).ToString();
                    textBox5.Text = myreader.GetValue(8).ToString();
                    textBox6.Text = myreader.GetValue(5).ToString();
                    textBox7.Text = myreader.GetValue(6).ToString();
                    textBox8.Text = myreader.GetValue(10).ToString();
                    textBox9.Text = myreader.GetValue(7).ToString();
                    if (myreader.GetValue(9).ToString() != "")
                    {
                        pictureBox1.Image = Image.FromFile(myreader.GetValue(9).ToString());
                    }
                    else
                    {
                        pictureBox1.Image = Image.FromFile("1.jpg");
                    }
                }
            }
            catch (Exception) { };
            myreader.Close();
            myconn.Close();

            //-------商家评价-------------------------------------------------------------------
            string evaluationStr = "select orders_comment,orders_score from orders where restaurant_id='" + resID + "'";
            myCmd.CommandText = evaluationStr;
            myconn.Open();
            myreader = myCmd.ExecuteReader();
            try
            {
                int index = 0;
                while (myreader.Read())
                {
                    string evaluation;
                    try
                    {
                        evaluation = myreader.GetString(0);
                    }
                    catch (Exception) { continue; }
                    //利用new操作生成一个窗体
                    Panel panel = new Panel();
                    panel.Size = new Size(480, 100);
                    panel.Location = new Point(5, 5 * (index + 1) + 100 * index);
                    panel.BackColor = Color.LightGray;

                    //信息
                    Label score = new Label();
                    score.Text = "评分:" + myreader.GetValue(1).ToString();
                    score.AutoSize = true;
                    score.Location = new Point(5, 5);
                    panel.Controls.Add(score);

                    //评价;
                    TextBox resEvaluation = new TextBox();
                    resEvaluation.ReadOnly = true;
                    resEvaluation.Multiline = true;
                    resEvaluation.Text = "评价信息:" + evaluation;
                    resEvaluation.Location = new Point(5, 30);
                    resEvaluation.Size = new Size(340, 60);
                    resEvaluation.ScrollBars = ScrollBars.Vertical;
                    panel.Controls.Add(resEvaluation);

                    商家评价.Controls.Add(panel);
                    index++;
                }
            }
            catch (Exception) { };
            myreader.Close();
            myconn.Close();
        }


//-------添加菜-------------------------------------------------------------------------------------------//
        static bool can_add_dish=false;
        private void button1_Click(object sender, EventArgs e)
        {
            can_add_dish=true;
            textBox10.ReadOnly = false;
            textBox11.ReadOnly = false;
            textBox12.ReadOnly = false;
            button2.Visible=true;
            button1.Visible=false;
            label14.Visible=true;
        }

        private void button2_Click(object sender, EventArgs e)
        {


            can_add_dish = false;
            textBox10.ReadOnly = true;
            textBox11.ReadOnly = true;
            textBox12.ReadOnly = true;
            button2.Visible = false;
            button1.Visible = true;
            SqlConnection myconn=new SqlConnection(mystr);
            string dishName=textBox10.Text;
            if (dishName == "")
            {
                MessageBox.Show("菜名不能为空！");
                return;
                
            }
            float dishPrice=0;
            if (textBox11.Text != "")
            {
                dishPrice = float.Parse(textBox11.Text);
            } 
            string dishIntro=textBox12.Text;
            string restaurantID=resID;
            string selectStr="select MAX(dish_id) from dish";
            SqlCommand myCmd2=new SqlCommand(selectStr,myconn);

            string maxID;
            myconn.Open();
            SqlDataReader myreader = myCmd2.ExecuteReader();
            try
            {
                //读取数据
                myreader.Read();
                maxID = myreader.GetString(0);
            }
            catch (Exception) { maxID = "d09999"; }
            myreader.Close();
            maxID = "d" + (int.Parse(maxID.Substring(1)) + 1).ToString();

            string insertStr=String.Format("insert into dish values('{0}','{1}','{2}',{3:G},'{4}','{5}')",
                restaurantID,maxID,dishName,dishPrice,imageFile2,dishIntro);
            myCmd2.CommandText=insertStr;

            try
            {
                //再次执行插入命令
                myCmd2.ExecuteNonQuery();
                //成功执行命令，弹窗提醒用户
                MessageBox.Show("菜品添加成功,刷新后看信息哦~！");
            }
            catch (Exception) {pictureBox2.Image=Image.FromFile(""); };
            //关闭数据库连接
            myconn.Close();

            textBox10.Clear();  
            textBox11.Clear();
            textBox12.Clear();
            pictureBox2.Refresh();
            label14.Visible=true;
        }
        public bool imageFinished = false;
        public bool passwordFinished = false;
        public string imageFile;

        private void label14_Click(object sender, EventArgs e)
        {
            if (can_add_dish == false)
            {
                return;
            }
            //默认路径
            openFileDialog1.InitialDirectory = "C:\\";
            //限制文件格式
            openFileDialog1.Filter = "*.png|*.jpg|*.jpeg|*.bmp";
            //选择文件
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                //设置图片
                imageFile2 = openFileDialog1.FileName;
                pictureBox2.Image = Image.FromFile(imageFile2);
                //图片上传操作完成
                label14.Visible = false;
            }
        }
        private string imageFile2="";
        private void pictureBox2_Click(object sender, EventArgs e)
        {
            if (can_add_dish == false)
            {
                return;
            }
            //默认路径
            openFileDialog1.InitialDirectory = "C:\\";
            //限制文件格式
            openFileDialog1.Filter = "*.png|*.jpg|*.jpeg|*.bmp";
            //选择文件
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                //设置图片
                imageFile2 = openFileDialog1.FileName;
                pictureBox2.Image = Image.FromFile(imageFile2);
                //图片上传操作完成
                label14.Visible = false;
            }
        }

//-------删除菜品-------------------------------------------------------------------------------------------//
        private void deleteButton_Click(object sender,EventArgs e)
        {
            string dishID=((Button)sender).Name;
            string deleteStr="delete from dish where dish_id='"+dishID+"' and restaurant_id='"+resID+"'";
            SqlConnection myconn=new SqlConnection(mystr);
            SqlCommand myCmd=new SqlCommand(deleteStr,myconn);
            myconn.Open();
            {
                try
                {
                    DialogResult result = MessageBox.Show("确认删除此菜品吗?", "提示信息", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                    if (result == DialogResult.OK)
                    {
                        myCmd.ExecuteNonQuery();
                        MessageBox.Show("删除菜品成功!");
                    }
                }
                catch (Exception) { };
            }
            myconn.Close();
        }

        private void refreshForm()
        {          
            商家主界面 fp = new 商家主界面(this.resID);
            fp.Show();
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.refreshForm();
        }


//-------修改信息-------------------------------------------------------------------------------------------//
        static bool can_update_info=false;
        private void button4_Click(object sender, EventArgs e)
        {
            can_update_info = true;
            textBox2.ReadOnly = false;
            textBox3.ReadOnly = false;
            textBox4.ReadOnly = false;
            textBox5.ReadOnly = false;
            textBox6.ReadOnly = false;
            textBox7.ReadOnly = false;
            textBox9.ReadOnly = false;
            button4.Visible=false;
            button5.Visible=true;       
        }

        private void button5_Click(object sender, EventArgs e)
        {
            button4.Visible=true;
            button5.Visible=false;
            can_update_info = false;
            textBox2.ReadOnly = true;
            textBox3.ReadOnly = true;
            textBox4.ReadOnly = true;
            textBox5.ReadOnly = true;
            textBox6.ReadOnly = true;
            textBox7.ReadOnly = true;
            textBox9.ReadOnly = true;
            string name=textBox2.Text;
            string info=textBox3.Text;
            string phone=textBox4.Text;

            string feeStr=textBox5.Text;
            string startTime=textBox6.Text;
            string endTime=textBox7.Text;
            string address=textBox9.Text;

            //检验各项空不空;

            if (name == "")
            {
                MessageBox.Show("商家姓名不能为空!");
                return;
            }
            if (phone == "")
            {
                MessageBox.Show("商家电话不能为空!");
                return;
            }
            if (feeStr == "")
            {
                feeStr="0";
            }
            if (startTime == "")
            {
                startTime="0:00";
            }
            if (endTime == "")
            {
                endTime="24:00";
            }
            if (address == "")
            {
                MessageBox.Show("商家地址不能为空");
            }
            if (imageFile1 == "")
            {
                imageFile1 = "1.jpg";
            }
            //检验电话是否注册过;

            SqlConnection myconn=new SqlConnection(mystr);           
            string check="select restaurant_id from restaurant where restaurant_phone='"+phone+"'"+"and restaurant_id !='"
                +resID+"'";
            SqlCommand myCmd=new SqlCommand(check,myconn);
            myconn.Open();
            SqlDataReader myreader=myCmd.ExecuteReader();
            try
            {
                myreader.Read();
                myreader.GetString(0);
                myreader.Close();
                MessageBox.Show("当前电话号码已注册使用过");
                return;
            }
            catch (Exception) { };
            myconn.Close();
            //发送验证码;

            string update="update restaurant set restaurant_name='"+name+"',"+"restaurant_introduction='"+info+"',"+
                "restaurant_phone='"+phone+"',"+"restaurant_delivery_fee="+float.Parse(feeStr)+","+"restaurant_start_time='"+
                startTime+"',"+"restaurant_end_time='"+endTime+"',"+"restaurant_address='"+address+"',"+
                "restaurant_image='"+imageFile1+"' where restaurant_id='"+resID+"'";
            myCmd.CommandText=update;

            myconn.Open();
  //          try
            {
                myCmd.ExecuteNonQuery();
                MessageBox.Show("更新信息成功！");
            }
  //          catch (Exception) { };
            myconn.Close();


        }
        private string imageFile1="";
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            if (can_update_info == false)
            {
                return;
            }
            //默认路径
            openFileDialog1.InitialDirectory = "C:\\";
            //限制文件格式
            openFileDialog1.Filter = "*.png|*.jpg|*.jpeg|*.bmp";
            //选择文件
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                //设置图片
                imageFile1 = openFileDialog1.FileName;
                pictureBox1.Image = Image.FromFile(imageFile1);
                //图片上传操作完成
                imageFinished = true;
            }
        }
//-------修改菜品信息-------------------------------------------------------------------------------------------//
        static string updateID="";
        private void button6_Click(object sender, EventArgs e)
        {
            string dishID=textBox13.Text;
            SqlConnection myconn=new SqlConnection(mystr);
            string select1="select * from dish where dish_id='"+dishID+"'"+" and restaurant_id='"
                +resID+"'";
            SqlCommand myCmd=new SqlCommand(select1,myconn);
            myconn.Open();
            SqlDataReader myreader=myCmd.ExecuteReader();
            try
            {
                myreader.Read();
                textBox14.Text=myreader.GetString(2);
                textBox15.Text=myreader.GetValue(3).ToString();
                textBox16.Text=myreader.GetString(5);

                string ImageFile;
                if (myreader.GetValue(4).ToString() != "")
                {
                    ImageFile = myreader.GetValue(4).ToString();
                }
                else
                {
                    ImageFile = "1.jpg";
                }
                Image dishFile = Image.FromFile(ImageFile);
                pictureBox3.Image = dishFile;

                updateID =dishID;
                groupBox1.Visible=true;

            }
            catch (Exception) { MessageBox.Show("不存在该菜品信息!");}
            myconn.Close();
        }

        static bool can_update_dish=false;
        private void button7_Click(object sender, EventArgs e)
        {
            can_update_dish = true;
            button8.Visible = true;
            button7.Visible = false;
            textBox14.ReadOnly = false;
            textBox15.ReadOnly = false;
            textBox16.ReadOnly = false;
            textBox13.ReadOnly = true;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            can_update_dish = false;
            button8.Visible = false;
            button7.Visible = true;
            textBox14.ReadOnly = true;
            textBox15.ReadOnly = true;
            textBox16.ReadOnly = true;

            string name=textBox14.Text;
            string priceStr=textBox15.Text;
            string intro=textBox16.Text;
            //检验是否为空;

            if (name == "")
            {
                MessageBox.Show("菜名不能为空!");
                return;
            }
            if (priceStr == "")
            {
                priceStr="0";
            }
            
            SqlConnection myconn=new SqlConnection(mystr);
            string update="update dish set dish_name='"+name+"',"+"dish_price="+float.Parse(priceStr)+","+
                "dish_introduction='"+intro+"',"+"dish_image='"+ ImageDishupdate+ "'"+
                " where dish_id='"+updateID+"'";

            SqlCommand myCmd=new SqlCommand(update,myconn);

            myconn.Open();
            try
            {
                myCmd.ExecuteNonQuery();
                if (priceStr == "")
                {
                    MessageBox.Show("修改完成,请注意该菜品价格免费,请按刷新按钮来显示新添加的美食!~");
                }
                else
                {
                    MessageBox.Show("修改完成,请按刷新按钮来显示新添加的美食!~");
                }
                groupBox1.Visible=false;
            }
            catch (Exception) { };
            
            myconn.Close();
        }

        private string ImageDishupdate="";
        private void pictureBox3_Click(object sender, EventArgs e)
        {
            if (can_update_dish == false)
            {
                return;
            }
            //默认路径
            openFileDialog1.InitialDirectory = "C:\\";
            //限制文件格式
            openFileDialog1.Filter = "*.png|*.jpg|*.jpeg|*.bmp";
            //选择文件
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                //设置图片
                ImageDishupdate = openFileDialog1.FileName;
                pictureBox3.Image = Image.FromFile(ImageDishupdate);
                //图片上传操作完成
            }
        }
//-------商家接单-------------------------------------------------------------------------------------------//
        private void panelClick(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("是否要接本订单?", "提示信息",
                MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (result == DialogResult.Yes)
            {
                SqlConnection myconn=new SqlConnection(mystr);
                 string id=((Panel)sender).Name.Substring(0,6);
                 SqlCommand mycmd=new SqlCommand("update orders set orders_status='b' where orders_id='"+id+"'",myconn);
                myconn.Open();
                try
                {
                    mycmd.ExecuteNonQuery();
                    MessageBox.Show("您已经接受此订单,返回页面刷新可以获得新的信息!~");
                }
                catch (Exception) {  };
                myconn.Close();
            }
                      
        }

        private void button9_Click(object sender, EventArgs e)
        {
            修改密码 fp = new 修改密码(resID);
            fp.ShowDialog();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            timer.Start();
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            if (this.Opacity >= 0.025)
                this.Opacity -= 0.025;
            else
            {
                timer.Stop();
                Application.Exit();
            }
        }
    }
}
