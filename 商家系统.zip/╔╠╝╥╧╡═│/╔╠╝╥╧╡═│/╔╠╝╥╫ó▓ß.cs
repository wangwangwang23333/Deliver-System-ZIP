﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Net;
using System.Runtime.InteropServices;

namespace 商家系统
{
    public partial class 商家注册 : Form
    {
        public 商家注册()
        {
            InitializeComponent();
        }
        public bool imageFinished = false;
        public bool passwordFinished = false;
        public string imageFile;

        //验证码相关
        //发送验证短信相关代码
        private string url = "http://utf8.sms.webchinese.cn/?";
        private string strUid = "Uid=";
        private string strKey = "&key=d41d8cd98f00b204e980";
        private string strMob = "&smsMob=";
        private string strContent = "&smsText=";
        private int yanzhengma;
        private bool yanzhengma_send = false;

        static string mystr = "Initial Catalog = take_out;Data Source = (local);Integrated Security = True;";
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            //默认路径
            openFileDialog1.InitialDirectory = "C:\\";
            //限制文件格式
            openFileDialog1.Filter = "*.png|*.jpg|*.jpeg|*.bmp";
            //选择文件
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                //设置图片
                imageFile = openFileDialog1.FileName;
                pictureBox1.Image = Image.FromFile(imageFile);
                //图片上传操作完成
                imageFinished = true;
                label15.Visible = false;
            }
        }

        private void label15_Click(object sender, EventArgs e)
        {
            //默认路径
            openFileDialog1.InitialDirectory = "C:\\";
            //限制文件格式
            openFileDialog1.Filter = "*.png|*.jpg|*.jpeg|*.bmp";
            //选择文件
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                //设置图片
                imageFile = openFileDialog1.FileName;
                pictureBox1.Image = Image.FromFile(imageFile);
                //图片上传操作完成
                imageFinished = true;
                label15.Visible = false;
            }
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            const int maxName = 10;
            string name = textBox1.Text;
            if (name.Length > maxName)
            {
                MessageBox.Show("昵称长度超过10位,请重新输入,谢谢！");
                textBox1.Clear();
                label7.Visible = true;
                return;
            }
            label7.Visible = false;
        }
        private void textBox2_LostFocus(object sender, EventArgs e)
        {
            const int leastPassword = 8;
            bool flag_number = false;
            bool flag_letter = false;
            string passWord = textBox2.Text;
            if (passWord.Length < leastPassword && passWord != "")
            {
                MessageBox.Show("密码不能少于8位,请重新输入,谢谢！");
                textBox2.Clear();
                label8.Visible = true;
                return;
            }
            for (int i = 0; i < passWord.Length; i++)
            {
                if (flag_number && flag_letter)
                {
                    break;
                }
                if (passWord[i] <= '9' && passWord[i] >= '0')
                {
                    flag_number = true;
                }
                else if ((passWord[i] >= 'A' && passWord[i] <= 'Z') || (passWord[i] >= 'a' && passWord[i] <= 'z'))
                {
                    flag_letter = true;
                }
            }
            if ((!flag_number || !flag_letter) && passWord != "")
            {
                MessageBox.Show("密码不能全为数字或者字母,请重新输入,谢谢！");
                textBox2.Clear();
                label8.Visible = false;
                return;
            }
            if (passWord != "")
            {
                label8.Visible = false;
            }
        }
        private void textBox4_LostFocus(object sender, EventArgs e)
        {
            string phone = textBox4.Text;
            const int num = 11;
            if (phone.Length != num && phone != "")
            {
                MessageBox.Show("手机号码位数不正确,请重新输入,谢谢！");
                textBox4.Clear();
                label10.Visible = true;
                return;
            }
            if (phone != "")
            {
                label10.Visible = false;
            }
        }
        private void textBox8_LostFocus(object sender, EventArgs e)
        {
            string start_hour=textBox8.Text;
            if (Convert.ToInt32(start_hour) < 0 || Convert.ToInt32(start_hour) > 24)
            {
                MessageBox.Show("营业时间不合理！");
                label20.Visible=true;
                return;
            }
        }
        private void textBox9_LostFocus(object sender, EventArgs e)
        {
            string start_min = textBox8.Text;
            if (Convert.ToInt32(start_min) < 0 || Convert.ToInt32(start_min) > 60)
            {
                MessageBox.Show("营业时间不合理！");
                label20.Visible=true;
                return;
            }
        }
        private void textBox11_LostFocus(object sender, EventArgs e)
        {
            string end_min = textBox11.Text;
            if (Convert.ToInt32(end_min) < 0 || Convert.ToInt32(end_min) > 60)
            {
                MessageBox.Show("营业时间不合理！");
                label20.Visible=true;
                return;
            }
            label20.Visible=true;
        }
        private void textBox12_LostFocus(object sender, EventArgs e)
        {
            string end_hour = textBox12.Text;
            if (Convert.ToInt32(end_hour) < 0 || Convert.ToInt32(end_hour) > 24)
            {
                MessageBox.Show("营业时间不合理！");
                label20.Visible=true;
                return;
            }

        }
        private void button1_Click(object sender, EventArgs e)
        {
            string newPassword = textBox2.Text;
            string rePassword = textBox3.Text;
            if (rePassword != newPassword)
            {
                MessageBox.Show("再次输入密码不一致,请重新输入,谢谢！");
                textBox3.Clear();
                label9.Visible = true;
                return;
            }
            label9.Visible = false;

            //验证码
            if (yanzhengma_send == false)
            {
                MessageBox.Show("请发送手机验证码！");
                return;
            }

            //检查验证码是否正确
            if (yanzhengma != int.Parse(textBox13.Text.ToString()))
            {
                MessageBox.Show("验证码错误！");
                return;
            }


            //到此，说明成功操作，执行写入数据库操作
            //连接数据库
            SqlConnection myconn = new SqlConnection(mystr);

            //首先获取当前最大工号，以生成新的工号
            string findStr = "select MAX(restaurant_id) from restaurant";

            //查找工号指令
            SqlCommand mycmd = new SqlCommand(findStr, myconn);

            string maxId;
            //打开数据库连接
            myconn.Open();
            SqlDataReader myreader = mycmd.ExecuteReader();
            try
            {
                //读取数据
                myreader.Read();
                maxId = myreader.GetString(0);
            }
            catch (Exception) { maxId = "r09999"; }
            myreader.Close();

            //首先需要检验手机号以及身份证号在此之前从未注册使用过
            string phone = textBox6.Text + '-' + textBox4.Text;

            if (maxId != "r09999")
            {
                string checkStr = "select restaurant_id from restaurant where restaurant_phone='" + phone + "'";
                mycmd.CommandText = checkStr;
                myreader = mycmd.ExecuteReader();
                try
                {
                    myreader.Read();
                    myreader.GetString(0);
                    myreader.Close();
                    myconn.Close();
                    MessageBox.Show("当前电话号码已注册使用过");
                    return;
                }
                catch (Exception) { };

                myreader.Close();
            }

            //新的工号应在原有工号基础上加一
            maxId = "r" + (int.Parse(maxId.Substring(1)) + 1).ToString();

            string name = textBox1.Text;
            string passWord = textBox2.Text;
            string introduction=textBox7.Text;
            string start_time=textBox8.Text+":"+textBox9.Text;
            string end_time=textBox12.Text+":"+textBox11.Text;      
            string address = textBox5.Text;
            float fee=float.Parse(textBox10.Text);
            //插入命令
            string insertStr = String.Format("insert into restaurant values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}',{8:G},'{9}',{10:G},'{11}')",
                maxId, name,passWord,introduction,phone,start_time,end_time,address,fee,imageFile,0,"a");
            //插入数据
            mycmd.CommandText = insertStr;

            //再次执行插入命令
            mycmd.ExecuteNonQuery();

            //关闭数据库连接
            myconn.Close();

            //成功执行命令，弹窗提醒用户
            MessageBox.Show("成功向管理员发出注册信息,请等待审核通过！您的账号ID信息是"+maxId+"注册手机号是:"+phone);

            //关闭本窗体
            this.Close();     
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection myconn=new SqlConnection(mystr);
            //发送之前，检验手机号是否被使用过
            string phone=textBox6.Text+"-"+textBox4.Text;
            string checkStr = "select restaurant_id from restaurant where restaurant_phone='" + phone + "'";
            SqlCommand mycmd = new SqlCommand(checkStr, myconn);

            myconn.Open();
            SqlDataReader myreader = mycmd.ExecuteReader();
            try
            {
                myreader.Read();
                myreader.GetString(0);
                myreader.Close();
                myconn.Close();
                MessageBox.Show("当前电话号码已注册使用过");
                return;
            }
            catch (Exception) { };
            myconn.Close();
            myreader.Close();
            if (phone.Length > 11)
            {
                int index=phone.Length-11;
                phone=phone.Substring(index,11);
            }

            Random rd = new Random();
            yanzhengma = rd.Next(1000, 9999);
            if (phone.ToString().Trim() != "")
            {
                url = url + strUid + "wangwangwang23333" + strKey + strMob + phone + strContent + "您正在注册使用外卖数据库系统，验证码为" + yanzhengma + "。如该短信非您本人操作，请忽略。";
                string Result = GetHtmlFromUrl(url);

                if (Result == "1")
                {
                    MessageBox.Show("短信已发送！如未收到，请检查是否被拦截或手机欠费！");
                    button2.Enabled = false;
                    yanzhengma_send = true;
                }
                else
                {
                    MessageBox.Show("无法正常发送短信，请检查您的网络是否正常连接或手机号是否正确！");
                }
            }
        }

        public string GetHtmlFromUrl(string url)
        {
            string strRet = null;
            if (url == null || url.Trim().ToString() == "")
            {
                return strRet;
            }
            string targeturl = url.Trim().ToString();
            try
            {
                HttpWebRequest hr = (HttpWebRequest)WebRequest.Create(targeturl);
                hr.UserAgent = "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)";
                hr.Method = "GET";
                hr.Timeout = 30 * 60 * 1000;
                WebResponse hs = hr.GetResponse();
                Stream sr = hs.GetResponseStream();
                StreamReader ser = new StreamReader(sr, Encoding.Default);
                strRet = ser.ReadToEnd();
            }
            catch (Exception)
            {
                strRet = null;
            }
            return strRet;
        }

        #region 无边框拖动效果
        [DllImport("user32.dll")]//拖动无窗体的控件
        public static extern bool ReleaseCapture();
        [DllImport("user32.dll")]
        public static extern bool SendMessage(IntPtr hwnd, int wMsg, int wParam, int lParam);
        public const int WM_SYSCOMMAND = 0x0112;
        public const int SC_MOVE = 0xF010;
        public const int HTCAPTION = 0x0002;

        private void Start_MouseDown(object sender, MouseEventArgs e)
        {
            //拖动窗体
            ReleaseCapture();
            SendMessage(this.Handle, WM_SYSCOMMAND, SC_MOVE + HTCAPTION, 0);
        }
        #endregion
        private void 商家注册_Load(object sender, EventArgs e)
        {

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
