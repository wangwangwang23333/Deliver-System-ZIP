﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Net;
using System.Runtime.InteropServices;

namespace 商家系统
{
    public partial class 忘记密码 : Form
    {

        public bool passwordFinished = false;
        static string mystr = "Initial Catalog = take_out;Data Source = (local);Integrated Security = True;";
        SqlConnection myconn = new SqlConnection(mystr);

            //发送验证短信相关代码
            private string url = "http://utf8.sms.webchinese.cn/?";
            private string strUid = "Uid=";
            private string strKey = "&key=d41d8cd98f00b204e980";
            private string strMob = "&smsMob=";
            private string strContent = "&smsText=";
            private int yanzhengma;
            private bool yanzhengma_send = false;


        #region 无边框拖动效果
        [DllImport("user32.dll")]//拖动无窗体的控件
        public static extern bool ReleaseCapture();
        [DllImport("user32.dll")]
        public static extern bool SendMessage(IntPtr hwnd, int wMsg, int wParam, int lParam);
        public const int WM_SYSCOMMAND = 0x0112;
        public const int SC_MOVE = 0xF010;
        public const int HTCAPTION = 0x0002;

        private void Start_MouseDown(object sender, MouseEventArgs e)
        {
            //拖动窗体
            ReleaseCapture();
            SendMessage(this.Handle, WM_SYSCOMMAND, SC_MOVE + HTCAPTION, 0);
        }
        #endregion

        public 忘记密码()
            {
                InitializeComponent();
            }
            public string GetHtmlFromUrl(string url)
            {
                string strRet = null;
                if (url == null || url.Trim().ToString() == "")
                {
                    return strRet;
                }
                string targeturl = url.Trim().ToString();
                try
                {
                    HttpWebRequest hr = (HttpWebRequest)WebRequest.Create(targeturl);
                    hr.UserAgent = "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)";
                    hr.Method = "GET";
                    hr.Timeout = 30 * 60 * 1000;
                    WebResponse hs = hr.GetResponse();
                    Stream sr = hs.GetResponseStream();
                    StreamReader ser = new StreamReader(sr, Encoding.Default);
                    strRet = ser.ReadToEnd();
                }
                catch (Exception ex)
                {
                    strRet = null;
                }
                return strRet;
            }

            private void textBox3_TextChanged(object sender, EventArgs e)
            {
                //同步更新
                string userPassword = textBox3.Text;
                //检验密码异常
                if (userPassword.Length < 8)
                    label4.Text = "密码需要至少八位";
                else
                {
                    //检验是否同时含有字母和数字
                    bool numberAppear = false;
                    bool wordAppear = false;
                    for (int i = 0; i < userPassword.Length; i++)
                    {
                        if (userPassword[i] >= '0' && userPassword[i] <= '9')
                            numberAppear = true;
                        else if ((userPassword[i] >= 'a' && userPassword[i] <= 'z') ||
                            userPassword[i] >= 'A' && userPassword[i] <= 'Z')
                            wordAppear = true;
                    }
                    //输出提示符
                    if (!numberAppear || !wordAppear)
                        label4.Text = "密码需要同时包含数字和字母";
                    else
                    {
                        label4.Text = "合法的密码";
                        passwordFinished = true;
                        return;
                    }
                }
                passwordFinished = false;
            }

            private void button2_Click(object sender, EventArgs e)
            {
                //确认新密码正常
                if (!passwordFinished)
                {
                    MessageBox.Show("请输入符合要求的新密码！");
                    return;
                }
                //根据手机号检索
                string phone=textBox1.Text;
                if (phone.Length > 11)
                {
                    int index=phone.Length-11;
                    phone=phone.Substring(index,11);
                }
                SqlCommand mycmd = new SqlCommand("select * from restaurant where right(restaurant_phone,11)='" + phone + "'", myconn);
                myconn.Open();
                SqlDataReader myreader = mycmd.ExecuteReader();
                myreader.Read();
                //确认是否存在此手机号
                try
                {
                    myreader.GetValue(0).ToString();
                }
                catch (Exception)
                {
                    myreader.Close();
                    myconn.Close();
                    MessageBox.Show("该手机号未注册过本系统！");
                    return;
                }
                //验证码
                if (yanzhengma_send == false)
                {
                    MessageBox.Show("请发送手机验证码！");
                    return;
                }

                //检查验证码是否正确
                if (yanzhengma != int.Parse(textBox2.Text.ToString()))
                {
                    MessageBox.Show("验证码错误！");
                    return;
                }
                //修改密码
                myreader.Close();
                mycmd.CommandText = "update restaurant set restaurant_password = '" + textBox3.Text + "' where restaurant_phone = '" + textBox1.Text + "'";
                mycmd.ExecuteNonQuery();
                myconn.Close();
                MessageBox.Show("已修改密码！");
                this.Close();
            }

            private void button1_Click(object sender, EventArgs e)
            {
                //先确认该手机号是否注册过该系统
                //根据手机号检索
                string phone = textBox1.Text;
                if (phone.Length > 11)
                {
                    int index = phone.Length - 11;
                    phone = phone.Substring(index, 11);
                }
                string checkStr = "select restaurant_id from restaurant where right(restaurant_phone,11)='" + phone + "'";
                SqlCommand mycmd = new SqlCommand(checkStr, myconn);

                myconn.Open();
                SqlDataReader myreader = mycmd.ExecuteReader();
                try
                {
                    myreader.Read();
                    myreader.GetString(0);
                    myreader.Close();
                    myconn.Close();
                }
                catch (Exception)
                {
                    myconn.Close();
                    myreader.Close();
                    MessageBox.Show("此手机号尚未注册过该系统！");
                    return;
                }

                Random rd = new Random();
                yanzhengma = rd.Next(1000, 9999);
                if (phone.ToString().Trim() != "")
                {
                    url = url + strUid + "wangwangwang23333" + strKey + strMob + phone + strContent + "您正在注册使用外卖数据库系统，验证码为" + yanzhengma + "。如该短信非您本人操作，请忽略。";
                    string Result = GetHtmlFromUrl(url);

                    if (Result == "1")
                    {
                        MessageBox.Show("短信已发送！如未收到，请检查是否被拦截或手机欠费！");
                        button1.Enabled = false;
                        yanzhengma_send = true;
                    }
                    else
                    {
                        MessageBox.Show("无法正常发送短信，请检查您的网络是否正常连接或手机号是否正确！");
                    }
                }
            }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
