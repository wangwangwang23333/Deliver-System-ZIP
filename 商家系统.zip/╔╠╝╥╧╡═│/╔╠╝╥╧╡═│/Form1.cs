﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Runtime.InteropServices;

namespace 商家系统
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        #region 无边框拖动效果
        [DllImport("user32.dll")]//拖动无窗体的控件
        public static extern bool ReleaseCapture();
        [DllImport("user32.dll")]
        public static extern bool SendMessage(IntPtr hwnd, int wMsg, int wParam, int lParam);
        public const int WM_SYSCOMMAND = 0x0112;
        public const int SC_MOVE = 0xF010;
        public const int HTCAPTION = 0x0002;

        private void Start_MouseDown(object sender, MouseEventArgs e)
        {
            //拖动窗体
            ReleaseCapture();
            SendMessage(this.Handle, WM_SYSCOMMAND, SC_MOVE + HTCAPTION, 0);
        }
        #endregion

        private void Form1_Load(object sender, EventArgs e)
        {
            label4.Parent = pictureBox2;
            pictureBox1.Parent = pictureBox2;

            //读取文件信息
            StreamReader sr = new StreamReader("restaurantinformation.txt");
            string userName = sr.ReadLine();
            if (userName != "null")
            {
                checkBox2.Checked = true;
                textBox1.Text = userName;
                textBox2.Text = sr.ReadLine();
            }
            else
            {
                checkBox2.Checked = false;
            }
            sr.Close();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            string id = textBox1.Text;
            string passWord = textBox2.Text;
            string selectStr;

            if (id == "" || passWord == "")
                return;

            if (id[0] == 'r')
            {
                //账号登陆;
                selectStr = "select restaurant_passWord,restaurant_status,restaurant_id from restaurant where restaurant_id='" + id + "'";
            }
            else if (id.Length == 11)
            {
                //末尾手机号;
                selectStr = "select restaurant_passWord,restaurant_status,restaurant_id from restaurant where right(restaurant_phone,11)='" + id + "'";
            }
            else
            {
                selectStr = "select restaurant_passWord,restaurant_status,restaurant_id from restaurant where restaurant_phone='" + id + "'";
            }

            const string mystr = "Initial Catalog = take_out;Data Source = (local);Integrated Security = True;";
            SqlConnection myconn = new SqlConnection(mystr);

            SqlCommand myCmd = new SqlCommand(selectStr, myconn);

            string newPassWord;
            string status;
            string rID;
            //打开数据库连接
            myconn.Open();
            SqlDataReader myreader = myCmd.ExecuteReader();
            try
            {
                //读取数据
                myreader.Read();
                newPassWord = myreader.GetString(0);
                status = myreader.GetString(1);
                rID = myreader.GetString(2);
            }
            catch (Exception)
            {
                MessageBox.Show("不存在此商家,请检查账号重新输入,谢谢!");
                return;
            }
            myreader.Close();

            if (passWord != newPassWord)
            {
                MessageBox.Show("密码不正确,请重新输入!");
                return;
            }

            //如果勾选了记住密码，则存储到本地文件
            if (checkBox2.Checked == true)
            {
                StreamWriter sr = new StreamWriter("restaurantinformation.txt", false);
                sr.WriteLine(textBox1.Text);
                sr.WriteLine(textBox2.Text);
                sr.Close();
            }
            else
            {
                StreamWriter sr = new StreamWriter("restaurantinformation.txt", false);
                sr.WriteLine("null");
                sr.Close();
            }

            //封禁状态;
            if (status == "a")
            {
                MessageBox.Show("您好,现在你的餐馆申请处于待审核状态,请及时与管理员联系通过审核,谢谢您的配合!");
                textBox1.Clear();
                textBox2.Clear();
                return;
            }
            else if (status == "c")
            {
                MessageBox.Show("您好,现在你的餐馆已经处于封禁状态,请及时与管理员联系解除,谢谢！~");
                textBox1.Clear();
                textBox2.Clear();
                return;
            }
            else if (status == "d")
            {
                MessageBox.Show("您好,您的餐馆申请审核未通过,请考虑你的信息是否完整正确,谢谢您的配合~!");
                textBox1.Clear();
                textBox2.Clear();
                return;
            }

            商家主界面 fp1 = new 商家主界面(rID);
            this.Hide();
            fp1.ShowDialog();
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            商家注册 fp2 = new 商家注册();
            fp2.ShowDialog();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            忘记密码 fp = new 忘记密码();
            fp.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox2.PasswordChar == '●')
            {
                textBox2.PasswordChar = '\0';
                button3.Image = Image.FromFile("yanjingzheng.png");
            }
            else
            {
                textBox2.PasswordChar = '●';
                button3.Image = Image.FromFile("yanjingbi.png");
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            timer.Start();
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            if (this.Opacity >= 0.025)
                this.Opacity -= 0.025;
            else
            {
                timer.Stop();
                this.Close();
            }
        }
    }
}
