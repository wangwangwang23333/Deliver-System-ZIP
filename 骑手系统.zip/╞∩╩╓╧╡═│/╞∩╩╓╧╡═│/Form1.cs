﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Runtime.InteropServices;
using System.IO;

namespace 骑手系统
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        #region 无边框拖动效果
        [DllImport("user32.dll")]//拖动无窗体的控件
        public static extern bool ReleaseCapture();
        [DllImport("user32.dll")]
        public static extern bool SendMessage(IntPtr hwnd, int wMsg, int wParam, int lParam);
        public const int WM_SYSCOMMAND = 0x0112;
        public const int SC_MOVE = 0xF010;
        public const int HTCAPTION = 0x0002;

        private void Start_MouseDown(object sender, MouseEventArgs e)
        {
            //拖动窗体
            ReleaseCapture();
            SendMessage(this.Handle, WM_SYSCOMMAND, SC_MOVE + HTCAPTION, 0);
        }
        #endregion
        private void btnClose_Click(object sender, EventArgs e)
        {
            timer.Start();
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            if (this.Opacity >= 0.025)
                this.Opacity -= 0.025;
            else
            {
                timer.Stop();
                this.Close();
            }
        }


        private void linkLabel2_LinkClicked_1(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //打开新窗体
            骑手注册 fp = new 骑手注册();
            this.Hide();
            fp.Owner = this;
            fp.ShowDialog();
            
        }

        private void linkLabel1_LinkClicked_1(object sender, LinkLabelLinkClickedEventArgs e)
        {
            忘记密码 fp = new 忘记密码();
            this.Hide();
            fp.Owner = this;
            fp.ShowDialog();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            if (textBox2.PasswordChar == '●')
            {
                textBox2.PasswordChar = '\0';
                button3.Image = Image.FromFile("yanjingzheng.png");
            }
            else
            {
                textBox2.PasswordChar = '●';
                button3.Image = Image.FromFile("yanjingbi.png");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //设置背景色
            pictureBox1.Parent = pictureBox2;
            label3.Parent = pictureBox2;
            btnClose.Parent = pictureBox2;

            //读取登陆过的账号信息
            StreamReader sr = new StreamReader("uername.txt");
            while (sr.Peek() != -1)
            {
                comboBox1.Items.Add(sr.ReadLine());
            }
            sr.Close();

            //comboBox默认取最后一次登录信息
            StreamReader sr2 = new StreamReader("defaultLog.txt");
            while (sr2.Peek() != -1)
            {
                comboBox1.Text = sr2.ReadLine();
                //查看defaulLog是否有默认密码
                try
                {
                    StreamReader sr3 = new StreamReader("user" + comboBox1.Text + ".txt");
                    string userPassword = sr3.ReadLine();
                    if (userPassword != "null")
                        //非null，表示有密码
                    {
                        textBox2.Text = userPassword;
                        //如果到这里都正常，说明默认选择勾选了记住密码
                        checkBox2.Checked = true;
                    }
                    sr3.Close();
                }
                catch (Exception) { };
            }
            sr2.Close();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //读取用户名及密码信息
            string userName = comboBox1.Text;
            string userPassword = textBox2.Text;

            //检验不为空
            if (userName == "" || userPassword == "")
                return;

            //连接数据库
            const string mystr = "Data Source=DESKTOP-4U1M65K;Initial Catalog=take_out;Integrated Security=True";
            SqlConnection myconn = new SqlConnection(mystr);

            //确认输入的账号是手机号还是ID
            string findStr;
            if (userName[0] == 'g')
            {
                findStr = "select deliverGuy_password from deliverGuy where deliverGuy_id='" + userName + "'";
            }
            else
            {
                findStr = "select deliverGuy_password from deliverGuy where deliverGuy_phone='" + userName + "'";
            }

            //正确的密码
            string correctPassword;

            SqlCommand mycmd = new SqlCommand(findStr, myconn);

            myconn.Open();
            //读取数据
            SqlDataReader myreader = mycmd.ExecuteReader();
            myreader.Read();
            try
            {
                correctPassword = myreader.GetString(0);
                myreader.Close();
                myconn.Close();
            }
            catch (Exception)
            {
                myreader.Close();
                myconn.Close();
                MessageBox.Show("不存在当前账号，请使用用户ID或者手机号进行登录");
                return;
            }


            //验证密码正确性
            if (correctPassword != userPassword)
            {
                MessageBox.Show("密码错误");
                return;
            }

            //至此，输入全部正确，确认送餐员状态
            if (userName[0] == 'g')
            {
                mycmd.CommandText = "select deliverGuy_status from deliverGuy where deliverGuy_id='" + userName + "'";
            }
            else
            {
                mycmd.CommandText = "select deliverGuy_status from deliverGuy where deliverGuy_phone='" + userName + "'";
            }
            myconn.Open();
            findStr = mycmd.ExecuteScalar().ToString();
            myconn.Close();

            //登录成功才会保存 账号 信息
            
            //先读一读看看是不是这个账号以前存过
            StreamReader srs = new StreamReader("uername.txt");
            bool exists = false;
            while(srs.Peek()!=-1)
            {
                if (srs.ReadLine() == userName)
                {
                    exists = true;
                    break;
                }
            }
            srs.Close();
            if(exists==false)
            {
                StreamWriter sw = new StreamWriter("uername.txt", true);
                sw.WriteLine(userName);
                sw.Close();
            }

            StreamWriter sw2 = new StreamWriter("defaultLog.txt",false);
            sw2.WriteLine(userName);
            sw2.Close();

            if (checkBox2.Checked==true)
            {
                //选择了记住密码,写入
                StreamWriter sw3 = new StreamWriter("user" + userName + ".txt", false);
                sw3.WriteLine(textBox2.Text);
                sw3.Close();
            }
            else
            {
                StreamWriter sw3 = new StreamWriter("user" + userName + ".txt", false);
                sw3.WriteLine("null");
                sw3.Close();
            }

            if (findStr == "b")
            {
                送餐后台 fp = new 送餐后台(userName);
                fp.Show();
                this.Hide();
               
                
            }
            else if (findStr == "a")
            {
                异常状态 fp = new 异常状态('a');
                fp.Show();
                this.Hide();
            }
            else if (findStr == "c")
            {
                异常状态 fp = new 异常状态('c');
                fp.Show();
                this.Hide();
            }
            else
            {
                异常状态 fp = new 异常状态('d');
                fp.Show();
                this.Hide();
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //每选一个，就查看是不是存在密码被保存
            try
            {
                StreamReader sr3 = new StreamReader("user" + comboBox1.Text + ".txt");
                string userPassword = sr3.ReadLine();
                if (userPassword != "null")
                //非null，表示有密码
                {
                    textBox2.Text = userPassword;
                    //如果到这里都正常，说明默认选择勾选了记住密码
                    checkBox2.Checked = true;
                }
                sr3.Close();
            }
            catch (Exception) { };
            
        }
    }
}
