﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Runtime.InteropServices;

namespace 骑手系统
{
    public partial class 送餐后台 : Form
    {
        string userID;
        const string mystr = "Data Source=DESKTOP-4U1M65K;Initial Catalog=take_out;Integrated Security=True;MultipleActiveResultSets=true";
        SqlConnection myconn = new SqlConnection(mystr);
        public 送餐后台(string inputID)
        {
            this.userID = inputID;
            InitializeComponent();
        }

        #region 无边框拖动效果
        [DllImport("user32.dll")]//拖动无窗体的控件
        public static extern bool ReleaseCapture();
        [DllImport("user32.dll")]
        public static extern bool SendMessage(IntPtr hwnd, int wMsg, int wParam, int lParam);
        public const int WM_SYSCOMMAND = 0x0112;
        public const int SC_MOVE = 0xF010;
        public const int HTCAPTION = 0x0002;

        private void Start_MouseDown(object sender, MouseEventArgs e)
        {
            //拖动窗体
            ReleaseCapture();
            SendMessage(this.Handle, WM_SYSCOMMAND, SC_MOVE + HTCAPTION, 0);
        }
        #endregion

        private void 送餐后台_Load(object sender, EventArgs e)
        {
            tabControl1.DrawItem += new DrawItemEventHandler(tabControl1_DrawItem);


            //确认输入的账号是手机号还是ID
            string findStr;
            if (userID[0] == 'g')
            {
                findStr = "select deliverGuy_name from deliverGuy where deliverGuy_id='" + userID + "'";
            }
            else
            {
                findStr = "select deliverGuy_name from deliverGuy where deliverGuy_phone='" + userID + "'";
            }

            //数据库连接
            myconn.Open();
            SqlCommand mycmd = new SqlCommand(findStr, myconn);
            SqlDataReader myreader = mycmd.ExecuteReader();
            myreader.Read();
            string warnWord = myreader.GetString(0) + "先生，";
            myreader.Close();
            myconn.Close();

            //如果用户名是手机号，将其更改为账号
            if (userID[0] != 'g')
            {
                myconn.Open();
                mycmd.CommandText = "select deliverGuy_id from deliverGuy where deliverGuy_phone='" + userID + "'";
                userID = mycmd.ExecuteScalar().ToString();
                myconn.Close();
            }
            
            
            //个人信息界面
            label2.Text += userID;
            //获取个人平均分
            mycmd.CommandText = "select AVG(orders_score) from orders where deliverGuy_id='" + userID + "'";
            myconn.Open();
            if (mycmd.ExecuteScalar().ToString().Length!=0)
            {
                label3.Text += mycmd.ExecuteScalar().ToString();
            }
            else
            {
                label3.Text += "您尚未完成任何外卖单，没有评分";
            }
            myconn.Close();

            //获取个人头像
            findStr = "select deliverGuy_image from deliverGuy where deliverGuy_id='" + userID + "'";

            //数据库连接
            myconn.Open();
            mycmd.CommandText = findStr;
            myreader = mycmd.ExecuteReader();
            myreader.Read();
            try
            {
                pictureBox1.Image = Image.FromFile(myreader.GetString(0));
            }
            catch(Exception)
            {
                pictureBox1.Image = Image.FromFile("yonghutouxiang.png");
            }
            myreader.Close();
            myconn.Close();

            //获取系统时间
            int hour = DateTime.Now.Hour;
            if (hour < 6)
                warnWord += "已经是深夜了，赚钱的时候也要记得好好休息哦！";
            else if (hour < 9)
                warnWord += "早上好！新的一天也要加油呀！";
            else if (hour < 11)
                warnWord += "上午好，一起努力吧！";
            else if (hour < 14)
                warnWord += "中午好，工作的时候也要记得好好吃饭！";
            else if (hour < 18)
                warnWord += "下午好，一起努力吧！";
            else if (hour < 21)
                warnWord += "晚上好，要记得按时吃饭哦！";
            else
                warnWord += "已经是深夜了，赚钱的时候也要记得好好休息哦！";

            //显示提示语
            label1.Size = new Size(200, 100);
            label1.Text = warnWord;

            //获取所有状态为'b'的订单，加载到界面中
            mycmd.CommandText = "select * from orders where orders_status='b'";
            //读取数据
            myconn.Open();
            myreader = mycmd.ExecuteReader();
            int index = 0;
            while(myreader.Read())
            {
                //利用new操作生成一个窗体
                Panel panel = new Panel();
                panel.Size = new Size(550, 120);
                panel.Location = new Point(5, 5 * (index + 1) + 120 * index);
                panel.BackColor = Color.WhiteSmoke;

                //向panel中添加信息
                Label orderLabel = new Label();
                orderLabel.Text = "订单编号:" + myreader.GetString(0);
                orderLabel.AutoSize = true;
                orderLabel.Location = new Point(5, 5);
                panel.Controls.Add(orderLabel);
                //地址信息
                Label placeLabel = new Label();
                placeLabel.Text = myreader.GetString(3) + "  至  " + myreader.GetString(4);
                placeLabel.AutoSize = true;
                placeLabel.Location = new Point(5, 55);
                panel.Controls.Add(placeLabel);
                //送达时间
                Label requireTimeLabel = new Label();
                requireTimeLabel.Text = "预期送达时间:" + myreader.GetValue(7).ToString();
                requireTimeLabel.AutoSize = true;
                requireTimeLabel.Location = new Point(5, 80);
                panel.Controls.Add(requireTimeLabel);

                //订单信息
                string orderInformation = /*"订单内容:\n";*/myreader.GetString(9);
                //将orderContent按照逗号分隔
                //string[] orderContent = myreader.GetString(9).Split(',');
                //for (int i = 0; i < orderContent.Length; i++)
                //{
                //    if (i != 0)
                //        orderInformation += ",";
                //    SqlCommand orderCommand = new SqlCommand("select dish_name from dish where dish_id='" + orderContent[i] + "'", myconn);
                //    //获取对应菜品名
                //    orderInformation += orderCommand.ExecuteScalar().ToString();
                //}
                //备注信息
                orderInformation += "\n订单备注:\n" + myreader.GetString(10);
                ToolTip toolTip = new ToolTip();
                toolTip.SetToolTip(panel, orderInformation);

                //按钮控件
                Button acceptButton = new Button();
                acceptButton.Name = myreader.GetString(0);
                acceptButton.Size = new Size(30, 70);
                acceptButton.Text = "接单";
                acceptButton.Location = new Point(500, 20);
                acceptButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.acceptEvent);
                panel.Controls.Add(acceptButton);

                //获取餐厅名
                Label restaurantLabel = new Label();
                restaurantLabel.AutoSize = true;
                restaurantLabel.Location = new Point(200, 5);
                SqlCommand mycmds = new SqlCommand("select restaurant_name from restaurant where restaurant_id='" + myreader.GetString(1) + "'", myconn);
                restaurantLabel.Text = mycmds.ExecuteNonQuery().ToString();
                panel.Controls.Add(requireTimeLabel);

                //获取用户信息
                mycmds.CommandText = "select customer_name,customer_phone from customer where customer_id='" + myreader.GetString(2) + "'";
                SqlDataReader informationReader = mycmds.ExecuteReader();
                informationReader.Read();
                Label informationLabel = new Label();
                informationLabel.AutoSize = true;
                informationLabel.Location = new Point(5, 30);
                informationLabel.Text = informationReader.GetString(0) + "    ";
                //保护用户隐私
                informationLabel.Text += "尾号:" + informationReader.GetString(1).Substring(informationReader.GetString(1).Length - 4);
                informationReader.Close();
                panel.Controls.Add(informationLabel);

                index++;
                tabPage2.Controls.Add(panel);
            }
            myreader.Close();
            myconn.Close();
            
            //下面加载已接订单
            //获取所有状态为'b'的订单，加载到界面中
            mycmd.CommandText = "select * from orders where deliverGuy_id='"+userID+"' and orders_status='c'";
            //读取数据
            myconn.Open();
            myreader = mycmd.ExecuteReader();
            int acceptIndex = 0;
            while (myreader.Read())
            {
                //利用new操作生成一个窗体
                Panel panel = new Panel();
                panel.Size = new Size(550, 120);
                panel.Location = new Point(5, 5 * (acceptIndex + 1) + 120 * acceptIndex);
                panel.BackColor = Color.WhiteSmoke;

                //向panel中添加信息
                Label orderLabel = new Label();
                orderLabel.Text = "订单编号:" + myreader.GetString(0);
                orderLabel.Location = new Point(5, 5);
                orderLabel.AutoSize = true;
                panel.Controls.Add(orderLabel);
                //地址信息
                Label placeLabel = new Label();
                placeLabel.Text = myreader.GetString(3) + "  至  " + myreader.GetString(4);
                placeLabel.AutoSize = true;
                placeLabel.Location = new Point(5, 55);
                panel.Controls.Add(placeLabel);
                //送达时间
                Label requireTimeLabel = new Label();
                requireTimeLabel.Text = "预期送达时间:" + myreader.GetValue(7).ToString();
                requireTimeLabel.AutoSize = true;
                requireTimeLabel.Location = new Point(5, 80);
                panel.Controls.Add(requireTimeLabel);

                //订单信息
                string orderInformation = myreader.GetString(9);

                //备注信息
                orderInformation += "\n订单备注:\n" + myreader.GetString(10);
                ToolTip toolTip = new ToolTip();
                toolTip.SetToolTip(panel, orderInformation);

                //按钮控件
                Button arriveButton = new Button();
                arriveButton.Name = myreader.GetString(0);
                arriveButton.Size = new Size(30, 70);
                arriveButton.Text = "送达";
                arriveButton.Location = new Point(500, 20);
                arriveButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.arriveEvent);
                panel.Controls.Add(arriveButton);

                //获取餐厅名
                Label restaurantLabel = new Label();
                restaurantLabel.AutoSize = true;
                restaurantLabel.Location = new Point(200, 5);
                SqlCommand mycmds = new SqlCommand("select restaurant_name from restaurant where restaurant_id='" + myreader.GetString(1) + "'", myconn);
                restaurantLabel.Text = mycmds.ExecuteNonQuery().ToString();
                panel.Controls.Add(requireTimeLabel);

                //获取用户信息
                mycmds.CommandText = "select customer_name,customer_phone from customer where customer_id='" + myreader.GetString(2) + "'";
                SqlDataReader informationReader = mycmds.ExecuteReader();
                informationReader.Read();
                Label informationLabel = new Label();
                informationLabel.AutoSize = true;
                informationLabel.Location = new Point(5, 30);
                informationLabel.Text = informationReader.GetString(0) + "    ";
                //保护用户隐私
                informationLabel.Text += "尾号:" + informationReader.GetString(1).Substring(informationReader.GetString(1).Length - 4);
                informationReader.Close();
                panel.Controls.Add(informationLabel);

                acceptIndex++;
                tabPage1.Controls.Add(panel);
            }
            myreader.Close();

            //获取总计完成订单数
            mycmd.CommandText = "select count(*) from orders where deliverGuy_id='" + userID + "' and orders_status='d'";
            label4.Text += mycmd.ExecuteScalar().ToString();

            myconn.Close();


        }


        //接单事件
        protected void acceptEvent(object sender,MouseEventArgs e)
        {
            //获取该单信息
            string name = ((Button)sender).Name;
            
            //如果是左键被按下
            if (e.Button == MouseButtons.Left)
            {
                //查看该单是否仍然存在
                SqlCommand mycmd = new SqlCommand("select orders_status from orders where orders_id = '" + name + "'", myconn);
                myconn.Open();
                if(mycmd.ExecuteScalar().ToString()!="b")
                {
                    if (MessageBox.Show("该订单已不存在，是否刷新窗体？", "该单已不存在", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        myconn.Close();
                        this.refreshForm();
                    }
                    return;
                }


                //存在，接单，更改订单相关信息
                if (MessageBox.Show("您确认要接受此单吗？", "接单提醒", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    
                    //修改订单状态
                    mycmd.CommandText = "update orders set orders_status = 'c', deliverGuy_id = '" + userID + "' where orders_id = '" + name + "'";
                    mycmd.ExecuteNonQuery();
                    myconn.Close();

                    //询问是否需要刷新界面
                    if (MessageBox.Show("您接受了一个新的订单，是否更新订单信息？", "订单需要被更新", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        this.refreshForm();
                    }
                }
                else
                {
                    myconn.Close();
                    return;
                }
            }
        }

        //送达事件
        protected void arriveEvent(object sender,MouseEventArgs e)
        {
            //获取该单信息
            string name = ((Button)sender).Name;

            //如果左键被按下
            if(e.Button == MouseButtons.Left)
            {
                if (MessageBox.Show("您确定订单已送达吗？如尚未送达，将有可能影响您的个人评分", "订单送到", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    //更改订单信息
                    myconn.Open();
                    SqlCommand mycmd = new SqlCommand("update orders set orders_truly_end_time = GETDATE(), orders_status = 'd' where orders_id = '" + name + "'", myconn);
                    mycmd.ExecuteNonQuery();
                    myconn.Close();

                    //询问是否刷新界面
                    if (MessageBox.Show("您完成了一个新的订单，是否更新订单信息？", "订单需要被更新", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        this.refreshForm();
                    }
                }
            }
        }

        //刷新窗体
        private void refreshForm()
        {
            this.Close();
            送餐后台 fp = new 送餐后台(this.userID);
            fp.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.refreshForm();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            timer.Start();
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            if (this.Opacity >= 0.025)
                this.Opacity -= 0.025;
            else
            {
                timer.Stop();
                Application.Exit();
            }
        }

        private void tabControl1_DrawItem(object sender, DrawItemEventArgs e)
        {
            StringFormat sf = new StringFormat();

            #region 头背景
            sf.LineAlignment = StringAlignment.Center;
            sf.Alignment = StringAlignment.Center;
            Rectangle rec = tabControl1.ClientRectangle;
            //获取背景图片，我的背景图片在项目资源文件中。
            Image backImage = Properties.Resources.UnselectedIndex;
            e.Graphics.DrawImage(backImage, 0, 2, tabControl1.Width, tabControl1.ItemSize.Height + 2);
            #endregion
            #region  设置选择的标签的背景
            if (e.Index == tabControl1.SelectedIndex)
                e.Graphics.DrawImage(Properties.Resources.selectedIndex, e.Bounds.X, e.Bounds.Y, e.Bounds.Width, e.Bounds.Height);
            else
                e.Graphics.DrawImage(Properties.Resources.UnselectedIndex, e.Bounds.X, e.Bounds.Y, e.Bounds.Width, e.Bounds.Height);
            e.Graphics.DrawString(((TabControl)sender).TabPages[e.Index].Text,
            System.Windows.Forms.SystemInformation.MenuFont, new SolidBrush(Color.Black), e.Bounds, sf);
            #endregion
            #region 重写标签名
            ColorConverter colorConverter = new ColorConverter();
            Color cwhite = (Color)colorConverter.ConvertFromString("#2178ba");
            SolidBrush white = new SolidBrush(cwhite);

            Rectangle rect0 = tabControl1.GetTabRect(0);
            Rectangle rect1 = tabControl1.GetTabRect(1);
            Rectangle rect2 = tabControl1.GetTabRect(2);

            StringFormat stringFormat = new StringFormat();
            stringFormat.Alignment = StringAlignment.Center;
            stringFormat.LineAlignment = StringAlignment.Center;

            e.Graphics.DrawString("正在送餐", new Font("微软雅黑", 12), white, rect0, stringFormat);           
            e.Graphics.DrawString("当前可接", new Font("微软雅黑", 12), white, rect1, stringFormat);           
            e.Graphics.DrawString("个人信息", new Font("微软雅黑", 12), white, rect2, stringFormat);           
            
            #endregion

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            查看全部订单 fp = new 查看全部订单(userID);
            fp.Owner = this;
            this.Hide();
            fp.ShowDialog();
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //默认路径
            openFileDialog1.InitialDirectory = "C:\\";
            //限制文件格式
            openFileDialog1.Filter = "*.png|*.jpg|*.jpeg|*.bmp";
            //选择文件
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                //设置图片
                string imageFile = openFileDialog1.FileName;
                pictureBox1.Image = Image.FromFile(imageFile);
                //数据库修改
                SqlCommand mycmd = new SqlCommand("update deliverGuy set deliverGuy_image = '" + imageFile + "' where deliverGuy_id = '" + userID + "'", myconn);
                myconn.Open();
                mycmd.ExecuteNonQuery();
                myconn.Close();
                //弹窗提醒修改成功
                MessageBox.Show("修改成功！");
            }
        }

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            修改个人密码 fp = new 修改个人密码(userID);
            this.Hide();
            fp.Owner = this;
            fp.ShowDialog();
        }

    }
}
