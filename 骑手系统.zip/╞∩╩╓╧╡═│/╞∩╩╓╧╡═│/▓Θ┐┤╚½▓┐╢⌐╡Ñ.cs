﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Runtime.InteropServices;

namespace 骑手系统
{
    public partial class 查看全部订单 : Form
    {
        public string userID;
        const string mystr = "Data Source=DESKTOP-4U1M65K;Initial Catalog=take_out;Integrated Security=True;MultipleActiveResultSets=true";
        SqlConnection myconn = new SqlConnection(mystr);
        public 查看全部订单(string userId)
        {
            userID = userId;
            InitializeComponent();
        }

        private void 查看全部订单_Load(object sender, EventArgs e)
        {
            //获取所有状态为'd'的订单，加载到界面中
            SqlCommand mycmd = new SqlCommand("select * from orders where orders_status='d' and deliverGuy_id='" + userID + "'", myconn);
            //读取数据
            myconn.Open();
            SqlDataReader myreader = mycmd.ExecuteReader();
            int index = 0;
            while (myreader.Read())
            {
                //利用new操作生成一个窗体
                Panel panel = new Panel();
                panel.Size = new Size(330, 125);
                panel.Location = new Point(5, 5 * (index + 1) + 100 * index);
                panel.BackColor = Color.WhiteSmoke;

                //向panel中添加信息
                Label orderLabel = new Label();
                orderLabel.Text = "订单编号:" + myreader.GetString(0);
                orderLabel.Location = new Point(5, 5);
                panel.Controls.Add(orderLabel);
                //地址信息
                Label placeLabel = new Label();
                placeLabel.Text = myreader.GetString(3) + "  至  " + myreader.GetString(4);
                placeLabel.AutoSize = true;
                placeLabel.Location = new Point(5, 55);
                panel.Controls.Add(placeLabel);
                //送达时间
                Label requireTimeLabel = new Label();
                requireTimeLabel.Text = "预期送达时间:" + myreader.GetValue(7).ToString();
                requireTimeLabel.AutoSize = true;
                requireTimeLabel.Location = new Point(5, 80);
                panel.Controls.Add(requireTimeLabel);
                //实际送达时间
                Label trueTimeLabel = new Label();
                trueTimeLabel.Text = "实际送达时间:" + myreader.GetValue(8).ToString();
                trueTimeLabel.AutoSize = true;
                trueTimeLabel.Location = new Point(5, 105);
                panel.Controls.Add(trueTimeLabel);

                //订单信息
                string orderInformation = myreader.GetString(9);
                //备注信息
                orderInformation += "\n订单备注:\n" + myreader.GetString(10);
                //用户评价
                try
                {
                    orderInformation += "\n用户评价:\n" + myreader.GetString(14);
                }
                catch (Exception)
                {
                    orderInformation += "\n用户评价:\n用户未给出评价";
                }
                ToolTip toolTip = new ToolTip();
                toolTip.SetToolTip(panel, orderInformation);

                //获取餐厅名
                Label restaurantLabel = new Label();
                restaurantLabel.AutoSize = true;
                restaurantLabel.Location = new Point(200, 5);
                SqlCommand mycmds = new SqlCommand("select restaurant_name from restaurant where restaurant_id='" + myreader.GetString(1) + "'", myconn);
                restaurantLabel.Text = mycmds.ExecuteNonQuery().ToString();
                panel.Controls.Add(requireTimeLabel);

                //获取用户信息
                mycmds.CommandText = "select customer_name,customer_phone from customer where customer_id='" + myreader.GetString(2) + "'";
                SqlDataReader informationReader = mycmds.ExecuteReader();
                informationReader.Read();
                Label informationLabel = new Label();
                informationLabel.AutoSize = true;
                informationLabel.Location = new Point(5, 30);
                informationLabel.Text = informationReader.GetString(0) + "    ";
                //保护用户隐私
                informationLabel.Text += "尾号:" + informationReader.GetString(1).Substring(informationReader.GetString(1).Length - 4);
                informationReader.Close();
                panel.Controls.Add(informationLabel);

                //获取订单评分(倘若用户给了的话)
                if(myreader.GetValue(11)!=null)
                {
                    Label scoreLabel = new Label();
                    scoreLabel.Text = myreader.GetValue(11).ToString();
                    scoreLabel.AutoSize = true;
                    scoreLabel.Location = new Point(270, 50);
                    scoreLabel.Font = new Font("宋体", 20);
                    panel.Controls.Add(scoreLabel);
                }

                index++;
                flowLayoutPanel1.Controls.Add(panel);
            }
            myreader.Close();
            myconn.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Owner.Show();
            this.Close();
        }

        #region 无边框拖动效果
        [DllImport("user32.dll")]//拖动无窗体的控件
        public static extern bool ReleaseCapture();
        [DllImport("user32.dll")]
        public static extern bool SendMessage(IntPtr hwnd, int wMsg, int wParam, int lParam);
        public const int WM_SYSCOMMAND = 0x0112;
        public const int SC_MOVE = 0xF010;
        public const int HTCAPTION = 0x0002;

        private void Start_MouseDown(object sender, MouseEventArgs e)
        {
            //拖动窗体
            ReleaseCapture();
            SendMessage(this.Handle, WM_SYSCOMMAND, SC_MOVE + HTCAPTION, 0);
        }
        #endregion
    }
}
