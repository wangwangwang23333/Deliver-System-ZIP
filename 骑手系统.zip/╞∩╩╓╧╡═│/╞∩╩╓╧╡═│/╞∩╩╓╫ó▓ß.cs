﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Net;
using System.Runtime.InteropServices;

namespace 骑手系统
{
    public partial class 骑手注册 : Form
    {
        //连接数据库
        const string mystr = "Data Source=DESKTOP-4U1M65K;Initial Catalog=take_out;Integrated Security=True";
        SqlConnection myconn = new SqlConnection(mystr);

        public bool imageFinished = false;
        public bool passwordFinished = false;
        public string imageFile;

        //发送验证短信相关代码
        private string url = "http://utf8.sms.webchinese.cn/?";
        private string strUid = "Uid=";
        private string strKey = "&key=d41d8cd98f00b204e980";
        private string strMob = "&smsMob=";
        private string strContent = "&smsText=";
        private int yanzhengma;
        private bool yanzhengma_send = false;

        public 骑手注册()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            //默认路径
            openFileDialog1.InitialDirectory = "C:\\";
            //限制文件格式
            openFileDialog1.Filter = "*.png|*.jpg|*.jpeg|*.bmp";
            //选择文件
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                //设置图片
                imageFile = openFileDialog1.FileName;
                pictureBox1.Image = Image.FromFile(imageFile);
                label1.Hide();
                //图片上传操作完成
                imageFinished = true;
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            //默认路径
            openFileDialog1.InitialDirectory = "C:\\";
            //限制文件格式
            openFileDialog1.Filter = "*.png|*.jpg|*.jpeg|*.bmp";
            //选择文件
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                //设置图片
                string imageFile = openFileDialog1.FileName;
                pictureBox1.Image = Image.FromFile(imageFile);
                label1.Hide();
                //图片上传操作完成
                imageFinished = true;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                //检验姓名
                if(textBox1.Text.Length==0)
                {
                    MessageBox.Show("非法姓名！");
                    return;
                }

                //检验身份证
                if (!CheckIDCard(textBox2.Text))
                {
                    MessageBox.Show("非法身份证号！");
                    return;
                }

                //检验电话号码
                string phoneNumber = textBox3.Text;
                if(phoneNumber.Contains("-"))
                {
                    string[] numbers = new string[2];
                    numbers = phoneNumber.Split('-');
                    //前半段必须全部数字
                    for (int i = 0; i < numbers[0].Length; i++)
                    {
                        if (!(numbers[0][i] >= '0' && numbers[0][i] <= '9'))
                        {
                            MessageBox.Show("非法电话号码");
                            return;
                        }
                    }
                    //后半段必须符合正常电话号码
                    for (int i = 0; i < numbers[1].Length; i++)
                    {
                        if (!(numbers[1][i] >= '0' && numbers[1][i] <= '9'))
                        {
                            MessageBox.Show("非法电话号码");
                            return;
                        }
                    }
                    //长度必须恰好等于11
                    if (numbers[1].Length != 11)
                    {
                        MessageBox.Show("非法电话号码");
                        return;
                    }
                }
                else
                {
                    //必须全数字
                    for(int i=0;i<phoneNumber.Length;i++)
                    {
                        if (!(phoneNumber[i] >= '0' && phoneNumber[i] <= '9'))
                        {
                            MessageBox.Show("非法电话号码");
                            return;
                        }
                    }
                    //长度必须恰好等于11
                    if(phoneNumber.Length!=11)
                    {
                        MessageBox.Show("非法电话号码");
                        return;
                    }
                }

                if(!passwordFinished)
                {
                    MessageBox.Show("请输入正确的密码");
                    return;
                }

                if(!imageFinished)
                {
                    MessageBox.Show("请上传个人图片");
                    return;
                }

                //验证码
                if(yanzhengma_send==false)
                {
                    MessageBox.Show("请发送手机验证码！");
                    return;
                }

                //检查验证码是否正确
                if(yanzhengma!= int.Parse(textBox5.Text.ToString()))
                {
                    MessageBox.Show("验证码错误！");
                    return;
                }

                //到此，说明成功操作，执行写入数据库操作
                

                //首先获取当前最大工号，以生成新的工号
                string findStr = "select MAX(deliverGuy_id) from deliverGuy";

                //查找工号指令
                SqlCommand mycmd = new SqlCommand(findStr, myconn);

                string maxId;
                //打开数据库连接
                myconn.Open();
                SqlDataReader myreader = mycmd.ExecuteReader();
                try
                {
                    //读取数据
                    myreader.Read();
                    maxId = myreader.GetString(0);
                }
                catch (Exception){ maxId = "g09999"; }
                myreader.Close();

                //首先需要检验手机号以及身份证号在此之前从未注册使用过
                string checkStr = "select deliverGuy_id from deliverGuy where deliverGuy_phone='" + textBox3.Text + "'";
                mycmd.CommandText = checkStr;
                myreader = mycmd.ExecuteReader();
                try
                {
                    myreader.Read();
                    myreader.GetString(0);
                    myreader.Close();
                    myconn.Close();
                    MessageBox.Show("当前电话号码已注册使用过");
                    return;
                }
                catch (Exception) { };

                myreader.Close();
                checkStr = "select deliverGuy_id from deliverGuy where deliverGuy_realID='" + textBox2.Text + "'";
                mycmd.CommandText = checkStr;
                myreader = mycmd.ExecuteReader();
                try
                {
                    myreader.Read();
                    myreader.GetString(0);
                    myreader.Close();
                    myconn.Close();
                    MessageBox.Show("当前身份证号已注册使用过");
                    return;
                }
                catch (Exception) { };
                myreader.Close();

                //新的工号应在原有工号基础上加一
                maxId = "g" + (int.Parse(maxId.Substring(1)) + 1).ToString();

                //插入命令
                string insertStr = "insert into deliverGuy(deliverGuy_id,deliverGuy_name,deliverGuy_password,deliverGuy_phone,deliverGuy_realID,deliverGuy_image) values ('" + maxId + "', '" + textBox1.Text + "', '" + textBox4.Text + "', '" + textBox3.Text + "', '" + textBox2.Text + "','" + imageFile + "')";

                //插入数据
                mycmd.CommandText = insertStr;

                //再次执行插入命令
                mycmd.ExecuteNonQuery();

                //关闭数据库连接
                myconn.Close();

                //成功执行命令，弹窗提醒用户
                MessageBox.Show("成功注册！您的个人ID号为“" + maxId + "”，您的注册手机号为" + textBox3.Text + "\n待审核通过后，您即可成为骑手!");

                this.Owner.Show();

                //关闭本窗体
                this.Close();

                
            }
            catch (Exception error)
            {
                MessageBox.Show(error.ToString());
            }
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            //同步更新
            string userPassword = textBox4.Text;
            //检验密码异常
            if (userPassword.Length < 8)
                label6.Text = "密码需要至少八位";
            else
            {
                //检验是否同时含有字母和数字
                bool numberAppear = false;
                bool wordAppear = false;
                for (int i = 0; i < userPassword.Length; i++)
                {
                    if (userPassword[i] >= '0' && userPassword[i] <= '9')
                        numberAppear = true;
                    else if ((userPassword[i] >= 'a' && userPassword[i] <= 'z') ||
                        userPassword[i] >= 'A' && userPassword[i] <= 'Z')
                        wordAppear = true;
                }
                //输出提示符
                if (!numberAppear || !wordAppear)
                    label6.Text = "密码需要同时包含数字和字母";
                else
                {
                    label6.Text = "合法的密码";
                    passwordFinished = true;
                    return;
                }
            }
            passwordFinished = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        /// <summary>  
        /// 18位身份证号码验证  
        /// </summary>  
        private bool CheckIDCard(string idNumber)
        {
            long n = 0;
            //长度检验
            if (idNumber.Length < 18)
                return false;
            if (long.TryParse(idNumber.Remove(17), out n) == false
                || n < Math.Pow(10, 16) || long.TryParse(idNumber.Replace('x', '0').Replace('X', '0'), out n) == false)
            {
                return false;//数字验证  
            }
            string address = "11x22x35x44x53x12x23x36x45x54x13x31x37x46x61x14x32x41x50x62x15x33x42x51x63x21x34x43x52x64x65x71x81x82x91";
            if (address.IndexOf(idNumber.Remove(2)) == -1)
            {
                return false;//省份验证  
            }
            string birth = idNumber.Substring(6, 8).Insert(6, "-").Insert(4, "-");
            DateTime time = new DateTime();
            if (DateTime.TryParse(birth, out time) == false)
            {
                return false;//生日验证  
            }
            string[] arrVarifyCode = ("1,0,x,9,8,7,6,5,4,3,2").Split(',');
            string[] Wi = ("7,9,10,5,8,4,2,1,6,3,7,9,10,5,8,4,2").Split(',');
            char[] Ai = idNumber.Remove(17).ToCharArray();
            int sum = 0;
            for (int i = 0; i < 17; i++)
            {
                sum += int.Parse(Wi[i]) * int.Parse(Ai[i].ToString());
            }
            int y = -1;
            Math.DivRem(sum, 11, out y);
            if (arrVarifyCode[y] != idNumber.Substring(17, 1).ToLower())
            {
                return false;//校验码验证  
            }
            return true;//符合GB11643-1999标准  
        }

        private void 骑手注册_Load(object sender, EventArgs e)
        {

        }

        #region 无边框拖动效果
        [DllImport("user32.dll")]//拖动无窗体的控件
        public static extern bool ReleaseCapture();
        [DllImport("user32.dll")]
        public static extern bool SendMessage(IntPtr hwnd, int wMsg, int wParam, int lParam);
        public const int WM_SYSCOMMAND = 0x0112;
        public const int SC_MOVE = 0xF010;
        public const int HTCAPTION = 0x0002;

        private void Start_MouseDown(object sender, MouseEventArgs e)
        {
            //拖动窗体
            ReleaseCapture();
            SendMessage(this.Handle, WM_SYSCOMMAND, SC_MOVE + HTCAPTION, 0);
        }
        #endregion

        private void button3_Click(object sender, EventArgs e)
        {
            //发送之前，检验手机号是否被使用过
            string checkStr = "select deliverGuy_id from deliverGuy where deliverGuy_phone='" + textBox3.Text + "'";
            SqlCommand mycmd = new SqlCommand(checkStr, myconn);

            myconn.Open();
            SqlDataReader myreader = mycmd.ExecuteReader();
            try
            {
                myreader.Read();
                myreader.GetString(0);
                myreader.Close();
                myconn.Close();
                MessageBox.Show("当前电话号码已注册使用过");
                return;
            }
            catch (Exception) { };
            myconn.Close();
            myreader.Close();

            Random rd = new Random();
            yanzhengma = rd.Next(1000, 9999);
            if (textBox3.Text.ToString().Trim() != "")
            {
                url = url + strUid + "wangwangwang23333" + strKey + strMob + textBox3.Text + strContent + "您正在注册使用外卖数据库系统，验证码为" + yanzhengma + "。如该短信非您本人操作，请忽略。";
                string Result = GetHtmlFromUrl(url);

                if(Result=="1")
                {
                    MessageBox.Show("短信已发送！如未收到，请检查是否被拦截或手机欠费！");
                    button3.Enabled = false;
                    yanzhengma_send = true;
                }
                else
                {
                    MessageBox.Show("无法正常发送短信，请检查您的网络是否正常连接或手机号是否正确！");
                }
            }
        }

        public string GetHtmlFromUrl(string url)
        {
            string strRet = null;
            if (url == null || url.Trim().ToString() == "")
            {
                return strRet;
            }
            string targeturl = url.Trim().ToString();
            try
            {
                HttpWebRequest hr = (HttpWebRequest)WebRequest.Create(targeturl);
                hr.UserAgent = "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)";
                hr.Method = "GET";
                hr.Timeout = 30 * 60 * 1000;
                WebResponse hs = hr.GetResponse();
                Stream sr = hs.GetResponseStream();
                StreamReader ser = new StreamReader(sr, Encoding.Default);
                strRet = ser.ReadToEnd();
            }
            catch (Exception ex)
            {
                strRet = null;
            }
            return strRet;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Owner.Show();
            this.Close();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            if (textBox4.PasswordChar == '●')
            {
                textBox4.PasswordChar = '\0';
                button2.Image = Image.FromFile("yanjingzheng.png");
            }
            else
            {
                textBox4.PasswordChar = '●';
                button2.Image = Image.FromFile("yanjingbi.png");
            }
        }
    }
}
